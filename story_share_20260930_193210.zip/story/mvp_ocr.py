"""Read the in-game MVP window from a screenshot (Windows built-in OCR) and fill data/mvp_game.yaml's values.

Why: 2026-09-30 user: "사진주면 알아서 자동적으로 넣어주는거없나??" - typing the 12-row '주차별 예상' table by hand is
tedious. Windows 10/11 ships an OCR engine (Windows.Media.Ocr) with the Korean recognizer on Korean installs, reached
through PowerShell 5.1's WinRT bridge, so no extra Python package or download is needed (friend PCs too).
Parsed: '이번 주 등급' / '블랙 등급까지 N 캐시' (if visible) and rows 'N 주차 뒤 · 날짜 · 예상 등급 · N 캐시'.
Words are grouped into rows by their vertical position, because OCR lines break at the wide column gaps.

Self-test (reads the 2026-09-30 screenshot if present, else only the parser):
    <story>\\.venv\\Scripts\\python.exe -X utf8 <story>\\mvp_ocr.py [image]
"""
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

GRADES = ["브론즈", "실버", "골드", "다이아", "레드", "블랙"]
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

PS = r"""
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, [Type]$t) { $task = $asTask.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result }
$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($args[0])) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bmp = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
$eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('ko'))
if ($eng -eq $null) { $eng = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
$res = Await ($eng.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
$out = foreach ($l in $res.Lines) { foreach ($w in $l.Words) {
    [pscustomobject]@{ t = $w.Text; x = $w.BoundingRect.X; y = $w.BoundingRect.Y; h = $w.BoundingRect.Height } } }
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
ConvertTo-Json -InputObject @($out) -Compress
"""


def ocr_words(image: bytes, upscale: int = 2) -> list[dict]:
    """Words with positions. Small game fonts read better enlarged, so the image is scaled up first (PIL if present)."""
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "mvp.png"
        try:
            from io import BytesIO
            from PIL import Image
            im = Image.open(BytesIO(image)).convert("RGB")
            im = im.resize((im.width * upscale, im.height * upscale), Image.LANCZOS)
            im.save(p)
        except ImportError:
            p.write_bytes(image)
        ps = Path(d) / "ocr.ps1"
        ps.write_text(PS, encoding="utf-8-sig")
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(ps), str(p)],
                           capture_output=True, timeout=120, creationflags=NO_WINDOW)
        if r.returncode != 0:
            raise RuntimeError("Windows 글자 인식 실패: " + r.stderr.decode("utf-8", "replace")[-400:])
        txt = r.stdout.decode("utf-8", "replace").strip()
        return json.loads(txt) if txt else []


def rows_of(words: list[dict]) -> list[str]:
    """Group words whose vertical centers are within half a word height, left to right, into row strings."""
    ws = sorted(words, key=lambda w: w["y"] + w["h"] / 2)
    rows, cur, cy = [], [], None
    for w in ws:
        c = w["y"] + w["h"] / 2
        if cy is not None and abs(c - cy) > max(w["h"], 1) * 0.6:
            rows.append(cur)
            cur = []
        cur.append(w)
        cy = c if len(cur) == 1 else (cy * (len(cur) - 1) + c) / len(cur)
    if cur:
        rows.append(cur)
    return [" ".join(w["t"] for w in sorted(r, key=lambda w: w["x"])) for r in rows]


def _num(s: str) -> int | None:
    s = s.replace(",", "").replace(".", "").replace(" ", "")
    s = s.translate(str.maketrans({"O": "0", "o": "0", "l": "1", "I": "1"}))
    return int(s) if s.isdigit() else None


FUZZY = {"다미마": "다이아", "다이마": "다이아", "다미아": "다이아", "디이아": "다이아", "레트": "레드", "블렉": "블랙",
         "골트": "골드", "실바": "실버", "브론조": "브론즈"}


def _grade(s: str) -> str:
    for k, v in FUZZY.items():
        s = s.replace(k, v)
    return next((x for x in GRADES if x in s), "")


def parse(rows: list[str]) -> dict:
    """{'grade', 'to_black', 'weeks': [{k, grade, keep}]}; keys missing when not found in the picture.
    Read loosely (2026-09-30 real screenshot: 주차 -> '주가', 다이아 -> '다미마', 캐시 -> '캐치', 골드 dropped, '2026-1 1-05'):
    a row = '<k> 주? 뒤', the date is removed, keep = the last number. A missing grade is left '' for fill_grades."""
    out: dict = {}
    weeks = {}
    for row in rows:
        flat = row.replace(" ", "")
        m = re.match(r"(\d{1,2})주.?뒤", flat)
        if m:
            k = int(m.group(1))
            rest = re.sub(r"20\d\d-?\d\d-?\d\d", "", flat[m.end():])  # 등급 설정일
            nums = re.findall(r"\d[\d,.]*", rest)
            keep = _num(nums[-1]) if nums else None
            if 1 <= k <= 12 and keep is not None:
                weeks[k] = {"k": k, "grade": _grade(rest), "keep": keep}
            continue
        mb = re.search(r"블랙등급까지([\dOolI,.]+)", flat)
        if mb and _num(mb.group(1)) is not None:
            out["to_black"] = _num(mb.group(1))
        if "이번주" in flat and "등급" in flat and "예상" not in flat:
            g = _grade(flat.split("등급", 1)[-1])
            if g:
                out["grade"] = g
        if "다음주예상등급" in flat:
            g = _grade(flat.split("등급", 1)[-1])
            if g:
                out["next_grade"] = g
    if weeks:
        out["weeks"] = [weeks[k] for k in sorted(weeks)]
    return out


def fill_grades(weeks: list[dict], cur_grade: str, thresholds: dict) -> list[dict]:
    """Grade from 'keep' (13-week total = current-grade threshold - keep; keep 0 = current grade kept), used when OCR
    missed the word and to overwrite misread words, because the number is what the window actually states."""
    th_c = thresholds[cur_grade]
    order = sorted(thresholds, key=thresholds.get)
    for w in weeks:
        if w["keep"] == 0:
            w["grade"] = cur_grade
        else:
            t = th_c - w["keep"]
            w["grade"] = next((g for g in reversed(order) if t >= thresholds[g]), "")
    return weeks


def read_image(image: bytes) -> dict:
    return parse(rows_of(ocr_words(image)))


def selftest(img: Path | None) -> None:
    fake = ["주차 등급 설정일 예상 등급 현재 등급 유지까지", "1 주차 뒤 2026-10-01 레드 0 캐시",
            "3 주차 뒤 2026-10-15 다이아 8,614 캐시", "12 주차 뒤 2026-12-17 골드 821,354 캐시",
            "블랙 등급까지 296,614 캐시", "이번 주 등급 레드", "다음 주 예상 등급 레트"]
    p = parse(fake)
    assert p == {"to_black": 296614, "grade": "레드", "next_grade": "레드", "weeks": [
        {"k": 1, "grade": "레드", "keep": 0}, {"k": 3, "grade": "다이아", "keep": 8614},
        {"k": 12, "grade": "골드", "keep": 821354}]}, p
    print("parser ok")
    if img and img.exists():
        got = read_image(img.read_bytes())
        th = {"브론즈": 150_000, "실버": 300_000, "골드": 600_000, "다이아": 900_000, "레드": 1_500_000, "블랙": 2_500_000}
        fill_grades(got["weeks"], got.get("grade") or got.get("next_grade") or "레드", th)
        print(json.dumps(got, ensure_ascii=False))
        want = [0, 0, 8614, 358614, 458614, 478614, 578614, 748614, 798614, 821354, 821354, 821354]
        keeps = [w["keep"] for w in got.get("weeks", [])]
        assert keeps == want, (keeps, want)
        assert [w["grade"] for w in got["weeks"]] == ["레드"] * 2 + ["다이아"] * 5 + ["골드"] * 5
        print("screenshot ok: 12 rows")
    print("selftest ok")


if __name__ == "__main__":
    selftest(Path(sys.argv[1]) if len(sys.argv) > 1 else None)
