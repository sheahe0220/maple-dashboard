"""메소 구하기 tab math: what 1억 meso costs by each way of getting it, and a plan to reach a target amount.

Why: 2026-09-30 user: "메소구하거나 얼마 구하는지 이런걸로 탭을 새로 만들어봐" + "MVP작으로 넘기는게 낫지않아?".
Ways compared (원 per 1억 meso, lower = cheaper):
  메소마켓   메포 per 1억 x 원 per 메포 x (1 - 충전 할인). Buyer pays no fee (seller 1%, 나무위키 거래 시스템 2026-09-30).
  엠작       a cash item bought for C 캐시 and sold on the auction for S억: C x 원 per 캐시 x (1 - 충전 할인) / (S x (1 - fee)).
             fee 5%, MVP 실버+ or PC방 3% (ref/mvp_20260930.yaml benefits.permanent.옥션_판매_수수료).
  현금 거래  the user-typed cash trade rate (reference only: user-to-user cash trades break the NEXON terms).
Boss crystals are income, not a price: they appear in the target plan as meso per week.

Self-test:
    <story>\\.venv\\Scripts\\python.exe -X utf8 <story>\\money.py
"""
import math

EOK = 100_000_000


def route_mesomarket(mp_per_eok: float, won_per_mp: float = 1.0, charge_disc_pct: float = 0.0) -> float | None:
    if mp_per_eok <= 0:
        return None
    return mp_per_eok * won_per_mp * (1 - charge_disc_pct / 100)


def route_mvp_item(cash: float, sell_eok: float, fee: float, won_per_cash: float = 1.0,
                   charge_disc_pct: float = 0.0) -> float | None:
    """원 per 1억 when a cash item (price `cash`) is resold on the auction for `sell_eok` 억. fee is a fraction."""
    if not cash or not sell_eok or sell_eok <= 0:
        return None
    return cash * won_per_cash * (1 - charge_disc_pct / 100) / (sell_eok * (1 - fee))


def routes(mk: dict, items: list[dict], fee: float, mp_per_eok: float | None = None) -> list[dict]:
    """Rows sorted cheapest first: {방법, 1억당 원, MVP 실적, 비고}. mk = market.load() values."""
    v = lambda k: float((mk.get(k) or {}).get("value") or 0)
    disc, wpm = v("charge_discount_pct"), v("won_per_mp") or 1.0
    rate = mp_per_eok if mp_per_eok is not None else v("meso_market_mp_per_eok")
    out = []
    mm = route_mesomarket(rate, wpm, disc)
    if mm:
        out.append({"방법": "메소마켓 (메포로 사기)", "1억당 원": mm, "MVP 실적": "판정보류",
                    "비고": f"1억 = {rate:,.0f} 메포, 사는 쪽 수수료 없음"})
    for it in items:
        w = route_mvp_item(float(it.get("캐시 가격") or 0), float(it.get("경매장 판매가 (억)") or 0), fee, wpm, disc)
        if w:
            out.append({"방법": f"엠작: {it.get('아이템')}", "1억당 원": w, "MVP 실적": "쌓임",
                        "비고": f"{float(it['캐시 가격']):,.0f} 캐시 -> 경매장 {float(it['경매장 판매가 (억)']):,.2f}억, "
                              f"수수료 {fee:.0%}"})
    cash = v("cash_won_per_eok")
    if cash > 0:
        out.append({"방법": "현금 거래 (참고)", "1억당 원": cash, "MVP 실적": "없음",
                    "비고": "직접 입력한 시세. 넥슨 약관상 제재 대상"})
    return sorted(out, key=lambda r: r["1억당 원"])


def target_plan(need_eok: float, have_eok: float, weekly_eok: float, won_per_eok: float | None,
                deadline_weeks: int = 0) -> dict:
    """How to reach `need_eok`: weeks by boss crystals alone, cost to buy the rest now, and (with a deadline) how much to
    buy so that boss income covers the remainder by then."""
    short = max(0.0, need_eok - have_eok)
    weeks = math.ceil(short / weekly_eok) if weekly_eok > 0 and short > 0 else (0 if short == 0 else None)
    buy_now = short * won_per_eok if won_per_eok else None
    buy_eok = None
    if deadline_weeks > 0:
        buy_eok = max(0.0, short - weekly_eok * deadline_weeks)
        buy_eok = math.ceil(buy_eok)  # 메소마켓 is 1억 units
    return {"short": short, "weeks": weeks, "buy_now_won": buy_now, "buy_eok": buy_eok,
            "buy_won": buy_eok * won_per_eok if buy_eok is not None and won_per_eok else None}


def selftest() -> None:
    assert route_mesomarket(1250) == 1250 and route_mesomarket(1250, 1, 10) == 1125 and route_mesomarket(0) is None
    # 25,000 캐시 item sold for 22억 with 3% fee: 25000 / (22 x 0.97) = 1171.5 원/억
    w = route_mvp_item(25_000, 22, 0.03)
    assert abs(w - 25_000 / (22 * 0.97)) < 1e-9 and route_mvp_item(25_000, 0, 0.03) is None
    mk = {"meso_market_mp_per_eok": {"value": 1250}, "won_per_mp": {"value": 1}, "charge_discount_pct": {"value": 0},
          "cash_won_per_eok": {"value": 870}}
    rs = routes(mk, [{"아이템": "A", "캐시 가격": 25_000, "경매장 판매가 (억)": 22},
                     {"아이템": "B", "캐시 가격": 10_000, "경매장 판매가 (억)": None}], 0.03)
    assert [r["방법"] for r in rs] == ["현금 거래 (참고)", "엠작: A", "메소마켓 (메포로 사기)"], rs
    p = target_plan(580, 100, 110, 1171.5, deadline_weeks=3)
    assert p["short"] == 480 and p["weeks"] == 5 and p["buy_eok"] == 150 and abs(p["buy_won"] - 150 * 1171.5) < 1e-6, p
    assert target_plan(50, 100, 10, 1000)["weeks"] == 0 and target_plan(50, 0, 0, None)["weeks"] is None
    print("routes:", [(r["방법"], round(r["1억당 원"])) for r in rs])
    print("plan 580억 (have 100, 110/week):", p)
    print("selftest ok")


if __name__ == "__main__":
    selftest()
