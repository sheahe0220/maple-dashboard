"""MVP tab: current 13-week total and grade, what is left to each grade, how long each grade lasts, payment log,
a planner, and the benefit table per grade.

Why: 2026-09-30 user: "MVP 창을 따로 만들어 봐. 블랙 · 레드까지 등급별로 얼마 남았는지, 올라가면 각각 몇 주 유지되는지,
MVP 에 대한 정보 최대한". Math in mvp.py, rules and benefits in ref/mvp_20260930.yaml (official guide 425, updates 768 ·
791 · 813; research 10_조사/20260930_MVP/MVP규칙.md).
"""
from datetime import date, timedelta

import altair as alt
import pandas as pd
import streamlit as st

import mvp

GRADE_COLOR = {"브론즈": "orange", "실버": "gray", "골드": "yellow", "다이아": "blue", "레드": "red", "블랙": "violet"}


def _wed(week: date) -> date:
    """A week runs Thursday 00:00 to Wednesday 23:59 (update 791): the last day of the week starting `week`."""
    return week + timedelta(days=6)


def render(row_factory, accent: str, muted: str, today: date) -> None:
    """v2 (2026-09-30 user: "너무 복잡해, 뭐가 뭔지 모르겠어" + "블랙 가면 다음 주에 얼마나 유지되는지"):
    one input (the in-game MVP window incl. its 12-week table), one answer on top, the rest folded away."""
    r = mvp.rules()
    grades_all = [g["name"] for g in r["grades"]]
    th = {g["name"]: g["threshold"] for g in r["grades"]}
    gv = mvp.load_game()
    game = mvp.from_game(gv, r)
    wk = mvp.week_of(today, r["week_start_weekday"])

    game_input(gv, grades_all, today, open_=not game)
    if not game:
        st.info("위 칸에 게임 캐시샵 MVP 창의 숫자를 옮겨 적으면 여기에 결과가 나옵니다. 넥슨 Open API 에는 MVP 정보가 없어 "
                "자동으로 가져올 수 없습니다.", icon=":material/info:")
        more_sections(r, None, row_factory, accent, muted, today)
        return

    # summary: where I am
    k = row_factory()
    k.metric("지금 등급", game["grade"], icon=":material/workspace_premium:",
             help=f"게임 MVP 창 값 ({game['date']} 입력)")
    k.metric("최근 13주 사용액", f"{game['total']:,.0f}", icon=":material/military_tech:",
             help="블랙 기준 - 게임 창의 '블랙 등급까지'")
    top = grades_all[-1]
    k.metric(f"{top}까지", "달성" if game["grade"] == top else f"{th[top] - game['total']:,.0f}", icon=":material/flag:")
    k.metric("이번 주", f"{wk:%m-%d} ~ {(wk + timedelta(days=6)):%m-%d}", icon=":material/calendar_today:",
             help="1주 = 목요일 00:00 ~ 다음 수요일 23:59")

    # the answer (2026-09-30 user: "내가 블랙을 달면 블랙을 얼마나 유지되는거냐"): spend X this week -> grade per week
    st.subheader("이번 주에 쓰면 등급이 언제까지 가나", divider=False)
    end = lambda n: wk + timedelta(weeks=n, days=6)      # last day (Wednesday) of the week set n weeks from now
    start = lambda n: wk + timedelta(weeks=n)             # 등급 설정일 (Thursday)
    to_top = max(0, th[top] - game["total"])
    spend = int(st.number_input("이번 주에 쓸 캐시", min_value=0, value=to_top, step=10_000,
                                key=f"mvpw_spend_{game['total']}",
                                help=f"처음 값은 {top}까지 남은 금액입니다. 0 으로 두면 더 안 쓸 때 등급이 나옵니다."))
    tl = mvp.after_spend(gv, r, spend)
    if not tl:
        new_g = mvp.grade_of(game["total"] + spend, r["grades"]) or "없음"
        st.info(f"{spend:,.0f} 캐시를 쓰면 {start(1):%m-%d}부터 {new_g}. 언제까지 가는지는 게임 MVP 창의 주차별 표를 위 칸에 "
                "넣으면(사진 올리기) 계산합니다.", icon=":material/info:")
    else:
        g1 = tl[0]["lo"]
        sure, maybe = mvp.runs(tl, g1)
        after = next((t for t in tl if t["week"] > max(sure, maybe)), None)
        msg = (f"이번 주({end(0):%m-%d} 수요일 23:59까지)에 **{spend:,.0f} 캐시**를 쓰면 **{start(1):%m-%d}부터 {g1}** 입니다. "
               f"{g1}은 **{end(sure):%m-%d}(수)까지 확실히 유지**" +
               (f"되고, 7월 초처럼 오래된 사용분이 얼마였는지에 따라 **최대 {end(maybe):%m-%d}(수)까지** 갈 수 있습니다."
                if maybe > sure else "됩니다.") +
               (f" 그다음 {start(after['week']):%m-%d}부터는 {after['lo']}" +
                (f" ~ {after['hi']}" if after["hi"] != after["lo"] else "") + " 입니다." if after else ""))
        st.markdown(msg)
        rows = []
        for t in tl:
            rows.append({"주": f"{t['week']}주 뒤", "기간": f"{start(t['week']):%m-%d} ~ {end(t['week']):%m-%d}",
                         "등급": t["lo"] if t["lo"] == t["hi"] else f"{t['lo']} 또는 {t['hi']}",
                         "13주 사용액": (f"{t['total_lo']:,.0f}" if t["total_lo"] == t["total_hi"]
                                     else f"{t['total_lo']:,.0f} ~ {t['total_hi']:,.0f}")})
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch", height="content")
        st.caption("게임 창에서 '현재 등급 유지까지'가 0 캐시인 주는 그 주 합계를 정확히 알 수 없어 '또는' 으로 나옵니다. 이번 주에 쓴 "
                   "금액은 13주 동안 합계에 남습니다. 블랙 이월(250만 초과분)은 넣지 않았습니다.")

        with st.expander("몇 주 유지하려면 이번 주에 얼마를 써야 하나", icon=":material/timer:"):
            target = st.segmented_control("목표 등급", grades_all[::-1], default=top, key="mvpw_target") or top
            plan = mvp.hold_plan(gv, r, target)
            st.dataframe(pd.DataFrame([{
                "주": f"{p['week']}주 뒤", "기간": f"{start(p['week']):%m-%d} ~ {end(p['week']):%m-%d}",
                f"이 주까지 {target} 유지하려면 이번 주에 쓸 캐시": (f"{p['spend_lo']:,.0f}" if p["spend_lo"] == p["spend_hi"]
                                                     else f"{p['spend_lo']:,.0f} ~ {p['spend_hi']:,.0f}")}
                for p in plan]), hide_index=True, width="stretch", height="content")

    # compact: what is left to each grade
    with st.expander("등급별로 남은 금액", icon=":material/stairs:"):
        st.dataframe(pd.DataFrame([{"등급": p["grade"], "기준": p["threshold"],
                                    "남은 금액": "달성" if p["reached"] else f"{p['left']:,.0f}"} for p in game["per_grade"]]),
                     hide_index=True, width="stretch", height="content",
                     column_config={"기준": st.column_config.NumberColumn(format="%,d")})
    more_sections(r, game["grade"], row_factory, accent, muted, today)


def game_input(gv: dict, grades_all: list, today: date, open_: bool) -> None:
    """The in-game MVP window: this week's grade, '블랙 등급까지', and the 12-week table (예상 등급, 현재 등급 유지까지)."""
    with st.expander("게임 MVP 창 옮겨 적기" + (f" (마지막 입력 {gv.get('date')})" if gv.get("date") else ""),
                     expanded=open_, icon=":material/edit_note:"):
        photo_input(gv, grades_all, today)
        st.caption("사진 대신 직접 적어도 됩니다. 아래 표는 MVP 창의 '주차 · 예상 등급 · 현재 등급 유지까지' 표입니다"
                   "(몇 주 유지되는지 계산에 씁니다, 모르면 비워도 됨).")
        with st.form("mvp_game"):
            a1, a2 = st.columns(2)
            g_grade = a1.selectbox("이번 주 등급", grades_all,
                                   index=grades_all.index(gv["grade"]) if gv.get("grade") in grades_all else 0)
            g_black = a2.number_input(f"{grades_all[-1]} 등급까지 (캐시)", min_value=0, value=int(gv.get("to_black") or 0),
                                      step=1000, help="블랙이면 0")
            old = {int(w["k"]): w for w in gv.get("weeks") or []}
            base = pd.DataFrame([{"주차": f"{k_}주 뒤", "예상 등급": (old.get(k_) or {}).get("grade") or None,
                                  "현재 등급 유지까지": (old.get(k_) or {}).get("keep")} for k_ in range(1, 13)])
            ed = st.data_editor(base, hide_index=True, width="stretch", disabled=["주차"], key="mvp_weeks_ed",
                                column_config={"예상 등급": st.column_config.SelectboxColumn(options=grades_all),
                                               "현재 등급 유지까지": st.column_config.NumberColumn(format="%,d", min_value=0,
                                                                                            step=1000)})
            if st.form_submit_button("저장", type="primary"):
                weeks = [{"k": i + 1, "grade": g_ if isinstance(g_, str) else "", "keep": int(kv)}
                         for i, (g_, kv) in enumerate(zip(ed["예상 등급"], ed["현재 등급 유지까지"])) if pd.notna(kv)]
                mvp.save_game({"date": today.isoformat(), "grade": g_grade, "to_black": int(g_black),
                               "next_grade": weeks[0]["grade"] if weeks else gv.get("next_grade"),
                               "keep_left": weeks[0]["keep"] if weeks else int(gv.get("keep_left") or 0), "weeks": weeks})
                st.rerun()


def photo_input(gv: dict, grades_all: list, today: date) -> None:
    """2026-09-30 user: "사진주면 알아서 자동적으로 넣어주는거없나". Screenshots of the MVP window (the 주차별 표 popup, and
    optionally the window showing '블랙 등급까지') -> Windows OCR (mvp_ocr.py) -> saved straight to data/mvp_game.yaml."""
    files = st.file_uploader("게임 MVP 창 사진 올리기 (끌어다 놓기, 여러 장 가능)", type=["png", "jpg", "jpeg", "bmp"],
                             accept_multiple_files=True, key="mvpw_photo",
                             help="캐시샵 MVP 창의 주차별 표(마우스를 올리면 뜨는 창)를 캡처해 올리면 숫자를 읽어 저장합니다. "
                                  "'블랙 등급까지'가 보이는 사진을 같이 올리면 그것도 읽습니다. Windows 기본 글자 인식을 씁니다.")
    if not files:
        return
    sig = tuple((f.name, f.size) for f in files)
    if st.session_state.get("mvpw_photo_done") == sig:
        if st.session_state.get("mvpw_photo_msg"):
            st.success(st.session_state["mvpw_photo_msg"], icon=":material/check_circle:")
        return
    import mvp_ocr
    got: dict = {}
    try:
        for f in files:
            one = mvp_ocr.read_image(f.getvalue())
            got.update({k: v for k, v in one.items() if k != "weeks"})
            if one.get("weeks"):
                got["weeks"] = {**{w["k"]: w for w in got.get("weeks", [])}, **{w["k"]: w for w in one["weeks"]}}.values()
                got["weeks"] = sorted(got["weeks"], key=lambda w: w["k"])
    except Exception as e:  # OCR missing (non-Windows) or unreadable image: tell, keep the old values
        st.error(f"사진을 읽지 못했습니다: {e}")
        return
    st.session_state["mvpw_photo_done"] = sig
    if not got:
        st.warning("사진에서 MVP 창 숫자를 찾지 못했습니다. 주차별 표가 다 보이게 캡처해 주세요.")
        return
    th = {g["name"]: g["threshold"] for g in mvp.rules()["grades"]}
    cur = got.get("grade") or gv.get("grade") or got.get("next_grade")
    weeks = mvp_ocr.fill_grades(got.get("weeks", []), cur, th) if got.get("weeks") and cur in th else got.get("weeks", [])
    new = dict(gv)
    new.update({"date": today.isoformat(), "grade": cur or gv.get("grade")})
    if "to_black" in got:
        new["to_black"] = got["to_black"]
    if weeks:
        new.update({"weeks": weeks, "next_grade": weeks[0]["grade"], "keep_left": weeks[0]["keep"]})
    mvp.save_game(new)
    read = [f"주차별 표 {len(weeks)}줄"] if weeks else []
    read += [f"블랙까지 {got['to_black']:,}"] if "to_black" in got else []
    read += [f"이번 주 등급 {got['grade']}"] if "grade" in got else []
    st.session_state["mvpw_photo_msg"] = ("사진에서 읽어 저장했습니다: " + " · ".join(read)
                                          + ". 아래 표에서 틀린 칸이 있으면 고쳐 저장하세요.")
    st.rerun()


def more_sections(r: dict, grade, row_factory, accent, muted, today) -> None:
    with st.expander("등급별 혜택", icon=":material/redeem:"):
        benefits_section(r, grade)
    rules_section(r)
    with st.expander("사용 기록으로 직접 계산 (선택)", icon=":material/receipt_long:"):
        st.caption("게임 창 대신 날짜별 사용액으로 계산하고 싶을 때만 씁니다.")
        log_section(r, row_factory, accent, muted, today)


def log_section(r: dict, row_factory, accent: str, muted: str, today: date) -> None:
    """Optional: the same answers from typed payments (date, amount) instead of the game window."""
    rows = mvp.load_log()
    carry = int(st.number_input("블랙 이월 금액 (캐시)", min_value=0, max_value=r["carry_max"], value=0, step=10_000,
                                key="mvpw_carry", help="블랙 기준을 넘은 사용액이 최대 1,000만까지 이월됩니다(업데이트 813)."))
    s = mvp.status(rows, today, r, carry)
    if rows:
        lad = [{"등급": p["grade"], "기준": p["threshold"], "남은 금액": "달성" if p["reached"] else f"{p['left']:,.0f}",
                "더 안 쓰면 유지": (f"{p['weeks_kept']}주 ({p['holds_until_week'] + timedelta(days=6):%Y-%m-%d} 수요일까지)"
                                if p["weeks_kept"] else "-")} for p in s["per_grade"]]
        st.markdown(f"사용 기록 기준 13주 사용액 **{s['total']:,.0f}** · 등급 **{s['grade'] or '없음'}**")
        st.dataframe(pd.DataFrame(lad), hide_index=True, width="stretch", height="content",
                     column_config={"기준": st.column_config.NumberColumn(format="%,d")})
        fut = pd.DataFrame([{"주": f"{w:%m-%d}", "누적": t} for w, t in s["future"]])
        st.altair_chart(alt.Chart(fut).mark_bar(color=accent).encode(
            x=alt.X("주:N", sort=None, title="주 (목요일 시작)"), y=alt.Y("누적:Q", title=None),
            tooltip=["주", alt.Tooltip("누적:Q", format=",d")]).properties(height=200, title="더 안 쓰면 앞으로 13주 누적"),
            width="stretch")
    base = pd.DataFrame(rows or [], columns=["date", "amount", "memo"])
    if len(base):
        base["date"] = pd.to_datetime(base["date"]).dt.date
    ed = st.data_editor(base.rename(columns={"date": "날짜", "amount": "캐시", "memo": "메모"}), num_rows="dynamic",
                        width="stretch", key="mvpw_editor", hide_index=True, column_config={
                            "날짜": st.column_config.DateColumn(format="YYYY-MM-DD", required=True),
                            "캐시": st.column_config.NumberColumn(format="%,d", min_value=0, step=1000, required=True),
                            "메모": st.column_config.TextColumn()})
    if st.button("사용 기록 저장", key="mvpw_save"):
        mvp.save_log([{"date": d, "amount": a, "memo": m} for d, a, m in ed[["날짜", "캐시", "메모"]].itertuples(index=False)
                      if pd.notna(d) and pd.notna(a)])
        st.rerun()


def benefits_section(r: dict, grade: str | None) -> None:
    b = r.get("benefits") or {}
    if not b:
        return
    names = [g["name"] for g in r["grades"]]
    st.subheader("등급별 혜택", divider=False, help="공식 MVP 가이드 425 · 업데이트 813 기준. 지금 등급 열에 ★")
    tbl = []

    def add(section, key, per):
        if isinstance(per, dict) and any(n in per for n in names):
            row = {"구분": section, "혜택": key.replace("_", " ")}
            for n in names:
                v = per.get(n, "")
                row[n] = "O" if v is True else (f"{v:.0%}" if isinstance(v, float) and v < 1 else ("" if v in (False, None) else str(v)))
            tbl.append(row)
    for sec, label in (("permanent", "상시"), ("weekly", "매주"), ("quickpass", "퀵패스")):
        for kk, per in (b.get(sec) or {}).items():
            add(label, kk, per)
    for sec, label in (("title", "칭호"), ("medal", "훈장")):
        if isinstance(b.get(sec), dict):
            add(label, label + " 능력치", b[sec])
    if tbl:
        df = pd.DataFrame(tbl)
        df = df.rename(columns={n: (f"★ {n}" if n == grade else n) for n in names})
        st.dataframe(df, hide_index=True, width="stretch", height=min(40 + 36 * len(df), 720))
    if b.get("daily_gift"):
        st.caption(f"데일리 기프트: {b['daily_gift']}")


def rules_section(r: dict) -> None:
    with st.expander("MVP 규칙 (공식 안내 요약)", icon=":material/gavel:"):
        c = r.get("counting") or {}
        lines = [f"- 등급: 이번 주 포함 최근 {r['period_weeks']}주 동안 캐시샵에서 쓴 넥슨캐시 합계. 1주 = 목 00:00 ~ 수 23:59."]
        for kk in ("basis", "charge_only", "refundable_items", "non_refundable_items", "gift", "pc_room", "mileage",
                   "excluded_items", "maple_point", "maple_credit", "refund"):
            if c.get(kk):
                lines.append(f"- {str(c[kk]).strip()}")
        if r.get("recalc_rule"):
            lines.append(f"- 등급 반영: {str(r['recalc_rule']).strip()}")
        if r.get("retention_rule"):
            lines.append(f"- 유지: {str(r['retention_rule']).strip()}")
        co = r.get("carryover") or {}
        if co.get("rule"):
            lines.append(f"- 블랙 이월: {str(co['rule']).strip()}")
        st.markdown("\n".join(lines))
        src = r.get("sources") or []
        if src:
            st.caption("출처: " + " · ".join(str(x.get("title", x) if isinstance(x, dict) else x) for x in src[:8]))
