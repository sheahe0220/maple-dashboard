"""Meso value conversions from user-entered market prices.

Why: no API serves meso market or auction prices, so the prices are typed in on
the dashboard and saved to data/market.yaml (shared by everyone who opens the page).
Every price carries the date it was entered; stale prices are shown as such.

Units
    meso_market_mp_per_eok   메이플포인트 paid for 1억 메소 on the 에오스 메소마켓
    won_per_mp               원 per 메이플포인트 (1.0 = no charge discount)
    market_fee_pct           fee when selling meso on the 메소마켓 (%)
    sol_erda_piece_meso      auction price of one 솔 에르다 조각 (메소)
    cash_won_per_eok         원 per 1억 메소 in outside cash trades (user-typed, 2026-09-18 user request;
                             never collected automatically)
"""
from datetime import date
from pathlib import Path

import yaml

PATH = Path(__file__).resolve().parent / "data" / "market.yaml"
EOK = 100_000_000

FIELDS = {
    "meso_market_mp_per_eok": "에오스 메소마켓 (1억 = ? 메포)",
    "won_per_mp": "메포 1점 실구매가 (원)",
    "market_fee_pct": "메소마켓 판매 수수료 (%)",
    "sol_erda_piece_meso": "솔 에르다 조각 1개 경매장 시세 (메소)",
    "cash_won_per_eok": "현금 거래 시세 (1억 메소 = ? 원)",
    "meso_market_mp_per_eok_ch": "챌린저스 메소마켓 시세 (1억 메소 = ? 메포, 0 = 에오스와 같음)",
    "charge_discount_pct": "캐시 충전 할인율 (%, 카드 포인트 · 상품권 등)",
}
DEFAULTS = {"meso_market_mp_per_eok": 0.0, "won_per_mp": 1.0, "market_fee_pct": 0.0,
            "sol_erda_piece_meso": 0.0, "cash_won_per_eok": 0.0,
            "meso_market_mp_per_eok_ch": 0.0, "charge_discount_pct": 0.0}


def load() -> dict:
    data = yaml.safe_load(PATH.read_text(encoding="utf-8")) if PATH.exists() else {}
    data = data or {}
    out = {}
    for k, v in DEFAULTS.items():
        e = data.get(k) or {}
        out[k] = {"value": float(e.get("value", v)), "date": e.get("date")}
    return out


def save(values: dict[str, float]) -> None:
    cur = load()
    today = date.today().isoformat()
    for k, v in values.items():
        if float(v) != cur[k]["value"]:
            cur[k] = {"value": float(v), "date": today}
    PATH.parent.mkdir(exist_ok=True)
    PATH.write_text(yaml.safe_dump(cur, allow_unicode=True, sort_keys=False), encoding="utf-8")


def meso_to_mp(meso: float, m: dict, selling: bool = False) -> float:
    rate = m["meso_market_mp_per_eok"]["value"]
    mp = meso / EOK * rate
    if selling:
        mp *= 1 - m["market_fee_pct"]["value"] / 100
    return mp


def meso_to_won(meso: float, m: dict, selling: bool = False) -> float:
    return meso_to_mp(meso, m, selling) * m["won_per_mp"]["value"]


def won_to_meso(won: float, m: dict) -> float:
    rate = m["meso_market_mp_per_eok"]["value"]
    if rate <= 0:
        return 0.0
    return won / m["won_per_mp"]["value"] / rate * EOK


def sol_erda_pieces(meso: float, m: dict) -> float:
    p = m["sol_erda_piece_meso"]["value"]
    return meso / p if p > 0 else 0.0


def meso_to_cash(meso: float, m: dict) -> float:
    return meso / EOK * m["cash_won_per_eok"]["value"]


def cash_to_meso(won: float, m: dict) -> float:
    r = m["cash_won_per_eok"]["value"]
    return won / r * EOK if r > 0 else 0.0


# ---------- typed amounts and item list (2026-09-18) ----------
UNITS = {"억": EOK, "천만": 10_000_000, "만": 10_000, "메소": 1}
ITEMS_PATH = PATH.parent / "items.yaml"


def parse_amount(text: str) -> float:
    """'13,450,000' / '1345만' / '1.345천만' / '5억 3000만' -> number. Raises ValueError."""
    s = str(text).replace(",", "").replace(" ", "").strip()
    if not s:
        return 0.0
    total, num = 0.0, ""
    i = 0
    while i < len(s):
        for u in ("천만", "억", "만", "조"):
            if s.startswith(u, i):
                if not num:
                    raise ValueError(text)
                total += float(num) * (EOK * 10_000 if u == "조" else UNITS[u])
                num, i = "", i + len(u)
                break
        else:
            if not (s[i].isdigit() or s[i] == "."):
                raise ValueError(text)
            num += s[i]
            i += 1
    return total + (float(num) if num else 0.0)


def load_items() -> list[dict]:
    if not ITEMS_PATH.exists():
        return []
    return yaml.safe_load(ITEMS_PATH.read_text(encoding="utf-8")) or []


def save_items(rows: list[dict]) -> None:
    ITEMS_PATH.parent.mkdir(exist_ok=True)
    ITEMS_PATH.write_text(yaml.safe_dump(rows, allow_unicode=True, sort_keys=False), encoding="utf-8")


# ---------- MVP (엠작) ----------
# 13-week purchase thresholds in 캐시. 블랙 250만 from 2026-09-17 (official patch 813);
# the others from namu "메이플스토리/MVP" 2026-09-10, unchanged by 813 [추정].
MVP_GRADES = {"브론즈": 150_000, "실버": 300_000, "골드": 600_000, "다이아": 900_000,
              "레드": 1_500_000, "블랙": 2_500_000}
MVP_ITEMS_PATH = PATH.parent / "mvp_items.yaml"


def mp_per_eok(m: dict, server: str) -> float:
    """메소마켓 rate for the server; 챌린저스 falls back to 에오스 when left 0."""
    if server == "챌린저스" and m["meso_market_mp_per_eok_ch"]["value"] > 0:
        return m["meso_market_mp_per_eok_ch"]["value"]
    return m["meso_market_mp_per_eok"]["value"]


def mvp_row(cash: float, qty: float, sell_eok: float, rate: float, fee: float,
            charge_disc: float, won_per_mp: float) -> dict:
    """One cash item bought and resold on the auction house.

    Buying 메포 and then meso on the 메소마켓 with the same cash also counts toward MVP, so the
    item only beats that route when it sells above breakeven = cash / rate * 1억 / (1 - fee).
    """
    cash_total = cash * qty
    paid = cash_total * (1 - charge_disc)                       # 원 actually charged
    meso = sell_eok * qty * EOK * (1 - fee)                      # meso received after fee
    meso_value = meso / EOK * rate * won_per_mp if rate else 0.0  # 원 at 메소마켓 price
    return {
        "캐시 합계": cash_total,
        "손익분기 판매가 (억)": cash / rate / (1 - fee) if rate else None,
        "회수 메소 (억)": meso / EOK,
        "회수율": meso_value / cash_total if cash_total and rate else None,
        "실부담 (원)": paid - meso_value,
    }


def auction_gross(net_meso: float, fee: float) -> float:
    """Auction price to list so that `net_meso` is left after the fee (fee is taken from the price).

    2026-09-28 user: 580억 needed at 3% -> 598억 listing, not 580 x 1.03 (that leaves 579.48억)."""
    assert 0 <= fee < 1, fee
    return net_meso / (1 - fee)


def load_mvp_items() -> list[dict]:
    if not MVP_ITEMS_PATH.exists():
        return []
    return yaml.safe_load(MVP_ITEMS_PATH.read_text(encoding="utf-8")) or []


def save_mvp_items(rows: list[dict]) -> None:
    MVP_ITEMS_PATH.parent.mkdir(exist_ok=True)
    MVP_ITEMS_PATH.write_text(yaml.safe_dump(rows, allow_unicode=True, sort_keys=False), encoding="utf-8")
