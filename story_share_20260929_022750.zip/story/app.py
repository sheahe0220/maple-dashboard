"""Streamlit dashboard. Reads data/maple.db only; the API is called only by
collector.py (the refresh button runs `collector.py --live-only`).

Run:
    C:\\Users\\jeong\\Documents\\story\\.venv\\Scripts\\python.exe -m streamlit run C:\\Users\\jeong\\Documents\\story\\app.py
"""
import base64
import functools
import json
import math
import os
import re
import subprocess
import sys
from datetime import date as Date, timedelta
from pathlib import Path

import altair as alt
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from streamlit.delta_generator import DeltaGenerator as _DG
import yaml

import db
from nexon_api import daily_budget

# every table shows "-" for empty cells instead of "None" (UI 점검 2026-09-27: None in 8 tables). One default for
# st.dataframe and container.dataframe; a call can still pass placeholder= itself.
if not getattr(_DG.dataframe, "_dash_default", False):
    _df_orig = _DG.dataframe

    def _df_dash(self, *a, **k):
        k.setdefault("placeholder", "-")
        return _df_orig(self, *a, **k)
    _df_dash._dash_default = True
    _DG.dataframe = _df_dash
st.dataframe = lambda *a, **k: _DG.dataframe(st._main, *a, **k)
# delta_color="off" marks an info line (기대 2.24회, 마지막 09-06), not a rise or fall: no arrow (UI 점검: 화살표 오용)
if not getattr(_DG.metric, "_info_default", False):
    _metric_orig = _DG.metric

    def _metric_info(self, *a, **k):
        if k.get("delta_color") == "off":
            k.setdefault("delta_arrow", "off")
        return _metric_orig(self, *a, **k)
    _metric_info._info_default = True
    _DG.metric = _metric_info
st.metric = lambda *a, **k: _DG.metric(st._main, *a, **k)

ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config.yaml"
PRICES_PATH = ROOT / "crystal_prices.yaml"

st.set_page_config(page_title="메이플 대시보드", page_icon="🍁", layout="wide")

import access  # link-only access from outside (2026-09-27); this PC (localhost) is always open
access.gate()

# chart colors that Streamlit's theme can't set (gaps between fills, label ink); both modes defined in
# .streamlit/config.toml, the palette slot 1 matches chartCategoricalColors there
DARK = (st.context.theme.type or "dark") == "dark"
SURFACE = "#0f1117" if DARK else "#ffffff"
ACCENT = "#3987e5" if DARK else "#2a78d6"
MUTED = "#9aa0ad" if DARK else "#5b6270"
# 이득 / 손해 bars: green and red from the validated chart palette in .streamlit/config.toml (per mode)
SF_GOOD = "#199e70" if DARK else "#1baf7a"
SF_BAD = "#e66767" if DARK else "#e34948"


# No password gate since 2026-09-26 (user request: only the user and one friend open it, and the
# Cloudflare link changes every launch). The old gate is in _백업/20260926_0402/app.py.


# ---------- loading ----------
def world_names() -> set[str] | None:
    """Current names of the account's characters in config world (e.g. 에오스). History is account-wide, so this
    drops characters that live in another world now (2026-09-28 user: 리부트 캐릭터 기록은 빼고, 지금 에오스
    캐릭터 기록은 날짜 제한 없이 전부 - the Genesis additional resets of 2024-11 were done before the world
    rename of 2024-12-19). None = no world set, show everything. Records under a pre-rename name are not matched."""
    world = cfg.get("world")
    if not world:
        return None
    con = db.connect()
    try:
        return {r[0] for r in con.execute("SELECT name FROM characters WHERE world=?", (world,))}
    finally:
        con.close()


@st.cache_data(ttl=300)
def load_snapshots(endpoint: str) -> pd.DataFrame:
    con = db.connect()
    rows = con.execute("SELECT s.ocid, s.date, s.json, c.name FROM snapshot s "
                       "JOIN characters c USING (ocid) WHERE s.endpoint=?", (endpoint,)).fetchall()
    con.close()
    out = []
    for ocid, d, js, name in rows:
        data = json.loads(js)
        if "_error" not in data:
            out.append({"ocid": ocid, "date": d, "name": name, "data": data})
    df = pd.DataFrame(out, columns=["ocid", "date", "name", "data"])
    pick = cfg.get("characters") or []
    return df[df["name"].isin(pick)] if pick else df


@st.cache_data(ttl=300)
def load_history(kind: str) -> pd.DataFrame:
    con = db.connect()
    rows = con.execute("SELECT json FROM history WHERE kind=?", (kind,)).fetchall()
    days = con.execute("SELECT COUNT(*), MIN(date), MAX(date) FROM history_done WHERE kind=?", (kind,)).fetchone()
    con.close()
    df = pd.DataFrame([json.loads(r[0]) for r in rows])
    names = world_names()
    if names is not None and "character_name" in df:
        df = df[df["character_name"].isin(names)].reset_index(drop=True)
    return df, (days[0], days[1] or "-", days[2] or "-")


def stat_value(stat_json: dict, name: str):
    for s in stat_json.get("final_stat") or []:
        if s["stat_name"] == name:
            try:
                return float(s["stat_value"])
            except (TypeError, ValueError):
                return None
    return None


BOSS_ICON_DIR = ROOT / "ref" / "boss_icons"


@st.cache_data
@functools.lru_cache(maxsize=256)
def boss_icon(name: str) -> str | None:
    """Local icon as a data URL (ImageColumn does not read local paths). None when missing."""
    p = BOSS_ICON_DIR / f"{name.removeprefix('시즌 보스 ')}.png"
    if not p.exists():
        p = BOSS_ICON_DIR / f"{name}.png"
    return "data:image/png;base64," + base64.b64encode(p.read_bytes()).decode() if p.exists() else None


def week_start(d: Date) -> Date:
    # weekly bosses reset Thursday 00:00 KST [추정: 인게임 주간 초기화 기준, 확인 필요]
    return d - timedelta(days=(d.weekday() - 3) % 7)


cfg = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
MAIN = cfg.get("main_character") or ""


DIFF_KO = {"easy": "이지", "normal": "노멀", "hard": "하드", "chaos": "카오스", "extreme": "익스트림"}
CARD_W = "stretch"  # cards share the row; Streamlit wraps them when they get too narrow
CALC_METRIC_W = 150  # px per small metric in calculator result cards (800px window truncated 2 columns, 2026-09-27)


# meaning -> Streamlit theme colour (adapts to light/dark): attack red, damage orange, boss/luck violet,
# defence/info blue, money/growth/cooldown green, crit/star yellow
ICON_COLOR = {
    "swords": "red", "flare": "red", "heart_broken": "red",
    "bolt": "orange", "whatshot": "orange", "redeem": "orange", "flag": "orange", "military_tech": "orange",
    "receipt_long": "orange",
    "skull": "violet", "auto_awesome": "violet", "casino": "violet", "groups": "violet",
    "shield": "blue", "person": "blue", "diamond": "blue", "token": "blue", "grid_view": "blue", "history": "blue",
    "calendar_today": "blue", "schedule": "blue", "lock": "blue",
    "savings": "green", "payments": "green", "trending_up": "green", "timer": "green", "hourglass_top": "green",
    "check_circle": "green", "exposure_plus_1": "green", "handshake": "green", "toll": "green",
    "target": "yellow", "star": "yellow", "emoji_events": "yellow",
}


class MetricRow:
    """A row of summary cards that wraps onto the next line on narrow windows instead of squeezing
    (2026-09-27 user: half-screen browser made 4-5 card rows unreadable). Same .metric() call as a column."""

    def __init__(self, width=CARD_W, border=True):
        self.box = st.container(horizontal=True, gap="small")
        self.width, self.border = width, border

    def metric(self, label, *args, **kwargs):
        # colour by meaning (2026-09-27 user: "기능에 맞게 알록달록"): the icon picks the colour, and icon + label
        # go into the label as coloured markdown so every card on every tab follows the same rule
        icon = kwargs.pop("icon", None)
        color = kwargs.pop("color", None)
        if icon:
            name = icon.removeprefix(":material/").removesuffix(":")
            color = color or ICON_COLOR.get(name, "gray")
            label = f":{color}[{icon} {label}]"
        kwargs.setdefault("width", self.width)
        kwargs.setdefault("border", self.border)
        return self.box.metric(label, *args, **kwargs)


@st.cache_data(ttl=600, show_spinner=False)
def _sf_levels() -> dict:
    """item name -> required level for the starforce cost (sf_record.level_map over all item-equipment snapshots)."""
    con = db.connect()
    try:
        return sf_record.level_map(con)
    finally:
        con.close()


PERIODS = ["7일", "30일", "90일", "올해", "에오스 이후", "전체"]
# 리부트 -> 에오스 전환일 (공식 업데이트 762, 2024-12-19; API world_name changes that day). Only the "에오스 이후"
# quick period uses it; which records show is decided by world_names().
EOS_DATE = Date.fromisoformat(str(cfg.get("eos_date") or "2024-12-19"))
# oldest day NEXON still serves enhancement history (collector walks back to it)
HISTORY_FLOOR = db.now_kst().date() - timedelta(days=int(cfg.get("history_keep_days", 730)) - 1)


def period_picker(box, key: str, first: Date, default: str = "전체") -> tuple[Date, Date]:
    """Calendar range (시작일 ~ 종료일) plus quick buttons that fill it (2026-09-27 user: "캘린더처럼 내가 원하는
    기간에 볼 수 있게"). Picking dates by hand clears the quick button so the two never disagree."""
    today = db.now_kst().date()
    first = min(first, today)
    rk, qk = f"{key}_range", f"{key}_quick"

    def span(q: str) -> tuple[Date, Date]:
        if q == "전체":
            return first, today
        if q == "올해":
            return max(first, Date(today.year, 1, 1)), today
        if q == "에오스 이후":
            return max(first, EOS_DATE), today
        return max(first, today - timedelta(days=int(q[:-1]) - 1)), today

    def on_quick():
        q = st.session_state.get(qk)
        if q:
            st.session_state[rk] = span(q)

    def on_range():
        st.session_state[qk] = None
    if rk not in st.session_state:  # defaults via session state only (a widget default too triggers a warning)
        st.session_state[rk] = span(default)
        st.session_state[qk] = default
    box.segmented_control("빠른 기간", PERIODS, key=qk, on_change=on_quick)
    rng = box.date_input("기간 (달력)", key=rk, min_value=first, max_value=today, format="YYYY-MM-DD",
                         on_change=on_range, help="시작일과 종료일을 차례로 누르세요. 받아 둔 기록 안에서만 고를 수 있습니다.")
    if isinstance(rng, (tuple, list)):
        start = rng[0] if len(rng) > 0 else first
        end = rng[1] if len(rng) > 1 else start  # while only the start is clicked, show that one day
    else:
        start = end = rng
    return start, end


def backfill_note(first_day: str) -> None:
    """While the 04:00 collector is still walking back to HISTORY_FLOOR (NEXON keeps 2 years), say so, so totals
    are not read as final."""
    if first_day and first_day != "-" and first_day > HISTORY_FLOOR.isoformat():
        left = (Date.fromisoformat(first_day) - HISTORY_FLOOR).days
        st.info(f"과거 강화 기록을 받는 중입니다. 지금은 {first_day} 부터 있고, 넥슨이 주는 가장 오래된 날"
                f"({HISTORY_FLOOR}, 최근 2년)까지 {left:,}일 남았습니다. 매일 04:00 수집이 하루 한도 안에서 이어서 받습니다.",
                icon=":material/history:")


def main_first(names) -> list:
    """Sorted names with the main character (config main_character) first."""
    return sorted(set(names), key=lambda n: (n != MAIN, n))

# ---------- sidebar ----------
with st.sidebar:
    st.header("🍁 메이플 대시보드")
    if MAIN:
        st.markdown(f":material/star: 본캐 **{MAIN}**")
    # font size (2026-09-27 user request). The theme sets sizes only at startup, so this one CSS rule scales the
    # root size; Streamlit sizes in rem, so everything follows. Kept in the URL (?font=...) across reloads.
    FONT_PX = {"작게": 14, "보통": 16, "크게": 18, "최대": 20}
    fs = st.segmented_control("글자 크기", list(FONT_PX), default="보통", key="font", bind="query-params") or "보통"
    st.html(f"<style>html {{ font-size: {FONT_PX[fs]}px; }}</style>")
    st.caption(f"대상: {cfg['world']} · " + (", ".join(cfg["characters"]) if cfg.get("characters")
                                             else f"{cfg['min_level']}레벨 이상"))
    # change the shown characters without touching config.yaml by hand (2026-09-27 user: 주보돌이만 고르기, friend too).
    # Only on this PC: people who open the shared link must not change the owner's settings.
    if access.is_local():
        with st.popover("보여 줄 캐릭터 바꾸기", icon=":material/group:", width="stretch"):
            _c = db.connect()
            _rows = _c.execute("SELECT name, class, level FROM characters WHERE world=? ORDER BY level DESC",
                               (cfg["world"],)).fetchall()
            _c.close()
            _lab = {n: f"Lv.{lv} {n} ({cl})" for n, cl, lv in _rows}
            _cur = [n for n in (cfg.get("characters") or []) if n in _lab]
            _sel = st.multiselect("캐릭터", list(_lab), default=_cur, format_func=lambda n: _lab[n], key="cfg_chars",
                                  help="보스 도는 캐릭터만 고르면 됩니다. 비우면 최소 레벨 이상 전부.")
            _main = st.selectbox("본캐", _sel or list(_lab)[:1], index=(_sel.index(MAIN) if MAIN in _sel else 0),
                                 key="cfg_main") if (_sel or _lab) else None
            if st.button("저장", key="cfg_save", type="primary", width="stretch"):
                txt = CONFIG_PATH.read_text(encoding="utf-8")
                txt, n1 = re.subn(r"^characters:.*$", "characters: [" + ", ".join(_sel) + "]", txt, count=1, flags=re.M)
                txt, n2 = re.subn(r"^main_character:.*$", f"main_character: {_main or ''}", txt, count=1, flags=re.M)
                assert n1 == 1 and n2 == 1, "config.yaml 에 characters / main_character 줄이 없습니다"
                CONFIG_PATH.write_text(txt, encoding="utf-8")
                st.cache_data.clear()
                st.rerun()
            st.caption("저장한 뒤 '지금 갱신'을 누르면 새로 고른 캐릭터 기록을 받습니다.")
    _c0 = db.connect()
    BUDGET = daily_budget(cfg)  # 950 for a dev key, daily_call_budget_live for a service key
    _left = BUDGET - db.calls_today(_c0)
    _c0.close()
    if _left <= 0:
        st.warning("오늘 호출 예산을 다 썼습니다. 자정(한국 시간) 뒤 다시 갱신할 수 있습니다.", icon=":material/hourglass_top:")
    if st.button("지금 갱신 (실시간)", width="stretch", disabled=_left <= 0):
        with st.spinner("넥슨 API 호출 중... (캐릭터당 약 1초)"):
            r = subprocess.run([sys.executable, "-X", "utf8", str(ROOT / "collector.py"), "--live-only"],
                               capture_output=True, text=True, encoding="utf-8", cwd=ROOT)
        st.cache_data.clear()
        tail = (r.stdout or "").strip().splitlines()[-1:] or ["(출력 없음)"]
        (st.success if r.returncode == 0 else st.error)(tail[0] if r.returncode == 0 else "갱신 실패. 잠시 뒤 다시 누르세요. (자세한 오류는 PC 의 collector 로그)")
    st.caption("캐릭터 정보는 인게임 반영 후 평균 15분, 큐브 기록은 최대 30분 뒤 API 에 나타납니다(넥슨 명세).")
    con = db.connect()
    st.caption(f"오늘 API 사용 {db.calls_today(con):,} / {BUDGET:,}건")
    st.caption("데이터: NEXON Open API 제공")
    # build stamp of a shared copy (make_share.py writes VERSION; updater.py keeps it current)
    if (Path(__file__).parent / "VERSION").exists():
        st.caption(f"버전 {(Path(__file__).parent / 'VERSION').read_text(encoding='utf-8').strip()}"
                   + (" · 자동 업데이트 켜짐" if (Path(__file__).parent / "update.yaml").exists() else ""))
    access.sidebar_link()  # attribution required by the Open API guide (01_API_전수.md)
    con.close()

import cube_spend
import calc_cube
import equip
import market
import calc_starforce
import importlib

import ui_components  # registered once; not reloaded

# The long-running dashboard keeps imported project modules in memory, so a page refresh after editing
# equip.py etc. mixed old modules with new app.py (2026-09-27: "module 'equip' has no attribute 'DEME_SLOTS'").
# Reloading them on every run is cheap and makes a refresh enough.
import spec_view
import spec_log
import events
import manual_view
import checklist
import sf_record
import efficiency
import icons_extra
import job_view
for _m in (db, market, cube_spend, calc_cube, calc_starforce, equip, spec_view, spec_log, events, manual_view, checklist,
           sf_record, efficiency, icons_extra, job_view):
    importlib.reload(_m)

@st.cache_data(ttl=300)
def _icons():
    return equip.icon_map(), equip.character_images()


@st.cache_data(ttl=3600)
def _cropped(url: str) -> str:
    return equip.crop_character(url) or url


ICONS, CHAR_IMG = _icons()   # item name -> icon URL, character name -> look image URL
# items no stored snapshot has an icon for (enhanced, then unequipped): official icons fetched by item id
# (ref/icons_extra/item, 10_조사/20260927_그림보강/보고서.md; 3 of 5 ids are [추정])
import icons_extra as _ix
for _n in _ix.names("item"):
    ICONS.setdefault(_n, _ix.extra_icon("item", _n))


def cube_icon(kind: str) -> str | None:
    """History cube_type -> icon. Meso resets use the meso bag; karma / memento / 대적자 variants fall back to the
    base cube picture only when that base cube exists (새 브론즈 · 실버 · 골드 큐브 그림은 이름 미확인이라 없음)."""
    if kind in ("잠재능력 재설정", "에디셔널 잠재능력 재설정", "소울 재설정"):
        return _ix.extra_icon("currency", "메소_뭉치")
    k = re.sub(r"\s*\(\d+제\)$", "", str(kind))
    return _ix.extra_icon("cube", k) or _ix.extra_icon("cube", re.sub(r"^(카르마|메멘토|대적자의)\s+", "", k))


CHAR_IMG = CHAR_IMG | {n: _cropped(CHAR_IMG[n]) for n in (cfg.get("characters") or []) if n in CHAR_IMG}
mk = market.load()
won_per_eok = market.meso_to_won(market.EOK, mk)

@st.cache_data(ttl=300, show_spinner=False)
def boss_clears():
    """Crystal sales per clear from the scheduler snapshots: (clears or None, world weekly cap, price table).
    Shared by the 보스 tab and the calculators ('보스 수익 N주'), cached so it runs once per 5 minutes."""
    sch = load_snapshots("scheduler")
    prices = yaml.safe_load(PRICES_PATH.read_text(encoding="utf-8")) if PRICES_PATH.exists() else {}
    rules = prices.get("_rules", {})
    world_cap = int(rules.get("world_weekly_sale_cap", 90))
    recs = []
    for _, r in sch.iterrows():
        for b in r["data"].get("boss_contents") or []:
            if str(b.get("complete_flag")).lower() == "true":
                recs.append({"ocid": r["ocid"], "name": r["name"], "date": Date.fromisoformat(r["date"]),
                             "boss": b["content_name"], "diff": b["difficulty"], "cycle": b["cycle"]})
    if not recs:
        return None, world_cap, prices
    bd = pd.DataFrame(recs)
    bd["week"] = bd["date"].map(week_start)
    # daily: one clear per (char, boss, day); weekly: flag stays true until Thursday reset;
    # monthly: flag stays true all month, count it once in the first week it shows up
    dy = bd[bd["cycle"] == "bossDaily"].drop_duplicates(["ocid", "boss", "diff", "date"])
    wk = bd[bd["cycle"] == "bossWeekly"].drop_duplicates(["ocid", "boss", "diff", "week"])
    mo = bd[bd["cycle"] == "bossMonthly"].copy()
    mo["month"] = mo["date"].map(lambda d: (d.year, d.month))
    mo = mo.sort_values("date").drop_duplicates(["ocid", "boss", "diff", "month"]).drop(columns="month")
    clears = pd.concat([dy, wk, mo], ignore_index=True)
    clears["key"] = clears["boss"] + "|" + clears["diff"]
    def _price(k, d):
        e = prices.get(k) or {}
        # 검은 마법사 new price applies from 2026-10-01 (official patch 813)
        if e.get("price_from") and d < Date.fromisoformat(str(e["price_from"])):
            return e.get("price_before")
        return e.get("price")
    clears["가격"] = [_price(k, d) for k, d in zip(clears["key"], clears["date"])]
    clears.loc[clears["boss"].str.startswith("시즌 보스"), "가격"] = 0  # no crystal (patch 2026-06-18)
    clears["인원"] = clears["key"].map(lambda k: (prices.get(k) or {}).get("party") or 1)
    clears["수익"] = (clears["가격"] // clears["인원"]).astype("Float64")
    # world cap: at most N crystals sold per week across all characters; sell the priciest
    clears = clears.sort_values("수익", ascending=False, na_position="last")
    clears["월드순번"] = clears.groupby("week").cumcount() + 1
    clears["판매"] = (clears["월드순번"] <= world_cap) & (clears["수익"].fillna(0) > 0)
    return clears, world_cap, prices


@st.cache_data(ttl=3600, show_spinner="장비 변경 기록 계산 중...")  # 갱신 버튼이 캐시를 비움
def _spec_changes(name: str, main: str):
    """spec_log.changes compares every stored item-equipment snapshot; cache it for 5 minutes."""
    return spec_log.changes(name, main)


def boss_week():
    """(income of the last finished week, label) for the calculators; (0, "") without clears."""
    clears, _, _ = boss_clears()
    if clears is None:
        return 0.0, ""
    weeks = sorted(clears["week"].unique(), reverse=True)
    wk = weeks[1] if len(weeks) > 1 else weeks[0]
    total = float(clears.loc[(clears["week"] == wk) & clears["판매"], "수익"].sum())
    return total, (f"{wk} 주" if len(weeks) > 1 else "이번 주(진행 중)")


basic = load_snapshots("basic")
stat = load_snapshots("stat")
if basic.empty:
    st.warning("아직 받은 데이터가 없습니다. 왼쪽 사이드바의 '지금 갱신' 을 누르거나, 처음이면 설치하기.bat 을 다시 실행하세요.")
    st.stop()

tab_spec, tab_check, tab_equip, tab_meso, tab_growth, tab_sf, tab_cube, tab_boss, tab_calc, tab_event, tab_manual = st.tabs(
    # short names so all 11 fit at 1100 px (UI 점검: 사용설명서까지 잘림)
    [":material/person: 스펙", ":material/checklist: 체크리스트", ":material/checkroom: 장비", ":material/payments: 메소",
     ":material/trending_up: 성장", ":material/star: 스타포스", ":material/casino: 큐브", ":material/swords: 보스",
     ":material/calculate: 계산기", ":material/event: 이벤트", ":material/menu_book: 설명서"],
    on_change="rerun")  # lazy: only the open tab runs (optimisation 2026-09-27; was ~19 s headless for all tabs)
# headless tests render every tab: MAPLE_ALL_TABS=1
ALL_TABS = os.environ.get("MAPLE_ALL_TABS") == "1"

# ---------- meso value ----------
def _save_rate(field: str) -> None:
    """Rate boxes save as soon as they change (no separate save button)."""
    try:
        market.save({field: market.parse_amount(st.session_state[f"rate_{field}"])})
    except ValueError:
        st.session_state["rate_error"] = st.session_state[f"rate_{field}"]


def _parse_eok(text: str) -> float:
    """'10' -> 10억, '5억 3000만' / '53000만' -> meso. Returns meso."""
    s = str(text).replace(",", "").strip()
    if any(u in s for u in ("억", "만", "조")):
        return market.parse_amount(s)
    return float(s or 0) * market.EOK


SPEND_GROUPS = {"스타포스": "스타포스", **{k: "메소 재설정" for k in cube_spend.MESO_RESETS}, "소울 재설정": "소울 재설정"}


@st.cache_data(ttl=300, show_spinner="강화에 쓴 메소 계산 중...")
def spend_frame(mvp: str, mp_per_eok: float) -> pd.DataFrame:
    """Every enhancement attempt in one table (일시 · 캐릭터 · 장비 · 종류 · 분류 · 메소), priced exactly like the
    스타포스 tab (sf_record, official cost formula + event + MVP) and the 큐브 tab (cube_spend price table)."""
    parts = []
    sf, _ = load_history("starforce")
    if not sf.empty:
        sf = sf.copy()
        sf["date_create"] = pd.to_datetime(sf["date_create"], format="ISO8601")
        a = sf_record.analyze(sf, _sf_levels(), mvp)[0]
        parts.append(pd.DataFrame({"일시": a["date_create"].dt.tz_localize(None), "캐릭터": a["character_name"],
                                   "장비": a["target_item"], "종류": "스타포스", "메소": a["비용"]}))
    for kind in ("cube", "potential", "soul-potential"):
        h, _ = load_history(kind)
        if h.empty:
            continue
        h = h.copy()
        if "cube_type" not in h:
            h["cube_type"] = h.get("potential_type", "소울 재설정" if kind == "soul-potential" else "잠재능력 재설정")
        h["date_create"] = pd.to_datetime(h["date_create"], format="ISO8601").dt.tz_localize(None)
        h = cube_spend.enrich(h, cube_spend.load_prices(), mp_per_eok)
        parts.append(pd.DataFrame({"일시": h["date_create"], "캐릭터": h["character_name"], "장비": h["target_item"],
                                   "종류": h["cube_type"], "메소": h["메소 환산"]}))
    if not parts:
        return pd.DataFrame(columns=["일시", "캐릭터", "장비", "종류", "분류", "메소"])
    out = pd.concat(parts, ignore_index=True)
    out["분류"] = out["종류"].map(SPEND_GROUPS).fillna("큐브")
    return out


def spend_section(mm_buy: float) -> None:
    """메소 tab: where the meso went since the Reboot -> Eos move (2026-09-28 user: "리부트 -> 에오스 되고 얼마 쓰고
    어디에 썼는지"). Sums the 스타포스 and 큐브 tabs; no API calls of its own."""
    st.subheader("강화에 쓴 메소", help="스타포스 · 큐브 · 메소 재설정 기록을 합친 값입니다. 계산은 스타포스 탭 · 큐브 탭과 같습니다. "
                 "스타포스는 스타포스 탭에서 고른 MVP 할인을 따릅니다.")
    firsts = [load_history(k)[1][1] for k in ("starforce", "cube", "potential")]
    backfill_note(max(firsts))
    sp = spend_frame(st.session_state.get("sf_mvp") or "없음", float(mk["meso_market_mp_per_eok"]["value"]))
    if sp.empty:
        st.info("아직 강화 기록이 없습니다.")
        return
    _pb = st.container(horizontal=True, gap="large", vertical_alignment="bottom")
    s0, s1 = period_picker(_pb, "spend_period", sp["일시"].min().date())
    who = _pb.multiselect("캐릭터", main_first(sp["캐릭터"].dropna().unique()), key="spend_who", placeholder="전체 캐릭터")
    v = sp[(sp["일시"].dt.date >= s0) & (sp["일시"].dt.date <= s1)]
    v = v[v["캐릭터"].isin(who)] if who else v
    priced = v.dropna(subset=["메소"])
    tot = float(priced["메소"].sum())
    by_group = priced.groupby("분류")["메소"].sum()
    r = MetricRow()
    r.metric("합계", f"{tot / 1e8:,.1f} 억", icon=":material/savings:",
             delta=f"{tot / 1e8 * mm_buy:,.0f}원 (메소마켓)" if mm_buy else None, delta_color="off",
             help=f"{s0} ~ {s1}. 스타포스 비용을 모르는 시도(강화권 · 렙제 모름) {len(v) - len(priced):,}회는 빠짐")
    for g, ic in (("스타포스", ":material/star:"), ("큐브", ":material/casino:"), ("메소 재설정", ":material/autorenew:")):
        m = float(by_group.get(g, 0.0))
        r.metric(g, f"{m / 1e8:,.1f} 억", icon=ic, delta=f"{m / tot * 100:.0f}%" if tot else None, delta_color="off",
                 help=f"{(v['분류'] == g).sum():,}회")
    st.caption(f"{s0} ~ {s1} 기록 {len(v):,}건. 계정 전체 기록이라 리부트 캐릭터도 섞여 있으면 캐릭터로 고르세요.")

    group = st.segmented_control("어디에", ["캐릭터", "장비", "종류", "월"], default="캐릭터", key="spend_group",
                                 label_visibility="collapsed") or "캐릭터"
    key = group  # the grouping label is also the column name
    vv = priced.assign(월=priced["일시"].dt.strftime("%Y-%m"))
    tb = vv.pivot_table(index=key, columns="분류", values="메소", aggfunc="sum", fill_value=0.0) / 1e8
    tb.columns = [f"{c} (억)" for c in tb.columns]
    tb.insert(0, "합계 (억)", tb.sum(axis=1))
    tb.insert(1, "횟수", vv.groupby(key).size())
    tb.insert(2, "비중", tb["합계 (억)"] / tb["합계 (억)"].sum() * 100 if tb["합계 (억)"].sum() else 0.0)
    tb = tb.sort_index(ascending=False) if group == "월" else tb.sort_values("합계 (억)", ascending=False)
    tb = tb.reset_index()
    if group == "장비":
        tb.insert(0, "그림", tb["장비"].map(ICONS))
    elif group == "캐릭터":
        tb.insert(0, "그림", tb["캐릭터"].map(CHAR_IMG))
    elif group == "종류":
        tb.insert(0, "그림", [cube_icon(t) if t != "스타포스" else None for t in tb["종류"]])
    if mm_buy:
        tb["현금 (원)"] = tb["합계 (억)"] * mm_buy
    cols = {c: st.column_config.NumberColumn(format="%,.2f") for c in tb.columns if c.endswith("(억)")}
    st.dataframe(tb, hide_index=True, width="stretch", row_height=40, height=min(560, 40 + 41 * len(tb)),
                 column_config=cols | {"그림": st.column_config.ImageColumn(" ", width="small"),
                                       "비중": st.column_config.ProgressColumn("비중", format="%.0f%%", min_value=0,
                                                                              max_value=100, color="primary"),
                                       "현금 (원)": st.column_config.NumberColumn(format="%,d")})

    monthly = vv.groupby(["월", "분류"])["메소"].sum().reset_index()
    monthly["억"] = monthly["메소"] / 1e8
    st.altair_chart(alt.Chart(monthly).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
        x=alt.X("월:N", title=None, sort=None, axis=alt.Axis(labelAngle=0)),
        y=alt.Y("억:Q", title=None),
        color=alt.Color("분류:N", title=None, legend=alt.Legend(orient="top")),
        tooltip=["월:N", "분류:N", alt.Tooltip("억:Q", format=",.2f")],
    ).properties(title="월별 강화에 쓴 메소 (억)", height=260), width="stretch")
    st.divider()


with tab_meso:
    if tab_meso.open or ALL_TABS:
        mm_buy = market.meso_to_won(market.EOK, mk)          # 원 per 1억 via 메소마켓
        cash = mk["cash_won_per_eok"]["value"]              # 원 per 1억 in cash trades
        has_mm, has_cash = mm_buy > 0, cash > 0

        spend_section(mm_buy)

        st.subheader("메소 ↔ 현금")
        r1, r2 = st.columns(2)
        for col, field, label, fmt in [
                (r1, "meso_market_mp_per_eok", "에오스 메소마켓 (1억 = ? 메포)", "{:,.0f}"),
                (r2, "cash_won_per_eok", "현금 거래 (1억 = ? 원)", "{:,.0f}")]:
            e = mk[field]
            col.text_input(label, value=fmt.format(e["value"]), key=f"rate_{field}",
                           on_change=_save_rate, args=(field,),
                           help=f"바꾸면 바로 저장됩니다. 마지막 입력일: {e['date'] or '없음'}")
        if st.session_state.pop("rate_error", None) is not None:
            st.error("시세를 숫자로 읽을 수 없습니다. 1250 / 1,250 처럼 적으세요.")

        with st.container(border=True):
            mode = st.segmented_control("계산", ["메소 → 원", "원 → 메소"], default="메소 → 원",
                                        key="conv_mode", label_visibility="collapsed") or "메소 → 원"
            if mode == "메소 → 원":
                txt = st.text_input("살 메소 (억)", value="10", key="conv_eok",
                                    help="10 = 10억. '5억 3000만' 처럼 단위를 붙여도 됩니다.")
                try:
                    eok = _parse_eok(txt) / market.EOK
                except ValueError:
                    st.error("숫자로 읽을 수 없습니다.")
                    eok = 0.0
                c1, c2 = st.columns(2)
                c1.metric("메소마켓으로 사면", f"{eok * mm_buy:,.0f} 원" if has_mm else "시세 미입력",
                          help=f"{eok:,.2f}억 × {mk['meso_market_mp_per_eok']['value']:,.0f} 메포 "
                               f"× 메포 1점 {mk['won_per_mp']['value']:g}원")
                c2.metric("현금 거래로 사면", f"{eok * cash:,.0f} 원" if has_cash else "시세 미입력",
                          delta=f"{eok * (cash - mm_buy):+,.0f} 원 (메소마켓 대비)" if has_mm and has_cash else None,
                          delta_color="inverse")
            else:
                txt = st.text_input("쓸 현금 (원)", value="10,000", key="conv_won")
                try:
                    won = market.parse_amount(txt)
                except ValueError:
                    st.error("숫자로 읽을 수 없습니다.")
                    won = 0.0
                c1, c2 = st.columns(2)
                c1.metric("메소마켓으로 사면", f"{won / mm_buy:,.2f} 억" if has_mm else "시세 미입력")
                c2.metric("현금 거래로 사면", f"{won / cash:,.2f} 억" if has_cash else "시세 미입력")
            if has_mm or has_cash:
                rows = [1, 5, 10, 50, 100]
                quick = pd.DataFrame({"메소": [f"{r}억" for r in rows]})
                if has_mm:
                    quick["메소마켓 (원)"] = [r * mm_buy for r in rows]
                if has_cash:
                    quick["현금 거래 (원)"] = [r * cash for r in rows]
                st.dataframe(quick, hide_index=True, width="stretch", column_config={
                    c: st.column_config.NumberColumn(format="%,d") for c in ["메소마켓 (원)", "현금 거래 (원)"]})

        # 2026-09-28 user: "580억이 필요한데 경매장 거래, 수수료 3%, 850원/억이면 얼마 결제?" (fee comes out of the price)
        with st.container(border=True):
            st.markdown("**경매장으로 받을 때 (수수료 포함)**")
            a1, a2, a3 = st.columns(3)
            need_txt = a1.text_input("손에 남아야 할 메소 (억)", value="100", key="auc_need",
                                     help="580 = 580억. '5억 3000만' 처럼 단위를 붙여도 됩니다.")
            auc_fee = a2.segmented_control("경매장 수수료", ["3%", "5%"], default="3%", key="auc_fee",
                                           help="MVP 실버 이상 또는 PC방이면 3%, 아니면 5%") or "3%"
            rate_default = cash if has_cash else mm_buy
            rate_txt = a3.text_input("1억 = ? 원", value=f"{rate_default:,.0f}" if rate_default else "",
                                     key=f"auc_rate_{rate_default:.0f}",
                                     help="처음 값은 위의 현금 거래 시세(없으면 메소마켓). 여기서 바꾼 값은 저장하지 않습니다.")
            try:
                need = _parse_eok(need_txt) / market.EOK
                auc_rate = market.parse_amount(rate_txt) if rate_txt.strip() else 0.0
            except ValueError:
                st.error("숫자로 읽을 수 없습니다.")
                need, auc_rate = 0.0, 0.0
            fee_v = int(auc_fee.rstrip("%")) / 100
            gross = market.auction_gross(need, fee_v)
            listing = math.ceil(gross * 100 - 1e-9) / 100  # 100만 메소 단위로 올림
            b1, b2, b3 = st.columns(3)
            b1.metric("경매장에 올릴 가격", f"{listing:,.2f} 억", help=f"{need:,.2f}억 ÷ (1 - {fee_v:.0%}), 100만 단위 올림")
            b2.metric("수수료", f"{listing * fee_v:,.2f} 억", help=f"받는 쪽 손에 남는 메소 {listing * (1 - fee_v):,.2f}억")
            b3.metric("결제할 금액", f"{listing * auc_rate:,.0f} 원" if auc_rate else "시세 미입력",
                      help=f"{listing:,.2f}억 × {auc_rate:,.0f}원" if auc_rate else None)
            if need:
                naive = need * (1 + fee_v)
                st.caption(f"수수료는 판매가에서 빠지므로 (1 - 수수료)로 나눕니다. {need:,.0f}억 × {1 + fee_v:g} = {naive:,.2f}억으로 "
                           f"올리면 {naive * (1 - fee_v):,.2f}억만 남아 {need - naive * (1 - fee_v):,.2f}억이 모자랍니다.")
        st.caption("현금 거래는 넥슨 약관상 제재 대상이라 참고용 직접 입력입니다. 다른 탭의 '현금 환산'은 메소마켓 기준입니다.")

        with st.expander("세부 설정: 메포 실구매가 · 수수료 · 충전 할인 · 챌린저스 · 솔 에르다 조각"):
            fmt = {"won_per_mp": "{:,.2f}", "market_fee_pct": "{:g}", "sol_erda_piece_meso": "{:,.0f}",
                   "meso_market_mp_per_eok_ch": "{:,.0f}", "charge_discount_pct": "{:g}"}
            with st.form("market"):
                raw = {}
                for k in fmt:
                    e = mk[k]
                    raw[k] = st.text_input(market.FIELDS[k], value=fmt[k].format(e["value"]),
                                           help=f"마지막 입력일: {e['date'] or '없음'}")
                if st.form_submit_button("저장", type="primary"):
                    try:
                        market.save({k: market.parse_amount(v) for k, v in raw.items()})
                    except ValueError as err:
                        st.error(f"숫자로 읽을 수 없는 값: {err}")
                    else:
                        st.cache_data.clear()
                        st.rerun()
            if has_mm:
                mm_sell = market.meso_to_won(market.EOK, mk, selling=True)
                st.caption(f"메소마켓에 1억을 팔면 수수료 빼고 {mm_sell:,.0f} 원어치 메포.")

        with st.expander("아이템 가격 → 현금"):
            unit = st.segmented_control("새 줄 기본 단위", list(market.UNITS), default="억", key="item_unit")
            base = pd.DataFrame(market.load_items(), columns=["아이템", "가격", "단위", "개수"])
            edited = st.data_editor(
                base, num_rows="dynamic", hide_index=True, width="stretch", key="items_editor",
                column_config={
                    "아이템": st.column_config.TextColumn(required=True),
                    "가격": st.column_config.NumberColumn(min_value=0.0, format="localized", required=True),
                    "단위": st.column_config.SelectboxColumn(options=list(market.UNITS), default=unit or "억",
                                                           required=True),
                    "개수": st.column_config.NumberColumn(min_value=1, step=1, default=1, format="localized"),
                })
            b1, b2 = st.columns(2)
            if b1.button("목록 저장", width="stretch"):
                rows = edited.dropna(subset=["아이템", "가격"]).fillna({"단위": "억", "개수": 1})
                market.save_items([{"아이템": str(r.아이템), "가격": float(r.가격), "단위": str(r.단위),
                                    "개수": int(r.개수)} for r in rows.itertuples()])
                st.toast(f"{len(rows)}개 저장")
            if b2.button("목록 비우기", width="stretch"):
                market.save_items([])
                st.session_state.pop("items_editor", None)
                st.rerun()
            v = edited.dropna(subset=["가격"]).copy()
            if v.empty:
                st.caption("표 맨 아래 빈 줄을 눌러 아이템 이름 · 가격을 적으세요.")
            elif has_mm or has_cash:
                v["단위"] = v["단위"].fillna(unit or "억")
                v["개수"] = v["개수"].fillna(1)
                v["메소 (억)"] = v["가격"] * v["단위"].map(market.UNITS) * v["개수"] / market.EOK
                if has_mm:
                    v["메소마켓 (원)"] = v["메소 (억)"] * mm_buy
                if has_cash:
                    v["현금 거래 (원)"] = v["메소 (억)"] * cash
                show = [c for c in ["아이템", "메소 (억)", "메소마켓 (원)", "현금 거래 (원)"] if c in v]
                st.dataframe(v[show], hide_index=True, width="stretch", column_config={
                    "메소 (억)": st.column_config.NumberColumn(format="%,.2f"),
                    **{c: st.column_config.NumberColumn(format="%,d") for c in ["메소마켓 (원)", "현금 거래 (원)"]}})
                tot = v["메소 (억)"].sum()
                pieces = market.sol_erda_pieces(tot * market.EOK, mk)
                st.caption(f"합계 {tot:,.2f}억 = 메소마켓 {tot * mm_buy:,.0f}원 · 현금 거래 {tot * cash:,.0f}원"
                           + (f" · 솔 에르다 조각 {pieces:,.0f}개" if pieces else ""))

        # ---------- MVP (엠작) ----------
        with st.expander("엠작 계산기"):
            st.caption("캐시템을 사서 경매장에 되팔아 MVP 실적은 쌓고 실부담은 줄이는 계산. "
                       "같은 캐시로 메포를 사서 메소마켓에서 메소를 사도 실적이 쌓이므로, "
                       "캐시템은 '손익분기 판매가'보다 비싸게 팔릴 때만 이득입니다. 시세는 서버마다 따로 넣으세요.")
            e1, e2, e3, e4 = st.columns(4)
            server = e1.segmented_control("서버", ["에오스", "챌린저스"], default="에오스", key="mvp_server") or "에오스"
            fee_pct = e2.segmented_control("경매장 수수료", ["3%", "5%"], default="3%", key="mvp_fee",
                                           help="MVP 실버 이상 또는 PC방이면 3%, 아니면 5%") or "3%"
            have = e3.number_input("현재 13주 누적 (캐시)", min_value=0, value=0, step=10_000, key="mvp_have")
            goal = e4.selectbox("목표 등급", list(market.MVP_GRADES), index=3, key="mvp_goal",
                                format_func=lambda g: f"{g} ({market.MVP_GRADES[g]:,})")
            rate = market.mp_per_eok(mk, server)
            fee = int(fee_pct.rstrip("%")) / 100
            disc = mk["charge_discount_pct"]["value"] / 100
            wpm = mk["won_per_mp"]["value"]
            if rate <= 0:
                st.info("위 시세 입력에서 메소마켓 시세를 먼저 넣으세요.")
            else:
                st.caption(f"{server} 메소마켓 1억 = {rate:,.0f} 메포, 충전 할인 {disc:.0%}. "
                           f"1만 캐시짜리 손익분기 판매가 = {10000 / rate / (1 - fee):,.2f} 억")
                mv_base = pd.DataFrame(market.load_mvp_items(), columns=["아이템", "캐시 가격", "수량", "경매장 판매가 (억)"])
                mv = st.data_editor(
                    mv_base, num_rows="dynamic", hide_index=True, width="stretch", key="mvp_editor",
                    column_config={
                        "아이템": st.column_config.TextColumn(required=True, help="로얄 스타일, 원더베리, 마스터피스 등"),
                        "캐시 가격": st.column_config.NumberColumn(min_value=0, format="localized", required=True),
                        "수량": st.column_config.NumberColumn(min_value=1, step=1, default=1),
                        "경매장 판매가 (억)": st.column_config.NumberColumn(min_value=0.0, format="%.2f",
                                                                      help="모르면 비워 두면 손익분기만 계산"),
                    })
                f1, f2 = st.columns(2)
                if f1.button("엠작 목록 저장", width="stretch"):
                    keep = mv.dropna(subset=["아이템", "캐시 가격"]).fillna({"수량": 1})
                    market.save_mvp_items([{"아이템": str(r.아이템), "캐시 가격": float(r[2]), "수량": int(r[3]),
                                            "경매장 판매가 (억)": None if pd.isna(r[4]) else float(r[4])}
                                           for r in keep.itertuples()])
                    st.toast(f"{len(keep)}개 저장")
                if f2.button("엠작 목록 비우기", width="stretch"):
                    market.save_mvp_items([])
                    st.session_state.pop("mvp_editor", None)
                    st.rerun()
                mvv = mv.dropna(subset=["캐시 가격"]).copy()
                need = max(0, market.MVP_GRADES[goal] - have)
                if mvv.empty:
                    st.info(f"{goal}까지 남은 실적 {need:,} 캐시. 표에 캐시템을 적으면 손익분기와 실부담이 나옵니다.")
                else:
                    mvv["수량"] = mvv["수량"].fillna(1)
                    sell = mvv["경매장 판매가 (억)"].fillna(0)
                    res = pd.DataFrame([market.mvp_row(c, q, sp, rate, fee, disc, wpm)
                                        for c, q, sp in zip(mvv["캐시 가격"], mvv["수량"], sell)], index=mvv.index)
                    out = pd.concat([mvv[["아이템", "수량"]], res], axis=1)
                    out.loc[sell == 0, ["회수 메소 (억)", "회수율", "실부담 (원)"]] = None
                    out["판정"] = [("판매가 미입력" if s == 0 else ("캐시템이 이득" if s >= be else "메소마켓이 이득"))
                                 for s, be in zip(sell, out["손익분기 판매가 (억)"])]
                    st.dataframe(out, hide_index=True, width="stretch", column_config={
                        "캐시 합계": st.column_config.NumberColumn(format="%,d"),
                        "손익분기 판매가 (억)": st.column_config.NumberColumn(format="%,.2f"),
                        "회수 메소 (억)": st.column_config.NumberColumn(format="%,.2f"),
                        "회수율": st.column_config.NumberColumn(format="percent"),
                        "실부담 (원)": st.column_config.NumberColumn(format="%,d")})
                    cash_sum = float(out["캐시 합계"].sum())
                    sold = out["실부담 (원)"].notna()
                    burden = float(out.loc[sold, "실부담 (원)"].sum())
                    g1 = g2 = g3 = g4 = MetricRow()
                    g1.metric("표의 실적 합계", f"{cash_sum:,.0f} 캐시")
                    g2.metric(f"{goal}까지 남은 실적", f"{max(0, need - cash_sum):,.0f} 캐시",
                              delta="달성" if cash_sum >= need else None, delta_color="off")
                    g3.metric("실부담 합계 (판매가 적은 것만)", f"{burden:,.0f} 원" if sold.any() else "-")
                    g4.metric("1만 캐시 실적당 실부담",
                              f"{burden / out.loc[sold, '캐시 합계'].sum() * 10000:,.0f} 원" if sold.any() else "-")
                st.caption("MVP 기준: 당주 포함 최근 13주 넥슨캐시 결제액, 마일리지 할인분 제외. 블랙 250만은 2026-09-17 공식 "
                           "패치노트 813, 나머지는 나무위키 2026-09-10 기준. 유저 간 선물식 엠작은 사기 위험이 있어 넣지 않았습니다.")

# ---------- spec ----------
with tab_spec:
    if tab_spec.open or ALL_TABS:
        latest = basic.sort_values("date").groupby("ocid").tail(1)
        st_latest = stat.sort_values("date").groupby("ocid").tail(1).set_index("ocid")
        # combat power swings with buffs/preset at save time (09-16 vs 09-17: 1.6억 vs 3.7억),
        # so the spec view uses the max of the last 7 stored days
        cp7 = stat.copy()
        cp7["cp"] = cp7["data"].map(lambda s: stat_value(s, "전투력"))
        cp7 = cp7[pd.to_datetime(cp7["date"]) >= pd.Timestamp(db.now_kst().date()) - pd.Timedelta(days=7)]
        cp7 = cp7.groupby("ocid")["cp"].max()
        rows = []
        for _, r in latest.iterrows():
            b = r["data"]
            if b.get("character_level") is None:
                continue
            s = st_latest["data"].get(r["ocid"], {}) if r["ocid"] in st_latest.index else {}
            rows.append({"이미지": b.get("character_image"), "캐릭터": b["character_name"],
                         "직업": b["character_class"], "레벨": b["character_level"],
                         "경험치 %": float(b.get("character_exp_rate") or 0),
                         "전투력": cp7.get(r["ocid"]), "전투력(최신)": stat_value(s, "전투력"), "스타포스": stat_value(s, "스타포스"),
                         "아케인": stat_value(s, "아케인포스"), "어센틱": stat_value(s, "어센틱포스"),
                         "기준일": r["date"]})
        spec = pd.DataFrame(rows).sort_values("전투력", ascending=False)
        spec = spec.sort_values("캐릭터", key=lambda c: c != MAIN, kind="stable")  # main first, then by 전투력
        spec["캐릭터"] = [f"★ {n}" if n == MAIN else n for n in spec["캐릭터"]]
        spec["이미지"] = [CHAR_IMG.get(n.removeprefix("★ "), u) for n, u in zip(spec["캐릭터"], spec["이미지"])]

        # one character's full spec (2026-09-27 user: 유니온 · 헥사 · 어빌 · 하이퍼 등 스펙 수단 전부, 아이콘으로)
        sp_names = main_first(spec["캐릭터"].str.removeprefix("★ "))
        sp_who = st.pills("캐릭터", sp_names, default=sp_names[0], key="spec_who") or sp_names[0]
        sp = spec_view.load(sp_who)
        sp_row = spec[spec["캐릭터"].str.removeprefix("★ ") == sp_who].iloc[0]
        _jr = job_view.job_row(sp_row["직업"])  # main stat per class from ref/jobs (was hard-coded for 키네시스 only)
        sp_main = str(_jr["scouter_main"]) if _jr is not None else "INT"
        with st.container(border=True):
            prof = st.container(horizontal=True, gap="large", vertical_alignment="center")
            if CHAR_IMG.get(sp_who):
                prof.image(CHAR_IMG[sp_who], width=110)
            info = prof.container(width="stretch")
            un = sp.get("union") or {}
            dj = sp.get("dojang") or {}
            info.markdown(f"### {'★ ' if sp_who == MAIN else ''}{sp_who}  \n"
                          f":gray-badge[{sp_row['직업']}] :orange-badge[Lv.{sp_row['레벨']}]"
                          + (f" :violet-badge[유니온 {un.get('union_level', 0):,}]" if un else "")
                          + (f" :blue-badge[무릉 {dj.get('dojang_best_floor')}층]" if dj.get("dojang_best_floor") else ""))
            info.progress(min(1.0, sp_row["경험치 %"] / 100), text=f"경험치 {sp_row['경험치 %']:.3f}%")
            info.caption(f"전투력 (최근 7일 최고) {spec_view.eok_man(sp_row['전투력'])}" if pd.notna(sp_row["전투력"]) else "")
            # badges as pictures: job icon, world emblem, union grade (ref/icons_extra, 2026-09-27)
            emb = prof.container(horizontal=True, gap="medium", width="content", vertical_alignment="center")
            for cat, name, cap in (("job_icon", sp_row["직업"], sp_row["직업"]), ("world", cfg["world"], cfg["world"]),
                                   ("union_grade", str(un.get("union_grade", "")), str(un.get("union_grade", "")))):
                pic = _ix.extra_icon(cat, name)
                if pic:
                    with emb.container(width=76, horizontal_alignment="center", gap="xxsmall"):
                        st.image(pic, width=44)
                        st.caption(cap)
        t_stat, t_job, t_hexa, t_sym, t_abil, t_union, t_link, t_all, t_jobs = st.tabs(
            [":material/bar_chart: 스탯", ":material/school: 직업 · 효율", ":material/hexagon: 헥사 · V",
             ":material/auto_awesome: 심볼", ":material/psychology: 어빌 · 하이퍼", ":material/groups: 유니온",
             ":material/link: 링크 · 세트", ":material/table_rows: 전체 캐릭터", ":material/diversity_3: 전 직업"], on_change="rerun")
        with t_job:  # job reference + stat efficiency (job_view.py, 2026-09-27)
            if t_job.open or ALL_TABS:
                job_view.render(sp_who, sp_row["직업"], int(sp_row["레벨"]), sp, MetricRow, sp_who == MAIN)
        with t_jobs:
            if t_jobs.open or ALL_TABS:
                job_view.all_jobs_section()
        with t_stat:
            if t_stat.open or ALL_TABS:
                spec_view.stats_section(sp.get("stat") or {}, sp_main, MetricRow)
        with t_hexa:
            if t_hexa.open or ALL_TABS:
                spec_view.hexa_section(sp.get("hexamatrix"), sp.get("hexamatrix-stat"), sp.get("skill-6"),
                                       sp.get("vmatrix"), sp.get("skill-5"),
                                       fragment_meso=mk["sol_erda_piece_meso"]["value"], row_factory=MetricRow)
        with t_sym:
            if t_sym.open or ALL_TABS:
                spec_view.symbol_section(sp.get("symbol-equipment"), MetricRow)
        with t_abil:
            if t_abil.open or ALL_TABS:
                spec_view.ability_hyper_section(sp.get("ability"), sp.get("hyper-stat"))
        with t_union:
            if t_union.open or ALL_TABS:
                spec_view.union_section(sp.get("union"), sp.get("union-raider"), sp.get("union-artifact"),
                                        sp.get("union-champion"), CHAR_IMG, MetricRow)
        with t_link:
            if t_link.open or ALL_TABS:
                spec_view.link_set_section(sp.get("link-skill"), sp.get("set-effect"))
        with t_all:
            if t_all.open or ALL_TABS:
                c1 = c2 = c3 = MetricRow()
                c1.metric("캐릭터 수", len(spec))
                c2.metric("최고 전투력", f"{spec['전투력'].max():,.0f}")
                c3.metric("전투력 합계", f"{spec['전투력'].sum():,.0f}")
                st.dataframe(spec, hide_index=True, width="stretch", row_height=48, column_config={
                    "이미지": st.column_config.ImageColumn(" ", width="small"),
                    "전투력": st.column_config.NumberColumn("전투력(7일 최고)", format="%,d"),
                    "전투력(최신)": st.column_config.NumberColumn(format="%,d"),
                    "경험치 %": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.2f%%")})
        st.caption("스펙 정보는 '지금 갱신' 을 누른 시점의 상태입니다(넥슨 반영 평균 15분).")

# ---------- equipment ----------
with tab_equip:
    if tab_equip.open or ALL_TABS:
        GRADE_COLOR = {"레전드리": "green", "유니크": "orange", "에픽": "violet", "레어": "blue"}
        GRADE_ABBR = {"레전드리": "레전", "유니크": "유니크", "에픽": "에픽", "레어": "레어"}  # was L/U/E/R (UI 점검)
        eq_names = main_first([n for n in basic["name"].unique()])
        _bar = st.container(horizontal=True, gap="large", vertical_alignment="bottom")
        f1 = f2 = _bar
        who = f1.pills("캐릭터", eq_names, default=eq_names[0], key="eq_who") or eq_names[0]
        try:
            eqd = equip.load(who)
        except AssertionError:
            eqd = None
            st.info("이 캐릭터의 장비 정보가 아직 수집되지 않았습니다.")
        if eqd:
            CLASS_MAIN = {"키네시스": "INT"}
            main_stat = f2.segmented_control("주스탯", ["STR", "DEX", "INT", "LUK"], default=CLASS_MAIN.get(eqd["class"], "INT"),
                                             key=f"eq_main_{who}") or "INT"
            preset = st.segmented_control(
                "프리셋", [1, 2, 3], default=eqd["preset_no"], key=f"eq_preset_{who}",
                format_func=lambda p: f"프리셋 {p}" + (" (착용 중)" if p == eqd["preset_no"] else "")) or eqd["preset_no"]
            ef = equip.frame(eqd["presets"][preset], main_stat)
            c1 = c2 = c3 = c4 = MetricRow()
            c1.metric(f"{main_stat}% 합 (윗잠 + 에디)", f"{ef['main_pct'].sum():,.0f}%", border=True, icon=":material/person:")
            c2.metric("드롭 (윗잠 + 에디)", f"{ef['drop'].sum():.0f}%", border=True, icon=":material/redeem:")
            c3.metric("메획 (윗잠 + 에디)", f"{ef['meso'].sum():.0f}%", border=True, icon=":material/savings:")
            c4.metric("22성 이상", f"{(ef['star'] >= 22).sum()} / {len(ef)}개", border=True, icon=":material/star:")
            st.caption(f"{who} · {eqd['class']} · 수집일 {eqd['date']}. 주스탯%는 윗잠 · 에디의 {main_stat}% 와 올스탯% 를 더한 값입니다.")

            ADD_KO = {"str": "STR", "dex": "DEX", "int": "INT", "luk": "LUK", "max_hp": "HP", "attack_power": "공격력",
                      "magic_power": "마력", "boss_damage": "보스 데미지", "damage": "데미지", "all_stat": "올스탯"}
            sub_win, sub_list, sub_log, sub_deme = st.tabs([":material/grid_view: 장비창", ":material/list: 목록",
                                                            ":material/history: 스펙업 기록", ":material/redeem: 드메 세팅"], on_change="rerun")
            with sub_win:
                if sub_win.open or ALL_TABS:
                    _row = st.container(horizontal=True, gap="medium")
                    left = _row.container(width=372)  # 5 x 58px tiles + padding; right side wraps below when narrow
                    right = _row.container(width="stretch")
                    with left:
                        sel = ui_components.equip_window(ef.to_dict("records"), key=f"eqwin_{who}_{preset}")
                        st.caption("칸을 누르면 오른쪽에 아이템 정보가 나옵니다. 테두리 색 = 윗잠 등급.")
                    with right:
                        r = ef[ef["slot"] == sel].iloc[0].to_dict() if sel in set(ef["slot"]) else None
                        if r:
                            with st.container(border=True):
                                a, b = st.columns([1, 5], vertical_alignment="center")
                                if r["icon"]:
                                    a.image(r["icon"], width=48)
                                chips = [f":orange-badge[★ {r['star']}성]"] if r["star"] else []
                                chips += [f":{GRADE_COLOR.get(r[g], 'gray')}-badge[{lab} {r[g]}]"
                                          for g, lab in (("pot_grade", "윗잠"), ("add_grade", "에디")) if isinstance(r[g], str)]
                                b.markdown(f"**{r['name']}**  \n" + " ".join(chips))
                                st.caption(f"{r['slot']} · {r['level']}제" + (f" · 주문서 {r['scroll']}회" if r["scroll"] else "")
                                           + (f" · 가위 {r['cut']}회 남음" if str(r["cut"]) not in ("None", "0", "255") else ""))
                                p1, p2 = st.columns(2)
                                p1.markdown("**윗잠**  \n" + ("  \n".join(r["pot"]) if r["pot"] else "없음"))
                                p2.markdown("**에디**  \n" + ("  \n".join(r["add"]) if r["add"] else "없음"))
                                ao = r["add_option"] or {}
                                adds = [f"{ADD_KO[k]} +{v}{'%' if k in ('all_stat', 'boss_damage', 'damage') else ''}"
                                        for k, v in ao.items() if k in ADD_KO and str(v) not in ("0", "", "None")]
                                st.markdown("**추옵**  \n" + (" · ".join(adds) if adds else "없음"))
                                summ = []
                                if r["atk_pct"]:
                                    summ.append(f"{'마' if main_stat == 'INT' else '공'} {r['atk_pct']:g}%")
                                if r["main_pct"]:
                                    summ.append(f"{main_stat} {r['main_pct']:g}%")
                                if r["drop"]:
                                    summ.append(f"드롭 {r['drop']:g}%")
                                if r["meso"]:
                                    summ.append(f"메획 {r['meso']:g}%")
                                if summ:
                                    st.caption("윗잠 · 에디 합: " + " · ".join(summ))
            with sub_list:
                if sub_list.open or ALL_TABS:
                    lst = ef.assign(
                        잠재=ef["pot_grade"].map(lambda g: GRADE_ABBR.get(g, "") if isinstance(g, str) else ""),
                        에디=ef["add_grade"].map(lambda g: GRADE_ABBR.get(g, "") if isinstance(g, str) else ""),
                        잠재옵션=ef["pot"].map(lambda x: " / ".join(x)), 에디옵션=ef["add"].map(lambda x: " / ".join(x)))
                    cols_eq = ["icon", "slot", "name", "star", "잠재", "에디", "main_pct", "atk_pct", "drop", "meso", "scroll",
                               "잠재옵션", "에디옵션"]
                    cols_eq = [c for c in cols_eq if c not in ("drop", "meso") or lst[c].fillna(0).any()]  # hide all-0 드롭 · 메획
                    st.dataframe(lst[cols_eq]
                                 .rename(columns={"icon": " ", "slot": "부위", "name": "아이템", "star": "성",
                                                  "main_pct": f"{main_stat}%", "atk_pct": "공마%", "drop": "드롭", "meso": "메획",
                                                  "scroll": "작"}),
                                 hide_index=True, width="stretch", row_height=34, height="content",
                                 column_config={" ": st.column_config.ImageColumn(width="small"),
                                                "성": st.column_config.NumberColumn(format="★%d", width="small"),
                                                f"{main_stat}%": st.column_config.NumberColumn(format="%g%%", width="small"),
                                                "공마%": st.column_config.NumberColumn(format="%g%%", width="small"),
                                                "드롭": st.column_config.NumberColumn(format="%g%%", width="small"),
                                                "메획": st.column_config.NumberColumn(format="%g%%", width="small"),
                                                "작": st.column_config.NumberColumn(width="small")})

            with sub_log:
                if sub_log.open or ALL_TABS:
                    # 스펙업 기록 (2026-09-27): changes between daily snapshots; prices typed by the user (no auction API)
                    log = _spec_changes(who, main_stat)  # cached: rebuilds every stored snapshot (~4 s)
                    prices = spec_log.load_prices()
                    if not log:
                        st.info("아직 바뀐 장비가 없습니다. 장비 정보는 매일 저장한 날끼리 비교합니다.")
                    else:
                        spent = sum(float((prices.get(e["key"]) or {}).get("eok") or 0) for e in log)
                        gain = sum(e["d_main"] for e in log)
                        c1 = c2 = c3 = MetricRow()
                        c1.metric("기록된 스펙업", f"{len(log)}건", icon=":material/history:")
                        c2.metric(f"{main_stat}% 변화 합", f"{gain:+g}%p", icon=":material/trending_up:")
                        c3.metric("적어 둔 비용 합", f"{spent:,.1f} 억", icon=":material/savings:",
                                  help="아래 표의 '산 가격 (억)' 칸에 적은 값의 합")
                        rows = []
                        for e in log:
                            pr = prices.get(e["key"]) or {}
                            b, a = e["before"], e["after"]
                            rows.append({"key": e["key"], "날짜": e["date"], "부위": e["slot"],
                                         "전": b["icon"], "이전": f"{b['name']} ★{b['star']}", "후": a["icon"],
                                         "이후": f"{a['name']} ★{a['star']}", "변화": " · ".join(e["kinds"]),
                                         f"{main_stat}%": e["d_main"], "공마%": e["d_atk"],
                                         "프리셋": ",".join(str(x) for x in sorted(e["presets"])),
                                         "산 가격 (억)": pr.get("eok"), "메모": pr.get("memo") or ""})
                        df = pd.DataFrame(rows)
                        ed = st.data_editor(
                            df, hide_index=True, width="stretch", row_height=40, key=f"speclog_{who}",
                            disabled=[c for c in df.columns if c not in ("산 가격 (억)", "메모")],
                            column_order=[c for c in df.columns if c != "key"],
                            column_config={"전": st.column_config.ImageColumn(" ", width="small"),
                                           "후": st.column_config.ImageColumn(" ", width="small"),
                                           f"{main_stat}%": st.column_config.NumberColumn(format="%+g%%p", width="small"),
                                           "공마%": st.column_config.NumberColumn(format="%+g%%p", width="small"),
                                           "산 가격 (억)": st.column_config.NumberColumn(min_value=0.0, format="%,.1f"),
                                           "메모": st.column_config.TextColumn(width="medium")})
                        if st.button("가격 · 메모 저장", key=f"speclog_save_{who}", icon=":material/save:"):
                            for r in ed.to_dict("records"):
                                if pd.notna(r["산 가격 (억)"]) or r["메모"]:
                                    prices[r["key"]] = {"eok": None if pd.isna(r["산 가격 (억)"]) else float(r["산 가격 (억)"]),
                                                        "memo": r["메모"] or ""}
                            spec_log.save_prices(prices)
                            st.toast("저장했습니다")
                            st.rerun()
                        per = [(float((prices.get(e["key"]) or {}).get("eok") or 0), e) for e in log]
                        per = [(c, e) for c, e in per if c > 0 and e["d_main"] > 0]
                        if per:
                            st.caption("주스탯 1%p 당 비용: " + " · ".join(
                                f"{e['slot']} {c / e['d_main']:,.1f}억" for c, e in per))
                        st.caption("매일 저장한 장비끼리 비교합니다. 저장이 빠진 날이 있으면 그 사이 언제 바뀌었는지는 모릅니다. "
                                   "경매장 가격은 API 가 없어 직접 적습니다.")
            with sub_deme:
                if sub_deme.open or ALL_TABS:
                    # ---------- 드메 빈 칸 계획 ----------
                    st.markdown("**드메 세팅 계획**")  # same heading size as the other sub-tabs
                    st.caption("보유한 드메템 중 고정할 것(기본: 드메 2줄 이상)과 건드리지 않을 칸(기본: 정펜)을 두고, 나머지 칸을 "
                               "무엇으로 채워야 목표(기본 풀드메 드롭 200 · 메획 100)가 되는지 모든 경우를 따져 구매가 가장 적은 세팅부터 "
                               "보여 줍니다. 칸마다 지금 템 유지 · 보스템 · 보유 드메템 · 구매(드드 · 드메 · 메메) 중에서 고릅니다.")
                    drop_by_p = {p: equip.frame(eqd["presets"][p], main_stat)["drop"].sum() for p in (1, 2, 3)}
                    deme_default = max(drop_by_p, key=drop_by_p.get)
                    boss_default = min((p for p in (1, 2, 3) if p != deme_default), key=lambda p: drop_by_p[p])
                    o1, o2, o3, o4 = st.columns(4)
                    deme_p = o1.selectbox("드메 프리셋", [1, 2, 3], index=deme_default - 1, key=f"deme_plan_cur_{who}",
                                          format_func=lambda p: f"프리셋 {p} (드롭 {drop_by_p[p]:.0f}%)")
                    boss_p = o2.selectbox("보스 프리셋 (빈 칸에 끼울 보스템)", [1, 2, 3], index=boss_default - 1, key=f"deme_plan_boss_{who}",
                                          format_func=lambda p: f"프리셋 {p}")
                    drop_t = o3.number_input("목표 드롭률 (%)", 0, 400, equip.DEFAULT_DROP_TARGET, step=20, key="deme_drop_t")
                    meso_t = o4.number_input("목표 메획 (%)", 0, 400, equip.DEFAULT_MESO_TARGET, step=20, key="deme_meso_t")
                    if boss_p == deme_p:
                        st.warning("보스 프리셋과 드메 프리셋이 같습니다. 빈 칸에 끼울 보스템이 드메템과 같아지니 다른 프리셋을 고르세요.")
                    deme_f = equip.frame(eqd["presets"][deme_p], main_stat)
                    boss_f = equip.frame(eqd["presets"][boss_p], main_stat)
                    pool = pd.concat([equip.frame(eqd["presets"][p], main_stat) for p in (1, 2, 3)], ignore_index=True)
                    in_deme = deme_f[deme_f["slot"].isin(equip.DEME_SLOTS)]
                    o1, o2 = st.columns(2)
                    fixed = o1.multiselect("고정할 드메템", in_deme["name"].tolist(),
                                           default=in_deme.loc[in_deme["deme_lines"] >= 2, "name"].tolist(), key=f"deme_fixed_{who}_{deme_p}",
                                           help="이 아이템들은 그대로 두고 계산합니다. 기본값은 드메 윗잠이 2줄 이상인 아이템")
                    jeong = in_deme.loc[in_deme["name"].str.contains("정령의 펜던트"), "slot"].tolist()
                    excluded = o2.multiselect("건드리지 않을 칸", equip.DEME_SLOTS, default=jeong, key=f"deme_excl_{who}_{deme_p}",
                                              help="정펜처럼 드메와 상관없이 그대로 둘 칸")
                    o1, o2 = st.columns(2)
                    allow3 = o1.toggle("3줄 드메템 구매도 고려", value=False, key="deme_allow3",
                                       help="드드드 등 3줄은 큐브로 만들 확률이 0.0005% 수준이라 기본으로는 뺍니다")
                    with o2.popover("한도 설정", icon=":material/tune:"):
                        drop_cap = st.number_input("잠재 드롭률 최대 (%)", 0, 400, equip.DROP_CAP, step=20, key="deme_drop_cap",
                                                   help=equip.CAP_SOURCE)
                        meso_cap = st.number_input("잠재 메획 최대 (%)", 0, 400, equip.MESO_CAP, step=20, key="deme_meso_cap",
                                                   help=equip.CAP_SOURCE)
                        st.caption(equip.CAP_SOURCE)

                    plan = equip.plan_open_slots(deme_f, boss_f, pool, fixed, excluded, drop_t, meso_t, drop_cap, meso_cap, allow3)
                    need_d = max(0.0, drop_t - min(drop_cap, plan["base_drop"]))
                    need_m = max(0.0, meso_t - min(meso_cap, plan["base_meso"]))
                    m1 = m2 = m3 = m4 = m5 = MetricRow()
                    m1.metric("고정 템 드롭", f"{plan['base_drop']:.0f}%", border=True, icon=":material/lock:")
                    m2.metric("고정 템 메획", f"{plan['base_meso']:.0f}%", border=True, icon=":material/lock:")
                    m3.metric("더 필요한 드롭", f"{need_d:.0f}%", border=True, icon=":material/flag:")
                    m4.metric("더 필요한 메획", f"{need_m:.0f}%", border=True, icon=":material/flag:")
                    m5.metric("채울 칸", f"{len(plan['open_slots'])}칸", border=True, icon=":material/grid_view:",
                              help=", ".join(plan["open_slots"]) or "없음")

                    KIND_BADGE = {"유지": ":gray-badge[유지]", "보스템": ":blue-badge[보스템]", "보유 드메템": ":green-badge[보유 드메템]",
                                  "구매": ":orange-badge[구매]"}
                    now_by_slot = deme_f.set_index("slot")["name"].to_dict()

                    def make_cost(slot: str, label: str):
                        """Average cube cost to roll this 드메 combo yourself on a legendary item of the boss item's level."""
                        lines = {"드": 0, "메": 0}
                        for ch in label:
                            lines[ch] += 1
                        conds = [c for c in ([{"family": "아이템 드롭률%", "mode": "lines", "min": lines["드"]}] if lines["드"] else []) +
                                 ([{"family": "메소 획득량%", "mode": "lines", "min": lines["메"]}] if lines["메"] else [])]
                        lv = int(boss_f.loc[boss_f["slot"] == slot, "level"].max() or 160) if (boss_f["slot"] == slot).any() else 160
                        band = max(b for b in (160, 200, 250) if b <= max(160, lv))
                        t = calc_cube.slot_tables("5062010", "레전드리", equip.CUBE_PART[slot], band)
                        pr = calc_cube.success_prob_sets(t, [conds])
                        return (calc_cube.reset_cost("potential", lv, "레전드리") / pr if pr else math.inf), pr, lv

                    if not plan["open_slots"]:
                        st.info("채울 칸이 없습니다. 고정할 템이나 건드리지 않을 칸을 줄여 보세요.")
                    elif not plan["plans"]:
                        st.warning("가능한 세팅이 없습니다.")
                    else:
                        best = plan["plans"][0]
                        with st.container(border=True):
                            head = (f"**추천 세팅** · 드롭 {best['drop']:.0f}% · 메획 {best['meso']:.0f}% · 구매 {best['buys']}개"
                                    + (f" · {main_stat} {best['main']:g}% 유지" if best["main"] else ""))
                            st.markdown(head)
                            if best["short"] > 0:
                                st.warning(f"채울 수 있는 칸을 다 써도 목표에 {best['short']:.0f}%p 모자랍니다. "
                                           "고정할 템을 줄이거나(1줄짜리를 2줄로 바꿀 칸 확보) 3줄 구매를 켜 보세요.")
                            rows = []
                            for sl, o in best["slots"].items():
                                cost_txt = ""
                                if o["kind"] == "구매":
                                    cst, pr, lv = make_cost(sl, o["name"])
                                    cost_txt = (f"메소 재설정으로 만들면 평균 {cst / 1e8:,.0f}억 (1회 {pr:.3%}, 보스템과 같은 {lv}제 기준)"
                                                if pr else "만들 수 없음")
                                rows.append({"칸": sl, "지금 그림": ICONS.get(now_by_slot.get(sl, "")), "지금": now_by_slot.get(sl, "-"),
                                             "추천 그림": ICONS.get(o["name"]) if o["kind"] != "구매" else None,
                                             "추천": f"{o['kind']} · {o['name']}",
                                             "드롭": o["drop"], "메획": o["meso"], f"{main_stat}%": o["main"], "비고": cost_txt})
                            st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch", row_height=38, column_config={
                                "지금 그림": st.column_config.ImageColumn(" ", width="small"),
                                "추천 그림": st.column_config.ImageColumn(" ", width="small"),
                                "드롭": st.column_config.NumberColumn(format="%d%%"), "메획": st.column_config.NumberColumn(format="%d%%"),
                                f"{main_stat}%": st.column_config.NumberColumn(format="%g%%")})
                            buys = [f"{sl} {o['name']}" for sl, o in best["slots"].items() if o["kind"] == "구매"]
                            keeps = [f"{sl} {o['name']}" for sl, o in best["slots"].items() if o["kind"] != "구매"]
                            st.markdown(":orange-badge[살 것] " + (", ".join(buys) or "없음") + "  \n"
                                        ":gray-badge[그 칸에 둘 것] " + (", ".join(keeps) or "없음"))
                            over = (best["raw_drop"] - best["drop"]) + (best["raw_meso"] - best["meso"])
                            if over > 0:
                                st.caption(f"한도를 넘는 {over:.0f}%p 는 버려집니다.")
                        if len(plan["plans"]) > 1:
                            with st.expander("다른 방법", icon=":material/alt_route:"):
                                alt_rows = [{"순위": i + 1, "구매": pl["buys"], "드롭": pl["drop"], "메획": pl["meso"],
                                             f"{main_stat}% 유지": pl["main"],
                                             "세팅": " / ".join(f"{sl}: {o['name'] if o['kind'] != '유지' else o['name'] + '(유지)'}"
                                                               for sl, o in pl["slots"].items())}
                                            for i, pl in enumerate(plan["plans"])]
                                st.dataframe(pd.DataFrame(alt_rows), hide_index=True, width="stretch", column_config={
                                    "드롭": st.column_config.NumberColumn(format="%d%%"), "메획": st.column_config.NumberColumn(format="%d%%"),
                                    f"{main_stat}% 유지": st.column_config.NumberColumn(format="%g%%")})
                    with st.expander("고정한 템 · 보유 드메템 전체", icon=":material/list:"):
                        st.dataframe(pool[pool["deme_lines"] > 0][["slot", "name", "drop", "meso", "deme_lines", "main_pct"]]
                                     .drop_duplicates(["slot", "name"])
                                     .assign(고정=lambda d: d["name"].isin(fixed))
                                     .sort_values(["고정", "deme_lines"], ascending=False)
                                     .rename(columns={"slot": "부위", "name": "아이템", "drop": "드롭", "meso": "메획",
                                                      "deme_lines": "드메 윗잠 줄", "main_pct": f"{main_stat}%"}),
                                     hide_index=True, width="stretch")
                        st.caption("드롭 · 메획은 윗잠 20% 줄 + 에디 5% 줄 합계입니다. 창고 · 인벤토리에 있는 드메템은 API 에 없으니, "
                                   "아무 프리셋에 한 번 끼워 두면 다음 수집부터 보유 드메템으로 잡힙니다.")

# ---------- growth ----------
# One character at a time (2026-09-27 user: "캐릭터 하나만 나오게"), laid out like the fan sites' 경험치 · 레벨
# history: profile header, period summary cards, daily gain bars with the average as a rule, level and
# 전투력 lines. A switch keeps the old all-character comparison.
with tab_growth:
    if tab_growth.open or ALL_TABS:
        g = basic.copy()
        g["level"] = g["data"].map(lambda b: b.get("character_level"))
        g["exp_rate"] = g["data"].map(lambda b: float(b.get("character_exp_rate") or 0))
        g["class"] = g["data"].map(lambda b: b.get("character_class"))
        g = g.dropna(subset=["level"])
        g["레벨(소수)"] = g["level"] + g["exp_rate"] / 100
        cp = stat.copy()
        cp["전투력"] = cp["data"].map(lambda s: stat_value(s, "전투력"))
        g = g.merge(cp[["ocid", "date", "전투력"]], on=["ocid", "date"], how="left")
        g["date"] = pd.to_datetime(g["date"])
        g = g.sort_values(["name", "date"])
        # daily gain in %p of a level; a level-up counts as 100 %p (levels are not equal in raw exp)
        g["경험치 증가"] = g.groupby("name")["레벨(소수)"].diff() * 100
        g["간격"] = g.groupby("name")["date"].diff().dt.days
        g["전투력 (억)"] = g["전투력"] / 1e8
        g["날짜"] = g["date"].dt.strftime("%m-%d")
        # real EXP (2026-09-27): API character_exp is the EXP inside the level; with the verified table
        # (ref/exp_200_300_20260927.csv, 95/100 확정) EXP from 200 = sum(exp_to_next below level) + character_exp,
        # so days that cross a level-up are exact instead of "level-up = 100%p"
        _exp = pd.read_csv(ROOT / "ref" / "exp_200_300_20260927.csv", encoding="utf-8-sig").set_index("level")["exp_to_next"]
        _cum = _exp.cumsum().shift(1, fill_value=0)  # EXP from 200 to the start of each level

        def cum_at(level) -> float:
            return float(_cum.get(int(level), float("nan"))) if 200 <= int(level) <= 299 else float("nan")

        g["exp_abs"] = g["data"].map(lambda b: float(b.get("character_exp") or 0))
        g["누적"] = [cum_at(lv) + e for lv, e in zip(g["level"], g["exp_abs"])]
        g["하루 경험치"] = g.groupby("name")["누적"].diff()
        g["하루 경험치 (조)"] = g["하루 경험치"] / 1e12

        def jo(x) -> str:
            """EXP in 조 / 억 units."""
            return f"{x / 1e12:,.2f}조" if abs(x) >= 1e12 else f"{x / 1e8:,.0f}억"

        names = main_first(g["name"].unique())
        _gbar = st.container(horizontal=True, gap="large", vertical_alignment="bottom")
        who_g = _gbar.pills("캐릭터", names, default=names[0], key="growth_one") or names[0]
        span = _gbar.segmented_control("기간", ["7일", "14일", "30일", "전체"], default="14일", key="growth_span") or "14일"
        compare = _gbar.toggle("전체 캐릭터 비교", value=False, key="growth_compare")
        since = g["date"].max() - pd.Timedelta(days=int(span[:-1]) - 1) if span != "전체" else g["date"].min()

        if not compare:
            h = g[g["name"] == who_g]
            hh = h[h["date"] >= since]
            now_ = h.iloc[-1]
            gain = hh["경험치 증가"].sum(skipna=True)
            days_ = max(1, (now_["date"] - max(since, h["date"].min())).days)
            per_day = gain / days_
            left_days = math.ceil((100 - now_["exp_rate"]) / per_day) if per_day > 0 else None

            # profile header
            with st.container(border=True):
                prof = st.container(horizontal=True, gap="large", vertical_alignment="center")
                img = CHAR_IMG.get(who_g)
                if img:
                    prof.image(img, width=110)
                info = prof.container(width="stretch")
                info.markdown(f"### {'★ ' if who_g == MAIN else ''}{who_g}\n"
                              f":gray-badge[{now_['class']}] :orange-badge[Lv.{int(now_['level'])}]")
                info.progress(min(1.0, now_["exp_rate"] / 100), text=f"경험치 {now_['exp_rate']:.3f}%")
                cp7 = h[h["date"] >= h["date"].max() - pd.Timedelta(days=6)]["전투력"].max()
                info.caption(f"전투력 (최근 7일 최고) {cp7:,.0f}" if pd.notna(cp7) else "전투력 기록 없음")

            gain_exp = hh["하루 경험치"].sum(skipna=True)
            per_day_exp = gain_exp / days_
            cur_level = int(now_["level"])
            tgt = st.number_input("목표 레벨", min_value=cur_level + 1, max_value=300, value=min(300, cur_level + 1),
                                  key=f"growth_target_{who_g}", help="이 레벨에 도달하는 데 남은 경험치와 예상 날짜를 계산합니다")
            remain = (cum_at(tgt) if tgt <= 299 else cum_at(299) + float(_exp.get(299, 0))) - now_["누적"]
            tgt_days = math.ceil(remain / per_day_exp) if per_day_exp > 0 and remain == remain else None
            c1 = c2 = c3 = c4 = MetricRow()
            c1.metric(f"{span} 경험치", jo(gain_exp) if gain_exp == gain_exp else "-", icon=":material/trending_up:",
                      delta=f"+{gain:.1f}%p", delta_color="off",
                      help="실제 경험치(레벨업 포함, 경험치표 기준). 아래 %p 는 레벨 진행도 기준")
            c2.metric("하루 평균", jo(per_day_exp) if per_day_exp == per_day_exp else "-", icon=":material/calendar_today:",
                      delta=f"{per_day:.1f}%p", delta_color="off")
            c3.metric(f"Lv.{tgt} 까지", f"약 {tgt_days}일" if tgt_days else "-", icon=":material/flag:",
                      delta=f"남은 경험치 {jo(remain)}" if remain == remain else None, delta_color="off",
                      help=f"예상 도달일 {(now_['date'] + pd.Timedelta(days=tgt_days)):%Y-%m-%d} (최근 {span} 하루 평균 기준)"
                      if tgt_days else None)
            best = hh.dropna(subset=["하루 경험치"])
            c4.metric("가장 많이 한 날", f"{best.loc[best['하루 경험치'].idxmax(), '날짜']}" if len(best) else "-",
                      delta=jo(best["하루 경험치"].max()) if len(best) else None, delta_color="off",
                      icon=":material/emoji_events:")

            bars = hh.dropna(subset=["하루 경험치 (조)"])
            if len(bars):
                base = alt.Chart(bars).encode(x=alt.X("날짜:O", title=None, axis=alt.Axis(labelAngle=0)))
                chart = (base.mark_bar(color=ACCENT, cornerRadiusTopLeft=4, cornerRadiusTopRight=4).encode(
                            y=alt.Y("하루 경험치 (조):Q", title=None),
                            tooltip=[alt.Tooltip("날짜:O"), alt.Tooltip("하루 경험치 (조):Q", format=",.2f", title="경험치 (조)"),
                                     alt.Tooltip("경험치 증가:Q", format=".2f", title="레벨 진행 %p"),
                                     alt.Tooltip("level:Q", title="레벨"), alt.Tooltip("간격:Q", title="앞 기록과 간격(일)")])
                         + base.mark_text(dy=-7, fontSize=11, color=MUTED).encode(
                            y="하루 경험치 (조):Q", text=alt.Text("하루 경험치 (조):Q", format=".1f"))
                         + alt.Chart(pd.DataFrame({"평균": [per_day_exp / 1e12]})).mark_rule(strokeDash=[4, 4], color=MUTED).encode(
                            y="평균:Q", tooltip=[alt.Tooltip("평균:Q", format=",.2f", title="하루 평균 (조)")]))
                st.altair_chart(chart.properties(title="하루 경험치 (조) · 점선 = 하루 평균", height=260), width="stretch")
            st.caption("경험치는 넥슨 API 의 레벨 내 경험치와 레벨별 필요 경험치표(나무위키 · 계산기 2곳 대조, 293\\~297레벨만 1\\~4 차이)로 "
                       "계산합니다. 1조 = 1,000,000,000,000.")
            l1, l2 = st.columns(2)
            with l1:
                st.altair_chart(alt.Chart(hh).mark_line(point=True, color=ACCENT, strokeWidth=2).encode(
                    x=alt.X("date:T", title=None, axis=alt.Axis(format="%m-%d")),
                    y=alt.Y("레벨(소수):Q", title=None, scale=alt.Scale(zero=False, nice=False, padding=8),
                            axis=alt.Axis(format="d", tickMinStep=1)),
                    tooltip=[alt.Tooltip("date:T", format="%Y-%m-%d"), alt.Tooltip("레벨(소수):Q", format=".2f", title="레벨")],
                ).properties(title="레벨 (눈금 사이 = 경험치 %)", height=220), width="stretch")
            with l2:
                cpd = hh.dropna(subset=["전투력 (억)"]).sort_values("date").copy()
                # the saved value swings with the equipped preset (보스 3.3~3.9억 / 드메 1.4~1.9억, 08_환산_전투력.md), so the
                # line is the 7-day best (what the 스펙 tab shows) and daily values are faint dots
                cpd["7일 최고"] = cpd.rolling("7D", on="date")["전투력 (억)"].max()
                base_cp = alt.Chart(cpd).encode(x=alt.X("date:T", title=None, axis=alt.Axis(format="%m-%d")))
                st.altair_chart(
                    (base_cp.mark_point(filled=True, color=MUTED, opacity=.45, size=30).encode(
                        y=alt.Y("전투력 (억):Q", title=None, scale=alt.Scale(zero=False)),
                        tooltip=[alt.Tooltip("date:T", format="%Y-%m-%d"), alt.Tooltip("전투력 (억):Q", format=".2f", title="그날 값")])
                     + base_cp.mark_line(color=ACCENT, strokeWidth=2.5).encode(
                        y="7일 최고:Q", tooltip=[alt.Tooltip("date:T", format="%Y-%m-%d"),
                                                alt.Tooltip("7일 최고:Q", format=".2f", title="7일 최고")])
                     ).properties(title="전투력 (억) · 선 = 7일 최고, 점 = 그날 저장값", height=220),
                    width="stretch")
            with st.expander("날짜별 기록", icon=":material/table_chart:"):
                st.dataframe(hh.sort_values("date", ascending=False)[["date", "level", "exp_rate", "경험치 증가", "전투력"]]
                             .rename(columns={"date": "날짜", "level": "레벨", "exp_rate": "경험치 %", "경험치 증가": "증가 (%p)"}),
                             hide_index=True, width="stretch", column_config={
                                 "날짜": st.column_config.DateColumn(format="YYYY-MM-DD"),
                                 "경험치 %": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.2f%%"),
                                 "증가 (%p)": st.column_config.NumberColumn(format="%.2f"),
                                 "전투력": st.column_config.NumberColumn(format="%,d")})
        else:
            gg = g[g["date"] >= since]
            c = MetricRow()
            for n in names:
                hn = g[g["name"] == n]
                gn = gg.loc[gg["name"] == n, "경험치 증가"].sum()
                c.metric(("★ " if n == MAIN else "") + n, f"Lv.{int(hn.iloc[-1]['level'])}",
                         delta=f"{span} +{gn:.1f}%p", delta_color="normal")
            cmp = gg.dropna(subset=["경험치 증가"])
            st.altair_chart(alt.Chart(cmp).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
                x=alt.X("날짜:O", title=None, axis=alt.Axis(labelAngle=0)), xOffset="name:N",
                y=alt.Y("경험치 증가:Q", title=None),
                color=alt.Color("name:N", title=None, legend=alt.Legend(orient="top")),
                tooltip=[alt.Tooltip("name:N", title="캐릭터"), "날짜:O", alt.Tooltip("경험치 증가:Q", format=".1f")],
            ).properties(title="하루 경험치 (%p) 비교", height=300), width="stretch")

        gaps = g[(g["date"] >= since) & (g["간격"] > 1)]
        st.caption(f"수집된 기간: {g['date'].min():%Y-%m-%d} ~ {g['date'].max():%Y-%m-%d}. "
                   + (f"기록이 빠진 날 뒤의 막대는 그 사이 며칠치 합계입니다 ({len(gaps)}건). " if len(gaps) else "")
                   + "매일 새벽 4시에 자동으로 수집합니다(PC 가 꺼져 있었으면 켤 때).")

# ---------- starforce ----------
with tab_sf:
    if tab_sf.open or ALL_TABS:
        sf, days = load_history("starforce")
        st.caption(f"조회 완료 {days[0]}일치 ({days[1]} ~ {days[2]}), 기록 {len(sf)}건. 계정 전체 기록.")
        backfill_note(days[1])
        if sf.empty:
            st.info("아직 스타포스 기록이 없습니다.")
        else:
            sf["date_create"] = pd.to_datetime(sf["date_create"], format="ISO8601")
            # history is account-wide: 2026-09-27 85 of 86 starforce rows were 챌린저스4, so filter by world
            worlds = sorted(sf["world_name"].dropna().unique()) if "world_name" in sf else []
            sfb = st.container(horizontal=True, gap="large", vertical_alignment="bottom")
            wsel = sfb.pills("월드", worlds, selection_mode="multi", default=worlds, key="sf_world",
                             format_func=lambda w: f"{w} ({(sf['world_name'] == w).sum()})") if worlds else []
            sf_w = sf[sf["world_name"].isin(wsel)] if worlds and wsel else sf
            who = sfb.multiselect("캐릭터", main_first(sf_w["character_name"].dropna().unique()), key="sf_who",
                                  placeholder="전체 캐릭터")
            v = sf_w[sf_w["character_name"].isin(who)] if who else sf_w
            _pb = st.container(horizontal=True, gap="large", vertical_alignment="bottom")
            s0, s1 = period_picker(_pb, "sf_period", sf["date_create"].min().date())
            _d = v["date_create"].dt.date
            v = v[(_d >= s0) & (_d <= s1)]
            st.caption(f"{s0} ~ {s1} 기록 {len(v):,}건")
            # efficiency / luck per attempt and per item (sf_record.py, 2026-09-27 user: "얼마 이득 얼마 손해", 아이템별)
            sf_mvp = _pb.selectbox("MVP 등급 (비용 할인)", list(sf_record.sfc.MVP), key="sf_mvp",
                                   help="1~17성 강화 비용 할인. 기록에 MVP 가 남지 않아 여기서 고릅니다. PC방 할인은 넣지 않았습니다.")
            a, items, trivia = sf_record.analyze(v, _sf_levels(), sf_mvp)
            scored = a.dropna(subset=["비용"])
            spent, fair, luck = scored["비용"].sum(), scored["가치"].sum(), scored["이득"].sum()
            booms, exp_booms = int((a["item_upgrade_result"] == "파괴").sum()), float(scored["파괴 확률"].sum())
            c1 = c2 = c3 = c4 = c5 = MetricRow()
            c1.metric("시도", f"{len(v):,}회", icon=":material/touch_app:",
                      help=f"강화권 사용 {trivia['_강화권']}회 포함. 메소 계산은 강화권 · 렙제 모르는 장비를 뺀 {len(scored):,}회")
            c2.metric("쓴 메소", f"{spent / 1e8:,.1f} 억", icon=":material/savings:",
                      help="시도마다 공식 비용식 x 그날 이벤트 할인 x MVP + 파괴 방지 추가금. 흔적 복구 · 스페어 비용은 빠짐")
            c3.metric("평균이라면", f"{fair / 1e8:,.1f} 억", icon=":material/calculate:",
                      help="같은 결과(같은 장비를 같은 성까지)를 평균적인 운으로 얻었을 때 드는 메소")
            c4.metric("이득" if luck >= 0 else "손해", f"{abs(luck) / 1e8:,.1f} 억", icon=":material/auto_awesome:",
                      delta=f"운 {fair / spent:.2f}배" if spent else None, delta_color="normal" if luck >= 0 else "inverse",
                      help="평균이라면 - 쓴 메소. 운 = 평균이라면 ÷ 쓴 메소 (1보다 크면 평균보다 싸게 함)")
            c5.metric("파괴", f"{booms}회", delta=f"기대 {exp_booms:.2f}회", delta_color="off", icon=":material/heart_broken:")
            if spent:
                st.caption(f"평균적인 운이라면 {fair / 1e8:,.1f}억이 들었을 결과를 {spent / 1e8:,.1f}억에 해냈습니다 "
                           f"({'이득' if luck >= 0 else '손해'} {abs(luck) / 1e8:,.1f}억).")
            if trivia["_제외_렙제모름"]:
                st.caption("렙제를 몰라 메소 계산에서 뺀 장비: " + ", ".join(trivia["_제외_렙제모름"])
                           + " (착용 기록이 없는 장비는 렙제를 알 수 없습니다)")

            if len(scored):
                daily = (scored.assign(날짜=scored["date_create"].dt.tz_localize(None).dt.normalize())
                         .groupby("날짜").agg(쓴메소=("비용", "sum"), 이득=("이득", "sum")).reset_index())
                daily["쓴 메소(억)"], daily["이득(억)"] = daily["쓴메소"] / 1e8, daily["이득"] / 1e8
                daily["결과"] = np.where(daily["이득"] >= 0, "이득", "손해")
                daily["날짜표시"] = daily["날짜"].dt.strftime("%m-%d")  # record days only (UI 점검: 막대 대부분 0)
                st.subheader("날짜별 쓴 메소 (억)", help="강화한 날만 표시")
                st.altair_chart(
                    alt.Chart(daily).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
                        x=alt.X("날짜표시:N", title=None, sort=None, axis=alt.Axis(labelAngle=0)),
                        y=alt.Y("쓴 메소(억):Q", title=None),
                        color=alt.Color("결과:N", scale=alt.Scale(domain=["이득", "손해"], range=[SF_GOOD, SF_BAD]),
                                        legend=alt.Legend(orient="top", title=None)),
                        tooltip=[alt.Tooltip("날짜:T", format="%Y-%m-%d"), alt.Tooltip("쓴 메소(억):Q", format=",.2f"),
                                 alt.Tooltip("이득(억):Q", format="+,.2f")]).properties(height=220),
                    width="stretch")

            st.subheader("아이템별")
            it = items.sort_values(["쓴 메소", "시도"], ascending=False, na_position="last").copy()
            it.insert(0, "그림", it["target_item"].map(ICONS))
            it["스타포스"] = [f"{int(a_)}→{int(b_)}성" + (f" (최고 {int(m_)})" if m_ > b_ else "")
                            for a_, b_, m_ in zip(it["시작"], it["최종"], it["최고"])]
            for col in ("쓴 메소", "평균 비용", "이득"):
                it[col + "(억)"] = it[col] / 1e8
            it["운"] = it["운"].where(it["쓴 메소"] > 0)
            st.dataframe(it[["그림", "target_item", "character_name", "스타포스", "시도", "성공", "실패", "파괴", "기대 파괴",
                             "쓴 메소(억)", "평균 비용(억)", "이득(억)", "운"]]
                         .rename(columns={"target_item": "아이템", "character_name": "캐릭터"}),
                         hide_index=True, width="stretch", row_height=40, height=min(40 + 41 * len(it), 520),
                         column_config={"그림": st.column_config.ImageColumn(" ", width="small"),
                                        "기대 파괴": st.column_config.NumberColumn(format="%.2f"),
                                        "쓴 메소(억)": st.column_config.NumberColumn(format="%,.2f"),
                                        "평균 비용(억)": st.column_config.NumberColumn(format="%,.2f"),
                                        "이득(억)": st.column_config.NumberColumn(format="%+,.2f", help="+ 이득, - 손해"),
                                        "운": st.column_config.NumberColumn(format="%.2f배", help="평균 비용 ÷ 쓴 메소")})

            tm = {k: x for k, x in trivia.items() if not k.startswith("_")}
            if tm:
                st.subheader("TMI")
                TMI_ICON = {"가장 운 좋은 성공": "stars", "가장 비싼 한 번": "paid", "가장 이득 본 한 번": "trending_up",
                            "가장 손해 본 한 번": "trending_down", "파괴 방지": "shield", "이벤트 날 강화": "celebration",
                            "가장 많이 쓴 날": "event", "최장 연속 실패": "replay"}
                tbox = st.container(horizontal=True, gap="small")
                for k, x in tm.items():
                    ic = TMI_ICON.get(k, "info")
                    with tbox.container(border=True, width=320):
                        st.markdown(f":{ICON_COLOR.get(ic, 'gray')}[:material/{ic}: **{k}**]  \n{x}")
            with st.expander("이득 · 손해는 어떻게 계산하나요?", icon=":material/help:"):
                st.markdown(
                    "- **쓴 메소**: 기록에 메소가 없어서, 시도마다 공식 비용식으로 다시 계산합니다. 렙제는 장비 기록에서 찾고, "
                    "그날 이벤트(30% 할인 등) · 파괴 방지 추가금 · 위에서 고른 MVP 할인을 넣습니다.\n"
                    "- **평균 비용**: 그 장비를 기록상 최고 성까지 올리는 평균 비용을 공식 확률로 정확히 풀어 두고, 시도 한 번이 "
                    "그 비용을 얼마나 줄였는지(성공이면 크게, 실패면 0, 파괴면 12성부터 다시 올리는 비용만큼 마이너스)를 더합니다.\n"
                    "- **이득 = 평균 비용 - 쓴 메소.** 운이 평균이면 0 이 되도록 만든 값이라(시뮬레이션 확인) + 면 평균보다 싸게, "
                    "- 면 비싸게 한 것입니다.\n"
                    "- 빠진 것: 흔적 복구 · 스페어 비용(기록에 없음), PC방 할인, 강화권(메소를 안 씀), 렙제를 모르는 장비.")

            st.subheader("최근 기록")
            sf_cols = {"date_create": "일시", "world_name": "월드", "character_name": "캐릭터", "target_item": "장비",
                       "before_starforce_count": "강화 전", "after_starforce_count": "강화 후",
                       "item_upgrade_result": "결과", "비용": "비용", "이득": "이득", "이벤트": "이벤트",
                       "destroy_defence": "파방", "upgrade_item": "사용 아이템"}
            sf_rec = a.sort_values("date_create", ascending=False).reindex(columns=list(sf_cols)).head(300)
            sf_rec["비용"], sf_rec["이득"] = sf_rec["비용"] / 1e8, sf_rec["이득"] / 1e8
            sf_rec["destroy_defence"] = sf_rec["destroy_defence"].map({"파괴 방지 적용": "적용", "파괴 방지 미적용": ""})
            sf_rec.insert(0, "그림", sf_rec["target_item"].map(ICONS))
            st.dataframe(sf_rec.rename(columns=sf_cols), hide_index=True, width="stretch", row_height=36,
                         column_config={"그림": st.column_config.ImageColumn(" ", width="small"),
                                        "일시": st.column_config.DatetimeColumn(format="MM-DD HH:mm"),
                                        "비용": st.column_config.NumberColumn("비용(억)", format="%,.2f"),
                                        "이득": st.column_config.NumberColumn("이득(억)", format="%+,.2f")})

            # per-star tables: low interest (2026-09-27 user), kept at the very bottom
            st.divider()
            # actual vs expected per star (PROB matches official 767 + 799 always-on starcatch; kb 2026-09-27).
            # Expected destroy uses each attempt's own event list (15~21성 파괴 30% 감소) and 파괴 방지.
            import calc_starforce as _sfc
            def _exp(r):
                stn = int(r["before_starforce_count"])
                if stn >= len(_sfc.PROB):
                    return pd.Series({"기대 성공": None, "기대 파괴": None})
                ps, pm, pd_ = _sfc.PROB[stn]
                evs = r["starforce_event_list"] if isinstance(r["starforce_event_list"], list) else []
                for e in evs:
                    rng = str(e.get("starforce_event_range") or "")
                    in_rng = (not rng) or ("~" in rng and int(rng.split("~")[0]) <= stn <= int(rng.split("~")[1]))                     or (str(stn) in rng.split(","))
                    if e.get("destroy_decrease_rate") and in_rng:
                        pd_ *= 1 - float(e["destroy_decrease_rate"]) / 100
                    if e.get("success_rate") and in_rng:
                        ps = float(e["success_rate"]) / 100
                if "적용" in str(r.get("destroy_defence")) and "미적용" not in str(r.get("destroy_defence")):
                    pd_ = 0.0
                return pd.Series({"기대 성공": ps, "기대 파괴": pd_})
            # API values: "슈페리얼 장비 미해당" / "파괴 방지 적용" · "파괴 방지 미적용" (DB 2026-09-27)
            vv = v[~v["superior_item_flag"].astype(str).str.contains("해당") | v["superior_item_flag"].astype(str).str.contains("미해당")].copy()
            exp_cols = vv.apply(_exp, axis=1) if len(vv) else pd.DataFrame(columns=["기대 성공", "기대 파괴"])
            vv["기대 성공"], vv["기대 파괴"] = exp_cols["기대 성공"], exp_cols["기대 파괴"]
            vv["성공"] = (vv["item_upgrade_result"] == "성공").astype(int)
            vv["파괴"] = vv["item_upgrade_result"].astype(str).str.contains("파괴").astype(int)
            cmp = vv.groupby("before_starforce_count").agg(
                시도=("성공", "size"), 성공=("성공", "sum"), 기대성공=("기대 성공", "sum"),
                파괴=("파괴", "sum"), 기대파괴=("기대 파괴", "sum")).reset_index()
            cmp["실패(유지)"] = cmp["시도"] - cmp["성공"] - cmp["파괴"]
            cmp["실제 성공률"] = cmp["성공"] / cmp["시도"] * 100
            cmp["기대 성공률"] = cmp["기대성공"] / cmp["시도"] * 100
            cmp["운"] = [f"{a / b:.2f}배" if b else "-" for a, b in zip(cmp["성공"], cmp["기대성공"])]
            st.subheader("★ 단계별 실제 vs 기대", divider=False)
            tot_s, tot_e = cmp["성공"].sum(), cmp["기대성공"].sum()
            r1 = MetricRow()
            r1.metric("성공 운", f"{tot_s / tot_e:.2f}배" if tot_e else "-", icon=":material/auto_awesome:",
                      help="실제 성공 횟수 ÷ 기대 성공 횟수(시도마다 공식 성공 확률의 합). 1보다 크면 운이 좋은 편")
            r1.metric("성공", f"{tot_s:,}회", delta=f"기대 {tot_e:.1f}회", delta_color="off", icon=":material/check_circle:")
            r1.metric("파괴", f"{cmp['파괴'].sum():,}회", delta=f"기대 {cmp['기대파괴'].sum():.2f}회", delta_color="off",
                      icon=":material/heart_broken:")
            st.dataframe(cmp[["before_starforce_count", "시도", "성공", "실패(유지)", "실제 성공률", "기대 성공률", "운", "파괴",
                              "기대파괴"]]
                         .rename(columns={"before_starforce_count": "강화 전 ★", "기대파괴": "기대 파괴"}),
                         hide_index=True, width="stretch", column_config={
                             "강화 전 ★": st.column_config.NumberColumn(format="%d성"),
                             "실제 성공률": st.column_config.ProgressColumn(min_value=0, max_value=100, format="%.1f%%"),
                             "기대 성공률": st.column_config.NumberColumn(format="%.1f%%"),
                             "기대 파괴": st.column_config.NumberColumn(format="%.2f")})
            with st.expander("이 표는 어떻게 계산하나요?", icon=":material/help:"):
                st.markdown("- 시도마다 그 성의 **공식 성공 · 파괴 확률**(스타캐치 상시 적용, 2026-03-19 개편 이후)을 더해 기대 횟수를 만듭니다.\n"
                            "- 그날 이벤트(샤타포스의 15~21성 파괴 30% 감소 등)와 파방 적용 여부는 기록에 남은 값을 그대로 씁니다.\n"
                            "- 슈페리얼 장비는 확률표가 달라 뺐습니다. 시도가 적은 성은 운 값이 크게 흔들립니다.")

# ---------- cube ----------
with tab_cube:
    if tab_cube.open or ALL_TABS:
        parts, spans, firsts = [], [], []
        for kind, label in (("cube", "큐브"), ("potential", "메소 재설정"), ("soul-potential", "소울 재설정")):
            h, days = load_history(kind)
            spans.append(f"{label} {days[1]} ~ {days[2]} ({len(h):,}건)")
            if kind in cfg["history_kinds"]:  # a kind no longer collected would pin the notice forever
                firsts.append(days[1])
            if not h.empty:
                if "cube_type" not in h:
                    h["cube_type"] = h.get("potential_type", "소울 재설정" if kind == "soul-potential" else "잠재능력 재설정")
                parts.append(h)
        backfill_note(max(firsts))
        if not parts:
            st.info("아직 큐브 · 메소 재설정 기록이 없습니다.")
        else:
            cu = pd.concat(parts, ignore_index=True)
            cu["date_create"] = pd.to_datetime(cu["date_create"], format="ISO8601").dt.tz_localize(None)
            cu["날짜"] = cu["date_create"].dt.normalize()
            rate_mp = mk["meso_market_mp_per_eok"]["value"]
            wpm = mk["won_per_mp"]["value"]
            cash_rate = mk["cash_won_per_eok"]["value"]
            prices = cube_spend.load_prices()
            cu = cube_spend.enrich(cu, prices, rate_mp)

            _bar = st.container(horizontal=True, gap="large", vertical_alignment="bottom")
            f1 = f2 = _bar
            who = f1.pills("캐릭터 (안 고르면 전체)", main_first(cu["character_name"].dropna().unique()), selection_mode="multi",
                           key="cube_who")
            _pb = st.container(horizontal=True, gap="large", vertical_alignment="bottom")
            c0, c1_ = period_picker(_pb, "cube_period", cu["날짜"].min().date())
            v = cu[cu["character_name"].isin(who)] if who else cu
            v = v[(v["날짜"].dt.date >= c0) & (v["날짜"].dt.date <= c1_)]
            st.caption(f"{c0} ~ {c1_} 기록 {len(v):,}건")

            meso_tot = float(v["메소 환산"].sum())
            mp_tot = float(v["메포 환산"].sum())
            c1 = c2 = c3 = MetricRow()
            c1.metric("쓴 메소", f"{meso_tot / 1e8:,.1f}억", border=True, icon=":material/savings:",
                      help="메소 재설정은 렙제 · 재설정 전 등급별 공식 비용, 큐브 아이템은 아래 가격표 기준")
            c2.metric("현금 환산 (메소마켓)", f"{mp_tot * wpm:,.0f}원" if rate_mp else "시세 미입력", border=True,
                      icon=":material/payments:", delta=f"{mp_tot:,.0f} 메포" if rate_mp else None, delta_color="off",
                      help=f"메소마켓 1억 = {rate_mp:,.0f} 메포 (메소 가치 탭)")
            c3.metric("현금 거래 환산", f"{meso_tot / 1e8 * cash_rate:,.0f}원" if cash_rate else "시세 미입력",
                      border=True, icon=":material/handshake:")
            ups, exp_ups = int(v["등업"].sum()), float(v["기대 등업"].sum())
            c1 = c2 = c3 = c4 = MetricRow()
            c1.metric("사용 횟수", f"{len(v):,}회", border=True, icon=":material/casino:")
            c2.metric("등업", f"{ups}회", delta=f"기대 {exp_ups:.2f}회", delta_color="off", border=True,
                      icon=":material/trending_up:")
            c3.metric("운", f"{ups / exp_ups:.2f}배" if exp_ups > 0 else "-", border=True, icon=":material/auto_awesome:",
                      help="실제 등업 ÷ 기대 등업(공식 1회 확률의 합, 천장 미반영). 1보다 크면 운이 좋은 편.")
            c4.metric("마지막 기록", f"{cu['date_create'].max():%m-%d %H:%M}", border=True, icon=":material/schedule:",
                      help="지금 갱신을 누르면 오늘 기록까지 다시 받습니다. 넥슨 반영은 최대 30분 늦습니다.")

            st.subheader("모아보기")
            group = st.segmented_control("기준", ["장비", "캐릭터", "종류", "날짜", "월"], default="장비",
                                         key="cube_group", label_visibility="collapsed") or "장비"
            vv = v.assign(월=v["날짜"].dt.strftime("%Y-%m"), 날짜표시=v["날짜"].dt.strftime("%Y-%m-%d"))
            by = {"장비": ["target_item", "item_level"], "캐릭터": ["character_name"], "종류": ["cube_type"],
                  "날짜": ["날짜표시"], "월": ["월"]}[group]
            sm = cube_spend.summarize(vv, by)
            if group in ("날짜", "월"):
                sm = sm.sort_values(by[0], ascending=False)
            # text so impossible grade-ups (already 레전드리, reward cubes capped below) show '-' instead of None
            sm["운"] = [f"{x:.2f}배" if pd.notna(x) else "-" for x in sm["운"]]
            # icons instead of the old top-12 bar chart (its labels overlapped); share of the total as a bar in the table
            share_by = "억" if sm["억"].sum() > 0 else "횟수"
            show = sm.drop(columns=["메소", "메포", "기대등업"])
            show.insert(show.columns.get_loc(share_by) + 1, "비중", sm[share_by] / sm[share_by].sum() * 100)
            if group == "장비":
                show.insert(0, "그림", show["target_item"].map(ICONS))
            elif group == "캐릭터":
                show.insert(0, "그림", show["character_name"].map(CHAR_IMG))
            elif group == "종류":
                show.insert(0, "그림", show["cube_type"].map(cube_icon))
            if rate_mp:
                show["현금 (원)"] = sm["메포"] * wpm
            st.dataframe(
                show.rename(columns={"target_item": "장비", "item_level": "렙제", "character_name": "캐릭터",
                                     "cube_type": "종류", "날짜표시": "날짜", "억": "메소 (억)", "등업": "등업"}),
                hide_index=True, width="stretch", height=min(560, 40 + 41 * len(sm)), row_height=40,
                column_config={"그림": st.column_config.ImageColumn(" ", width="small"),
                               "메소 (억)": st.column_config.NumberColumn(format="%,.2f"),
                               "비중": st.column_config.ProgressColumn(
                                   f"비중 ({'메소' if share_by == '억' else '횟수'})", format="%.0f%%",
                                   min_value=0, max_value=100, color="primary"),
                               "현금 (원)": st.column_config.NumberColumn(format="%,d"),
                               "렙제": st.column_config.NumberColumn(format="%d"),
                               "운": st.column_config.TextColumn(
                                   help="실제 등업 ÷ 기대 등업. '-' 는 등업이 불가능한 재설정(이미 레전드리 등)")})

            daily = (v[v["날짜"] >= v["날짜"].max() - pd.Timedelta(days=29)]
                     .groupby(["날짜", "cube_type"]).agg(횟수=("등업", "size"), 억=("메소 환산", "sum")).reset_index())
            daily["억"] /= 1e8
            metric_ = st.segmented_control("그래프", ["메소 (억)", "횟수"], default="메소 (억)", key="cube_chart") or "메소 (억)"
            ycol = "억" if metric_ == "메소 (억)" else "횟수"
            st.altair_chart(alt.Chart(daily).mark_bar(cornerRadiusTopLeft=3, cornerRadiusTopRight=3).encode(
                x=alt.X("날짜:T", title=None, axis=alt.Axis(format="%m-%d", labelAngle=0)),
                y=alt.Y(f"{ycol}:Q", title=None),
                color=alt.Color("cube_type:N", title=None, legend=alt.Legend(orient="bottom", columns=3, labelLimit=260)),
                tooltip=[alt.Tooltip("날짜:T", format="%Y-%m-%d"), alt.Tooltip("cube_type:N", title="종류"),
                         "횟수:Q", alt.Tooltip("억:Q", format=".2f")],
            ).properties(title=f"날짜별 {metric_} (최근 30일)", height=280), width="stretch")

            def _opts(r):
                o = r.get("after_potential_option")
                if not isinstance(o, list) or not o:
                    o = r.get("after_additional_potential_option")
                return " / ".join(x["value"] for x in o) if isinstance(o, list) else ""

            st.subheader("최근 기록")
            rec = v.sort_values("date_create", ascending=False).head(200).copy()
            rec["결과 옵션"] = [_opts(r) for r in rec.to_dict("records")]
            rec["메소 (억)"] = rec["메소 환산"] / 1e8  # 억, like the other cube tables
            rec["그림"] = rec["target_item"].map(ICONS)
            rec["큐브"] = rec["cube_type"].map(cube_icon)
            st.dataframe(rec[["그림", "date_create", "character_name", "target_item", "큐브", "cube_type", "이전 등급",
                              "item_upgrade_result", "메소 (억)", "결과 옵션"]]
                         .rename(columns={"date_create": "일시", "character_name": "캐릭터", "target_item": "장비",
                                          "cube_type": "종류", "item_upgrade_result": "등업"}),
                         hide_index=True, width="stretch", height=460, row_height=38,
                         column_config={"그림": st.column_config.ImageColumn(" ", width="small"),
                                        "큐브": st.column_config.ImageColumn(" ", width="small"),
                                        "일시": st.column_config.DatetimeColumn(format="MM-DD HH:mm"),
                                        "메소 (억)": st.column_config.NumberColumn(format="%,.3f")})

            with st.expander("큐브 아이템 가격 (이벤트 · 보상 큐브는 0)"):
                st.caption("메소 재설정은 비용표로 자동 계산합니다. 큐브 아이템은 1개 가격을 메소나 메포로 넣으세요. "
                           "카르마 · 메멘토 · 대적자 큐브처럼 보상으로 받은 것은 0 으로 두면 됩니다.")
                items = sorted(n for n in cu["cube_type"].unique() if n not in cube_spend.MESO_RESETS)
                pe = pd.DataFrame([{"큐브": n, "1개 가격": float((prices.get(n) or {}).get("price") or 0),
                                    "단위": (prices.get(n) or {}).get("unit") or "메소"} for n in items])
                pe = st.data_editor(pe, hide_index=True, width="stretch", key="cube_price_editor", disabled=["큐브"],
                                    column_config={"1개 가격": st.column_config.NumberColumn(min_value=0.0, format="localized"),
                                                   "단위": st.column_config.SelectboxColumn(options=["메소", "메포"])})
                if st.button("가격 저장", key="cube_price_save"):
                    cube_spend.save_prices({r["큐브"]: {"price": float(r["1개 가격"] or 0), "unit": r["단위"] or "메소"}
                                            for r in pe.to_dict("records")})
                    st.rerun()
        st.caption("조회 범위: " + " · ".join(spans) + ". 계정 전체 기록.")

# ---------- boss ----------
with tab_boss:
    if tab_boss.open or ALL_TABS:
        clears, world_cap, prices = boss_clears()
        if clears is None:
            st.info("스케줄러에 완료된 보스가 없습니다(최근 14일).")
        else:

            weeks = sorted(clears["week"].unique(), reverse=True)
            # weekly crystal income of the last finished week (or this week if none), used by the calculators
            # to show costs as "보스 수익 몇 주" (roadmap 06 rank 3, 2026-09-27)
            # weekly crystal income over the stored weeks (UI 점검: 한 주씩만 보여 추이가 없었음)
            wk_sum = (clears[clears["판매"]].groupby("week")["수익"].sum() / 1e8).reset_index()
            wk_sum["주차"] = wk_sum["week"].map(lambda d: f"{d:%m-%d}")
            _bh = st.container(horizontal=True, vertical_alignment="center", gap="small")
            _cry = _ix.extra_icon("currency", "강렬한 힘의 결정")
            if _cry:
                _bh.image(_cry, width=34)
            _bh.markdown("**주간 결정석 수익** (목요일 0시 시작 주)")
            st.altair_chart(alt.Chart(wk_sum).mark_bar(cornerRadiusTopLeft=4, cornerRadiusTopRight=4, color=ACCENT).encode(
                x=alt.X("주차:N", title=None, sort=None), y=alt.Y("수익:Q", title="억"),
                tooltip=["주차", alt.Tooltip("수익:Q", title="수익(억)", format=",.2f")]).properties(height=170),
                width="stretch")
            w = st.selectbox("주차 (목요일 0시 시작)", weeks, format_func=lambda d: f"{d} 주")
            cw = clears[clears["week"] == w]
            total = float(cw.loc[cw["판매"], "수익"].sum())
            c1 = c2 = c3 = c4 = MetricRow()
            c1.metric("클리어한 보스", f"{len(cw)}건", border=True, icon=":material/swords:")
            c2.metric("판매 결정석", f"{int(cw['판매'].sum())} / {world_cap}개", border=True, icon=":material/diamond:")
            c3.metric("결정석 수익", f"{total / 1e8:,.2f}억", border=True, icon=":material/savings:")
            c4.metric("현금 환산", f"{market.meso_to_won(total, mk):,.0f} 원" if won_per_eok else "시세 미입력",
                      border=True, icon=":material/payments:")
            missing = sorted(cw.loc[cw["가격"].isna(), "key"].unique())
            if missing:
                st.warning(f"가격표에 없는 보스 {len(missing)}종: " + ", ".join(missing))
            if cw["판매"].sum() < (cw["수익"].fillna(0) > 0).sum():
                st.caption(f"월드 주간 판매 한도 {world_cap}개를 넘은 결정석은 싼 것부터 뺐습니다.")
            DIFF_KO = {"easy": "이지", "normal": "노멀", "hard": "하드", "chaos": "카오스", "extreme": "익스트림"}
            by_boss = (cw.assign(판매수익=cw["수익"].where(cw["판매"], 0))
                         .groupby(["boss", "diff"]).agg(클리어=("name", "size"), 판매수익=("판매수익", "sum"),
                                                         결정가=("가격", "first")).reset_index()
                         .sort_values("판매수익", ascending=False))
            by_boss.insert(0, "아이콘", by_boss["boss"].map(boss_icon))
            by_boss["난이도"] = by_boss["diff"].map(lambda d: DIFF_KO.get(d, d))
            by_boss["수익(억)"] = by_boss["판매수익"] / 1e8
            by_boss["결정가"] = by_boss["결정가"] / 1e8  # 억, like 수익 (UI 점검: 576,000,000 원 단위와 섞임)
            st.dataframe(by_boss[["아이콘", "boss", "난이도", "클리어", "결정가", "수익(억)"]].rename(columns={"boss": "보스",
                                                                                                "결정가": "결정가(억)"}),
                         hide_index=True, width="stretch", row_height=44, height="content",
                         column_config={"아이콘": st.column_config.ImageColumn(" ", width="small"),
                                        "결정가(억)": st.column_config.NumberColumn(format="%,.2f"),
                                        "수익(억)": st.column_config.NumberColumn(format="%,.2f")})
            by_char = (cw.assign(판매수익=cw["수익"].where(cw["판매"], 0))
                         .groupby("name").agg(완료=("boss", "size"), 판매=("판매", "sum"), 수익=("판매수익", "sum"))
                         .sort_values("수익", ascending=False))
            by_char["수익(억)"] = by_char["수익"] / 1e8
            by_char = by_char.sort_index(key=lambda i: i != MAIN, kind="stable")  # main first
            by_char.index = [f"★ {n}" if n == MAIN else n for n in by_char.index]
            by_char.index.name = "캐릭터"
            by_char.insert(0, "그림", [CHAR_IMG.get(n.removeprefix("★ ")) for n in by_char.index])
            by_char = by_char.reset_index()[["그림", "캐릭터", "완료", "판매", "수익(억)"]]  # picture first, like other tables
            st.dataframe(by_char, width="stretch", row_height=48, hide_index=True, height="content",
                         column_config={"그림": st.column_config.ImageColumn(" ", width="small"),
                                        "수익(억)": st.column_config.NumberColumn(format="%,.2f")})
            with st.expander("클리어한 보스 상세", icon=":material/list:"):
                # API values bossDaily/bossWeekly/bossMonthly and easy/hard... shown in player words (07_용어점검 2026-09-27)
                CYCLE_KO = {"bossDaily": "일간", "bossWeekly": "주간", "bossMonthly": "월간"}
                det = cw.assign(diff=cw["diff"].map(lambda d: DIFF_KO.get(d, d)),
                                cycle=cw["cycle"].map(lambda c: CYCLE_KO.get(c, c)),
                                판매=cw["판매"].map({True: "판매", False: "한도 초과"}))
                det.insert(0, "그림", det["boss"].map(boss_icon))
                st.dataframe(det[["그림", "name", "boss", "diff", "cycle", "date", "가격", "인원", "수익", "판매"]]
                             .sort_values(["name", "수익"], ascending=[True, False])
                             .rename(columns={"name": "캐릭터", "boss": "보스", "diff": "난이도", "cycle": "주기",
                                              "date": "클리어일", "가격": "결정석 가격", "인원": "파티 인원"}), hide_index=True,
                             row_height=38,
                             width="stretch", column_config={"결정석 가격": st.column_config.NumberColumn(format="%,d 메소"),
                                                             "그림": st.column_config.ImageColumn(" ", width="small"),
                                                             "수익": st.column_config.NumberColumn(format="%,d")})
        st.caption(f"결정석 가격: {prices.get('_source', '').replace('namu.wiki', '나무위키')}. 규칙: 월드당 주 {world_cap}개 판매, "
                   "캐릭터당 주간 보스 12회, 파티 1/n(파티 인원은 결정석 가격표 파일에서 보스별로 바꿀 수 있습니다). "
                   "스케줄러는 최근 14일만 조회되므로 그 이전은 매일 수집한 기록만 남습니다.")

# ---------- calculators ----------
with tab_calc:
    if tab_calc.open or ALL_TABS:
        import calc_cube
        import calc_starforce as sfc

        # event effects and dates: 10_조사/20260926_강화이벤트_조사.md (official notices, API records)
        SF_EFFECTS = {"30% 할인": "discount30", "21성 이하 파괴 30% 감소": "destroy_down",
                      "흔적 복구 20% 할인": "restore20", "10성 이하 1+1": "one_plus_one", "5/10/15성 100%": "guarantee"}
        SHINING = ["30% 할인", "21성 이하 파괴 30% 감소", "흔적 복구 20% 할인"]

        def sf_event_picker(key: str) -> frozenset:
            """Combinable starforce event effects, with a one-click 샤타포스 preset."""
            def _shining():
                st.session_state[key] = SHINING
            sel = st.pills("스타포스 이벤트 (여러 개 선택 가능)", list(SF_EFFECTS), selection_mode="multi", key=key,
                          help="30% 할인: 전 구간 비용 × 0.7 (MVP · PC방 할인 뒤에 곱함, 파괴 방지 추가금은 할인 없음). "
                               "파괴 감소: 15~21성 파괴 확률 × 0.7. 1+1: 10성 이하 성공 시 +2성(최대 12성).")
            st.button("샤타포스로 채우기", on_click=_shining, key=f"{key}_shining", icon=":material/bolt:",
                     help="샤이닝 스타포스 = 30% 할인 + 21성 이하 파괴 30% 감소 + 흔적 복구 20% 할인 (2026-03-29부터)")
            return frozenset(SF_EFFECTS[s] for s in sel or [])

        MIRACLE_HELP = ("미라클 타임: 등업 확률 2배. 메소 재설정(윗잠 · 에디)과 등업이 되는 모든 큐브에 적용. "
                        "천장은 1회씩만 쌓이고 옵션 확률은 그대로입니다(공식 공지 1124 · 1352 · 1391). "
                        "다음 미라클 타임: 2026-09-27 (소울 잠재 재설정도 처음 포함).")

        def won_of(meso: float):
            return market.meso_to_won(meso, mk) if won_per_eok else None

        BOSS_WEEK, BOSS_WEEK_LABEL = boss_week()  # cached; works when the 보스 tab is closed (lazy tabs)

        def won_text(meso: float) -> str:
            t = f"≈ {won_of(meso):,.0f} 원" if won_per_eok else "현금 환산: 메소 가치 탭에서 시세 입력"
            if BOSS_WEEK > 0:
                t += f" · 보스 수익 {meso / BOSS_WEEK:,.1f}주 ({BOSS_WEEK_LABEL} 결정석 {BOSS_WEEK / 1e8:,.1f}억 기준)"
            return t

        def cost_box(label: str, auto: int, key: str, source: str) -> int:
            """Cost input whose default follows the other inputs.

            The table value is part of the widget key, so changing level / grade / method gives a fresh box
            with the new default (a keyed number_input otherwise keeps its first value; bug seen 2026-09-26:
            에디셔널 160제 유니크 still showed 윗잠 200제 유니크 45,900,000). A typed value lasts until then."""
            v = int(st.number_input(label, min_value=0, value=int(auto), step=100_000, key=f"{key}_{auto}",
                                    help="조건을 바꾸면 비용표 값으로 다시 채워집니다. 인게임 값과 다르면 고쳐 넣으세요."))
            note = f"{source}: {auto:,} 메소" if auto else source
            st.caption(note + (f" · 직접 입력 {v:,} 메소 사용 중" if v != auto else ""))
            return v

        def section(title: str, icon: str):
            st.markdown(f"**:material/{icon}: {title}**")

        sub_craft, sub_sf, sub_cube, sub_grade = st.tabs([":material/construction: 직작 비용",
                                                           ":material/star: 스타포스 기대값",
                                                           ":material/casino: 큐브 옵션",
                                                           ":material/trending_up: 큐브 등급업"], on_change="rerun")

        # ---------- 스타포스 기대값 ----------
        with sub_sf:
            if sub_sf.open or ALL_TABS:
                left, right = st.columns([3, 2], gap="large")
                with left:
                    with st.container(border=True):
                        section("장비와 목표", "tune")
                        a, b, c = st.columns(3)
                        lv = a.number_input("렙제", 100, 300, 200, step=5)
                        top = sfc.max_star(int(lv))
                        s0 = b.number_input("현재 성", 0, top - 1, min(17, top - 1))
                        s1 = c.number_input("목표 성", int(s0) + 1, top, min(22, top))
                        a, b = st.columns(2)
                        mvp = a.selectbox("MVP 할인 (1~17성 시도)", list(sfc.MVP))
                        spare = b.number_input("스페어 1개 가격 (억)", 0.0, 10000.0, 0.0, step=0.5,
                                               help="파괴되면 새 장비(스페어)가 필요. 흔적 복구에도 스페어가 들어감")
                        pc = st.checkbox("PC방 5% (16성 이하)")
                    with st.container(border=True):
                        section("이벤트", "celebration")
                        ev = sf_event_picker("sf_events")
                    with st.container(border=True):
                        section("파괴 대비", "shield")
                        guard = st.pills("파방 (기본 비용 +200%)", [x for x in sfc.SAFEGUARD_STARS if s0 <= x < s1],
                                         selection_mode="multi", key="sf_guard")
                        restore = []
                        if int(lv) in sfc.RESTORE:
                            restore = st.pills("흔적 복구 사용 성 (파괴 시 12성 대신 그 성으로 복구)",
                                               [x for x in sfc.RESTORE[int(lv)] if x < s1], selection_mode="multi",
                                               key="sf_restore")
                        else:
                            st.caption("흔적 복구표는 130 · 135 · 140 · 145 · 150 · 160 · 200 · 250제만 있습니다.")
                setup = sfc.Setup(int(lv), int(s0), int(s1), ev, mvp, pc, set(guard or []), set(restore or []), spare * 1e8)
                e = sfc.expected(setup)
                sim = sfc.simulate(setup, n=20000)
                q = sim["cost_q"]
                with right:
                    with st.container(border=True):
                        st.metric(f"{lv}제 {s0}→{s1}성 평균 비용", f"{e['cost'] / 1e8:,.2f} 억")
                        st.caption(won_text(e["cost"]))
                        m1 = m2 = MetricRow(width=CALC_METRIC_W, border=False)  # wraps in the narrow result card
                        m1.metric("기대 파괴", f"{e['destroys']:.2f} 회")
                        m2.metric("무파괴 확률", f"{sim['no_destroy_prob']:.1%}")
                        qdf = pd.DataFrame({
                            "경우": ["운 좋음 (상위 10%)", "중앙값", "운 나쁨 (하위 10%)", "최악권 (하위 1%)"],
                            "비용": [q[0.1] / 1e8, q[0.5] / 1e8, q[0.9] / 1e8, q[0.99] / 1e8]})
                        if won_per_eok:
                            qdf["현금"] = [won_of(v * 1e8) for v in qdf["비용"]]
                        st.dataframe(qdf, hide_index=True, width="stretch", column_config={
                            "비용": st.column_config.NumberColumn(format="%,.2f 억"),
                            "현금": st.column_config.NumberColumn(format="%,d 원")})
                # clip the long right tail at the top 1 % so the bars use the width (UI 점검: 오른쪽 60 % 가 빈 공간)
                q99 = float(np.quantile(sim["costs"], 0.99)) / 1e8
                hist = pd.DataFrame({"비용 (억)": np.minimum(sim["costs"] / 1e8, q99)})
                st.altair_chart(alt.Chart(hist).mark_bar(color=ACCENT, cornerRadiusTopLeft=2, cornerRadiusTopRight=2).encode(
                    x=alt.X("비용 (억):Q", bin=alt.Bin(maxbins=70), title="총 비용 (억)"),
                    y=alt.Y("count():Q", title=None),
                    tooltip=[alt.Tooltip("비용 (억):Q", bin=alt.Bin(maxbins=70), title="비용 (억)"),
                             alt.Tooltip("count():Q", title="횟수")],
                ).properties(title=f"2만 회 시뮬레이션 비용 분포 (맨 오른쪽 막대 = 상위 1%, {q99:,.0f}억 이상)", height=260),
                    width="stretch")
                prob, cost, _, _ = sfc.tables(setup)
                with st.expander("★ 단계별 확률 · 1회 비용", icon=":material/table_chart:"):
                    st.dataframe(pd.DataFrame({"성": range(int(s0), int(s1)),
                                               "성공": prob[int(s0):int(s1), 0], "유지": prob[int(s0):int(s1), 1],
                                               "파괴": prob[int(s0):int(s1), 2],
                                               "1회 비용": cost[int(s0):int(s1)]}),
                                 hide_index=True, width="stretch", column_config={
                                     "성공": st.column_config.NumberColumn(format="percent"),
                                     "유지": st.column_config.NumberColumn(format="percent"),
                                     "파괴": st.column_config.NumberColumn(format="percent"),
                                     "1회 비용": st.column_config.NumberColumn(format="%,d 메소")})
                st.caption("확률 · 비용식 · 흔적 복구표: 메수라이브 공개 코드(2026-03-21, 스타캐치 상시 적용 반영)를 "
                           "파이썬으로 다시 구현. 공식 계산과 시뮬레이션이 0.3% 안에서 일치.")

        # ---------- 큐브 옵션 ----------
        # Goal model = mesulive's option sets: rows with the same 조합 number must all hold (AND), and any one
        # 조합 is enough (OR). Presets per part fill the table; the threshold table shows the cost curve.
        with sub_cube:
            if sub_cube.open or ALL_TABS:
                d = calc_cube.load()
                all_fams = list(calc_cube.FAMILIES) + list(calc_cube.COMBOS)
                MODE_KO = {"sum": "수치 합", "lines": "줄 수"}
                KO_MODE = {v: k for k, v in MODE_KO.items()}
                left, right = st.columns([3, 2], gap="large")
                with left:
                    with st.container(border=True):
                        section("장비", "checkroom")
                        c1, c2 = st.columns(2)
                        cube_id = c1.selectbox("큐브", list(calc_cube.CUBES), format_func=calc_cube.CUBES.get)
                        grade = c2.selectbox("등급", ["레전드리", "유니크"])
                        c1, c2 = st.columns(2)
                        part = c1.selectbox("부위", list(dict.fromkeys(d.loc[d.cube_id == cube_id, "part"])))
                        lev = c2.selectbox("렙제", sorted(d["req_lev"].unique()), index=1,
                                           help="확률 페이지의 레벨 구간 (160 · 200 · 250)")
                        c1, c2 = st.columns(2)
                        main = c1.segmented_control("주스탯", ["STR%", "DEX%", "INT%", "LUK%", "최대 HP%"], default="INT%",
                                                    format_func=lambda x: x.replace("최대 ", ""),
                                                    key="cube_main", help="주스탯%는 올스탯%도 같이 셉니다") or "INT%"
                        atk = c2.segmented_control("공격 스탯", ["공격력%", "마력%"], default="마력%", key="cube_atk") or "마력%"
                    tables = calc_cube.slot_tables(cube_id, grade, part, int(lev))

                    with st.container(border=True):
                        section("목표", "target")
                        pre = calc_cube.presets(part, main, atk, tables)
                        ver = st.session_state.setdefault("cube_goal_ver", 0)

                        def _apply(name: str):
                            rows = [{"조합": i + 1, "옵션": c["family"], "기준": MODE_KO[c["mode"]], "이상": float(c["min"])}
                                    for i, conds in enumerate(pre[name]) for c in conds]
                            st.session_state["cube_goal_rows"] = rows
                            st.session_state["cube_goal_ver"] += 1

                        if pre:
                            pick = st.pills("빠른 목표 (누르면 아래 표가 채워집니다)", list(pre), key=f"cube_preset_{part}_{main}_{atk}")
                            if pick and st.session_state.get("cube_preset_last") != (part, main, atk, pick):
                                st.session_state["cube_preset_last"] = (part, main, atk, pick)
                                _apply(pick)
                                st.rerun()
                        if "cube_goal_rows" not in st.session_state:
                            st.session_state["cube_goal_rows"] = [{"조합": 1, "옵션": main, "기준": "수치 합", "이상": 21.0}]
                        goal = st.data_editor(
                            pd.DataFrame(st.session_state["cube_goal_rows"], columns=["조합", "옵션", "기준", "이상"]),
                            num_rows="dynamic", hide_index=True, width="stretch", key=f"cube_goal_editor_{ver}",
                            column_config={
                                "조합": st.column_config.NumberColumn(min_value=1, max_value=6, step=1, default=1, width="small",
                                                                    help="같은 번호 = 모두 만족(그리고). 번호가 다르면 하나만 맞아도 성공(또는)."),
                                "옵션": st.column_config.SelectboxColumn(options=all_fams, required=True, width="medium"),
                                "기준": st.column_config.SelectboxColumn(options=list(KO_MODE), default="수치 합", required=True,
                                                                       width="small",
                                                                       help="수치 합: 세 줄의 값을 더함(예 INT 12+9=21). 줄 수: 그 옵션이 몇 줄 떴는지."),
                                "이상": st.column_config.NumberColumn(min_value=0.0, step=1.0, required=True, width="small"),
                            })
                        st.caption("같은 조합 번호끼리는 모두 만족해야 하고, 조합이 여러 개면 그중 하나만 맞아도 성공입니다. "
                                   "정확한 확률 계산(모든 줄 조합을 전부 셈)이며 시뮬레이션이 아닙니다.")
                        kind = "potential" if cube_id == "5062010" else "additional"
                        kind_ko = "윗잠" if kind == "potential" else "에디"
                        one = cost_box("재설정 1회 비용 (메소)", calc_cube.reset_cost(kind, int(lev), grade), "cube_one",
                                       f"비용표 {kind_ko} {lev}제 {grade}")

                g_ok = goal.dropna(subset=["옵션", "기준", "이상"])
                sets = [[{"family": r["옵션"], "mode": KO_MODE[r["기준"]], "min": float(r["이상"])} for _, r in grp.iterrows()]
                        for _, grp in g_ok.assign(조합=g_ok["조합"].fillna(1).astype(int)).groupby("조합")]
                p = calc_cube.success_prob_sets(tables, sets) if sets else 0.0
                with right:
                    with st.container(border=True):
                        if not sets:
                            st.metric("1회 성공 확률", "-")
                            st.caption("목표를 한 줄 이상 넣으세요.")
                        elif p:
                            n90 = calc_cube.cubes_needed(p, .9)
                            st.metric("평균 비용", f"{one / p / 1e8:,.2f} 억")
                            st.caption(won_text(one / p))
                            m1 = m2 = MetricRow(width=CALC_METRIC_W, border=False)  # wraps in the narrow result card
                            m1.metric("1회 성공 확률", f"{p:.3%}")
                            m2.metric("평균 횟수", f"{1 / p:,.0f} 회")
                            m1.metric("50% 성공까지", f"{calc_cube.cubes_needed(p, .5):,} 회")
                            m2.metric("90% 성공까지", f"{n90:,} 회")
                            st.metric("90% 성공까지 비용", f"{one * n90 / 1e8:,.2f} 억")
                            st.caption(won_text(one * n90))
                        else:
                            st.metric("1회 성공 확률", "불가능")
                            st.caption("이 부위 · 등급 · 렙제에서는 나올 수 없는 목표입니다.")
                        if sets:
                            words = [" 그리고 ".join(f"{c['family']} {c['min']:g}{'줄' if c['mode'] == 'lines' else ''} 이상"
                                                   for c in conds) for conds in sets]
                            st.markdown("**목표 해석**  \n" + "  \n또는 ".join(words))

                # cost curve for the first goal row: where does raising the target stop being worth it
                if len(g_ok):
                    f0, m0 = g_ok.iloc[0]["옵션"], KO_MODE[g_ok.iloc[0]["기준"]]
                    tt = calc_cube.threshold_table(tables, f0, m0)
                    if len(tt):
                        st.subheader(f"{f0} 목표치별 비용 ({MODE_KO[m0]})", divider=False)
                        tt["평균 횟수"] = 1 / tt["확률"]
                        tt["평균 비용"] = one * tt["평균 횟수"] / 1e8
                        tt["90% 성공까지"] = [one * calc_cube.cubes_needed(x, .9) / 1e8 for x in tt["확률"]]
                        if won_per_eok:
                            tt["평균 현금"] = [won_of(v * 1e8) for v in tt["평균 비용"]]
                        pct_txt = [f"{x * 100:.2f}%" if x >= 1e-3 else f"{x * 100:.4f}%" for x in tt["확률"]]
                        st.dataframe(tt.assign(확률=pct_txt), hide_index=True, width="stretch", column_config={
                            "목표": st.column_config.NumberColumn(format="%g 이상" if m0 == "sum" else "%d줄 이상"),
                            "평균 횟수": st.column_config.NumberColumn(format="%,d 회"),
                            "평균 비용": st.column_config.NumberColumn(format="%,.2f 억"),
                            "90% 성공까지": st.column_config.NumberColumn(format="%,.2f 억"),
                            "평균 현금": st.column_config.NumberColumn(format="%,d 원")})
                        st.caption("이 옵션 하나만 볼 때의 값입니다(다른 조건 없이). 목표를 한 단계 올릴 때 비용이 몇 배로 뛰는지 보고 "
                                   "멈출 지점을 고르세요.")
                with st.expander("줄별 옵션 확률표", icon=":material/table_chart:"):
                    cols = st.columns(3)
                    for i, t in enumerate(tables):
                        cols[i].markdown(f"**{i + 1}번째 줄**")
                        cols[i].dataframe(t.assign(확률=t["p"] * 100)[["option", "확률"]].rename(columns={"option": "옵션"}),
                                          hide_index=True, width="stretch", height=420,
                                          column_config={"확률": st.column_config.NumberColumn(format="%.3f%%")})
                st.caption("출처: 메이플스토리 홈페이지 큐브 옵션 확률 (2026-09-18 수집). 줄 수 제한(쓸만한 · 무적시간 1줄, "
                           "피격 무시 · 피격 무적 2줄)은 메수라이브 방식. 목표 방식(조합 = 그리고, 조합끼리 = 또는)은 메수라이브의 "
                           "옵션 세트와 같습니다. 미라클 타임은 등급 상승 확률만 2배라 옵션 확률은 그대로입니다.")

        # ---------- 큐브 등급업 ----------
        with sub_grade:
            if sub_grade.open or ALL_TABS:
                g = calc_cube.gradeup_table()
                left, right = st.columns([3, 2], gap="large")
                with left:
                    with st.container(border=True):
                        section("재설정 방식", "tune")
                        method = st.selectbox("재설정 방식", list(dict.fromkeys(g["method"])), label_visibility="collapsed")
                        gm = g[g["method"] == method]
                        c1, c2 = st.columns(2)
                        step = c1.selectbox("등급 단계", gm["step"].tolist(), index=len(gm) - 1)
                        glev = c2.number_input("렙제", 1, 300, 200, key="glev")
                        miracle = st.toggle("미라클 타임 (등업 확률 2배)", key="g_miracle", help=MIRACLE_HELP)
                        row = gm[gm["step"] == step].iloc[0]
                        from_grade = step.split(" → ")[0]
                        gkind = "additional" if "에디셔널" in method else "potential"
                        meso_based = method.startswith(("잠재능력 재설정", "에디셔널 잠재능력 재설정"))
                        default_cost = calc_cube.reset_cost(gkind, int(glev), from_grade) if meso_based else 0
                        band = max(b for b in (1, 160, 200, 250) if b <= int(glev))
                        band_ko = "160 미만" if band == 1 else f"{band}~"
                        gone = cost_box("1회 비용 (메소)", default_cost, "gone",
                                        f"비용표 {'에디' if gkind == 'additional' else '윗잠'} {band_ko}제 {from_grade}"
                                        if meso_based else "큐브 아이템은 1개 시세를 메소로 넣으세요")
                        has_ceil = bool(row["ceil"]) and not pd.isna(row["ceil"])
                        done = int(st.number_input("지금까지 쌓인 천장 횟수", 0, max(0, int(row["ceil"]) - 1) if has_ceil else 0, 0,
                                                   key=f"g_done_{method}_{step}", disabled=not has_ceil,
                                                   help="이 재설정 방식 · 등급으로 이미 쌓인 천장 카운트(같은 월드 캐릭터끼리 공유). "
                                                        "남은 횟수만으로 평균 · 천장을 다시 계산합니다.")) if has_ceil else 0
                gp = min(1.0, float(row["prob"]) * (2 if miracle else 1))
                stats = calc_cube.gradeup_stats(gp, row["ceil"], done)
                with right:
                    with st.container(border=True):
                        if gone:
                            st.metric(f"{step} 평균 비용", f"{gone * stats['mean'] / 1e8:,.2f} 억")
                            st.caption(won_text(gone * stats["mean"]))
                        m1 = m2 = MetricRow(width=CALC_METRIC_W, border=False)  # wraps in the narrow result card
                        m1.metric("1회 확률", f"{gp:.2%}", delta="미라클 2배" if miracle else None, delta_color="off")
                        m2.metric("평균 횟수", f"{stats['mean']:,.1f} 회")
                        m1.metric("50% 성공까지", f"{stats['q50']} 회")
                        m2.metric("90% 성공까지", f"{stats['q90']} 회")
                        m2.metric("남은 천장" if done else "천장", f"{stats['max']} 회" if stats["max"] else "없음")
                        if gone and stats["max"]:
                            st.metric("천장까지 비용", f"{gone * stats['max'] / 1e8:,.2f} 억")
                with st.expander("공식 등업 확률 · 천장 전체", icon=":material/table_chart:"):
                    st.dataframe(g.rename(columns={"method": "방식", "step": "단계", "prob": "확률", "ceil": "천장"})
                                 .drop(columns="page"), hide_index=True, width="stretch",
                                 column_config={"확률": st.column_config.NumberColumn(format="percent"),
                                                "천장": st.column_config.NumberColumn(format="%d 회")})
                st.caption("출처: 메이플스토리 홈페이지 확률형 아이템 > 큐브 (2026-09-18 수집). 천장(등업 보장 횟수)은 "
                           "재설정 방식 · 등급별로 쌓이고 같은 월드의 내 캐릭터끼리 공유됩니다(공식 안내).")

        # ---------- 직작 비용 ----------
        with sub_craft:
            if sub_craft.open or ALL_TABS:
                left, right = st.columns([3, 2], gap="large")
                with left:
                    with st.container(border=True):
                        section("스타포스", "star")
                        a, b, c, d = st.columns(4)
                        clev = a.number_input("렙제", 100, 300, 200, step=5, key="clev")
                        ctop = sfc.max_star(int(clev))
                        cs0 = b.number_input("현재 성", 0, ctop - 1, 0, key="cs0")
                        cs1 = c.number_input("목표 성", int(cs0) + 1, ctop, min(22, ctop), key="cs1")
                        cmvp = d.selectbox("MVP 할인", list(sfc.MVP), key="cmvp", help="1~17성 시도에만 적용")
                        cev = sf_event_picker("craft_sf_events")
                        cspare = st.number_input("스페어 1개 가격 (억, 파괴 시 새 장비)", 0.0, 10000.0, 0.0, step=0.5,
                                                 key="cspare")
                    with st.container(border=True):
                        section("윗잠", "auto_awesome")
                        a, b = st.columns(2)
                        parts = list(dict.fromkeys(calc_cube.load().query("cube_id == '5062010'")["part"]))
                        cpart = a.selectbox("부위", parts, index=parts.index("모자") if "모자" in parts else 0)
                        cgrade_from = b.selectbox("현재 윗잠 등급", ["레어", "에픽", "유니크", "레전드리"], index=0)
                        a, b = st.columns(2)
                        cfam = a.selectbox("목표 옵션", list(calc_cube.FAMILIES), index=2, key="cfam")
                        cmin = b.number_input("목표 수치 합 이상 (0 = 옵션 목표 없음)", 0.0, 100.0, 30.0, key="cmin")
                        cmiracle = st.toggle("미라클 타임 (등업 확률 2배)", key="c_miracle", help=MIRACLE_HELP)
                    with st.container(border=True):
                        section("주문서 · 완제품 비교", "receipt_long")
                        a, b = st.columns(2)
                        cscroll = a.number_input("주문서 작 비용 합계 (억)", 0.0, 10000.0, 0.0, step=0.6, key="cscroll",
                                                 help="2026-09-17부터 주문서를 메소로 삽니다(공식 패치노트 813): 프악공 · 매지컬 "
                                                      "100% 6,000만, 귀 장식 10% 1억, 놀긍 60% 50만 · 100% 3억, 리턴 4억.")
                        buy = b.number_input("완제품 가격 (억, 경매장)", 0.0, 1e6, 0.0, step=1.0, key="cbuy")

                sf_cost = sfc.expected(sfc.Setup(int(clev), int(cs0), int(cs1), cev, cmvp,
                                                 spare_cost=cspare * 1e8))["cost"]
                gb = calc_cube.gradeup_table()
                gb = gb[gb["method"] == "잠재능력 재설정/블랙 큐브"].set_index("step")
                grades = ["레어", "에픽", "유니크", "레전드리"]
                up_cost = 0.0
                for i in range(grades.index(cgrade_from), 3):
                    r = gb.loc[f"{grades[i]} → {grades[i + 1]}"]
                    up_cost += (calc_cube.gradeup_stats(min(1.0, float(r["prob"]) * (2 if cmiracle else 1)), r["ceil"])["mean"]
                                * calc_cube.reset_cost("potential", int(clev), grades[i]))
                # official cube tables switch to the 250 values from 201제 (kb potential_option_values, 2026-09-27)
                lev_band = 250 if int(clev) >= 201 else (200 if int(clev) >= 200 else 160)
                opt_cost, opt_p = 0.0, None
                if cmin > 0:
                    ct = calc_cube.slot_tables("5062010", "레전드리", cpart, lev_band)
                    opt_p = calc_cube.success_prob(ct, [{"family": cfam, "mode": "sum", "min": cmin}])
                    opt_cost = calc_cube.reset_cost("potential", int(clev), "레전드리") / opt_p if opt_p else math.inf
                scroll_cost = cscroll * 1e8
                total_cost = sf_cost + up_cost + opt_cost + scroll_cost
                cdf = pd.DataFrame([(f"스타포스 {cs0}→{cs1}성", sf_cost), (f"윗잠 등급업 {cgrade_from}→레전드리", up_cost),
                                    (f"윗잠 옵션 {cfam} {cmin:g}+" + (f" (1회 {opt_p:.3%})" if opt_p else ""), opt_cost),
                                    ("주문서 작", scroll_cost)], columns=["항목", "메소"])
                cdf["억"] = cdf["메소"] / 1e8
                cdf["비중"] = cdf["메소"] / total_cost * 100 if math.isfinite(total_cost) and total_cost else 0.0
                if won_per_eok:
                    cdf["현금"] = cdf["메소"].map(won_of)
                with right:
                    with st.container(border=True):
                        if math.isfinite(total_cost):
                            st.metric("평균 총비용", f"{total_cost / 1e8:,.2f} 억")
                            st.caption(won_text(total_cost))
                        else:
                            st.metric("평균 총비용", "불가능")
                            st.caption("목표 옵션이 이 부위에서 나올 수 없습니다.")
                        st.dataframe(cdf[["항목", "억", "비중"]], hide_index=True, width="stretch",
                                     column_config={"억": st.column_config.NumberColumn(format="%,.1f"),
                                                    "비중": st.column_config.ProgressColumn(
                                                        format="%.0f%%", min_value=0, max_value=100, color="primary")})
                        if buy and math.isfinite(total_cost):
                            diff = buy * 1e8 - total_cost
                            if diff > 0:
                                st.success(f"직작이 평균 **{diff / 1e8:,.2f}억** 쌉니다.", icon=":material/check_circle:")
                            else:
                                st.warning(f"사는 게 평균 **{-diff / 1e8:,.2f}억** 쌉니다.", icon=":material/shopping_cart:")
                st.caption("평균값 기준입니다. 스타포스는 운에 따라 크게 흔들리니 '스타포스 기대값' 탭의 하위 10% 비용도 같이 보세요. "
                           "에디는 합산에 넣지 않았습니다.")

# ---------- event calendar ----------
# 미라클 · 샤이닝 · 주흔 할인 이력과 주기 (2026-09-27 user request). Next dates are estimates from past gaps.
with tab_event:
    if tab_event.open or ALL_TABS:
        ev = events.load()
        today = pd.Timestamp(db.now_kst().date())
        cyc = events.cycles(ev, today)
        ICON = {"미라클 타임": "auto_awesome", "샤이닝 스타포스": "star", "주흔 50%": "receipt_long", "10성 이하 1+1": "exposure_plus_1"}
        def window_text(r) -> str:
            """Next expected window from tomorrow on; the cards and the 주기 table use this same text (UI 점검: 불일치)."""
            if pd.isna(r.get("next_from")):
                return "-"
            f, t = max(r["next_from"], today + pd.Timedelta(days=1)), r["next_to"]
            return f"{f:%m-%d} ~ {t:%m-%d}" if f <= t else "예상 구간 지남"
        c = MetricRow()
        for r in cyc[cyc["kind"].isin(list(ICON))].to_dict("records"):
            if r["days_since"] == 0:
                val, delta = "오늘 진행 중", None
            elif pd.notna(r.get("next_from")):
                val = window_text(r)
                delta = f"마지막 {r['last']:%m-%d} ({r['days_since']}일 전)"
            else:
                val, delta = "-", None
            c.metric(r["kind"], val, delta=delta, delta_color="off", icon=f":material/{ICON[r['kind']]}:",
                     help=(f"최근 간격 {r['gap_min']:.0f}~{r['gap_max']:.0f}일, 평균 {r['gap_mean']:.0f}일 · 총 {r['count']}회"
                           if pd.notna(r.get("gap_mean")) else f"총 {r['count']}회"))
        st.caption("카드 값은 다음 개최 예상 구간입니다(최근 개최 간격의 최소 ~ 최대). 공지가 아니라 과거 주기로 본 추정이며, "
                   "2026-10 썬데이는 09-27 기준 아직 공지 전입니다.")

        kinds = [k for k in events.KIND_ORDER if k in set(ev["kind"])]
        # one colour per event from the validated chart palette (.streamlit/config.toml, per mode)
        PAL = (["#3987e5", "#d95926", "#199e70", "#c98500", "#d55181", "#008300", "#9085e9", "#e66767"] if DARK else
               ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948"])
        kcolor = alt.Scale(domain=kinds, range=[PAL[events.KIND_ORDER.index(k) % len(PAL)] for k in kinds])
        _eh = st.container(horizontal=True, vertical_alignment="center")
        _eh.subheader("개최 이력과 다음 예상", divider=False)  # same style as 주기 · 이벤트 날 강화
        show_all_ev = _eh.toggle("전체 이력", value=False, key="ev_all", help="끄면 최근 12개월 + 앞으로 3개월만 봅니다")
        x0 = ev["date"].min() - pd.Timedelta(days=10) if show_all_ev else today - pd.DateOffset(months=12)
        x1 = today + pd.DateOffset(months=3)
        evv = ev[ev["date"] >= x0]
        if not show_all_ev:  # rows with nothing in the window (one-off events) only show in 전체 이력
            _live = set(evv["kind"]) | set(cyc.dropna(subset=["next_from"])["kind"])
            kinds = [k for k in kinds if k in _live]
            kcolor = alt.Scale(domain=kinds, range=[PAL[events.KIND_ORDER.index(k) % len(PAL)] for k in kinds])
        xs = alt.Scale(domain=[x0.isoformat(), x1.isoformat()])
        # month labels "10월", with the year on January
        xaxis = alt.Axis(format="%m", tickCount="month", grid=True, gridOpacity=0.35, domain=False, ticks=False,
                         labelExpr="month(datum.value) == 0 ? timeFormat(datum.value, '%Y') : "
                                   "(month(datum.value) + 1) + '월'", labelPadding=8)
        yaxis = alt.Axis(labelLimit=220, labelFontSize=13, labelPadding=12, domain=False, ticks=False)
        y = alt.Y("kind:N", sort=kinds, title=None, axis=yaxis)
        track = alt.Chart(pd.DataFrame({"kind": kinds})).mark_rule(color=MUTED, opacity=0.25, strokeWidth=1).encode(y=y)
        win = cyc.dropna(subset=["next_from"]).assign(
            next_from=lambda d: d["next_from"].clip(lower=today), next_to=lambda d: d["next_to"])
        win = win[win["next_from"] <= win["next_to"]]
        band = alt.Chart(win).mark_bar(opacity=0.28, height=20, cornerRadius=10).encode(
            x=alt.X("next_from:T", scale=xs, axis=xaxis, title=None), x2="next_to:T", y=y,
            color=alt.Color("kind:N", scale=kcolor, legend=None),
            tooltip=[alt.Tooltip("kind:N", title="이벤트"), alt.Tooltip("next_from:T", format="%Y-%m-%d", title="예상 시작"),
                     alt.Tooltip("next_to:T", format="%Y-%m-%d", title="예상 끝")])
        band_txt = alt.Chart(win).mark_text(align="left", dx=8, fontSize=11, fontWeight="bold").encode(
            x="next_from:T", y=y, text=alt.value("예상"), color=alt.Color("kind:N", scale=kcolor, legend=None))
        pts = alt.Chart(evv).mark_point(filled=True, size=230, opacity=1, stroke=SURFACE, strokeWidth=2).encode(
            x=alt.X("date:T", scale=xs, axis=xaxis, title=None), y=y,
            color=alt.Color("kind:N", scale=kcolor, legend=None),
            tooltip=[alt.Tooltip("date:T", format="%Y-%m-%d", title="날짜"), alt.Tooltip("kind:N", title="이벤트"),
                     alt.Tooltip("detail:N", title="내용"), alt.Tooltip("source:N", title="출처")])
        tdf = pd.DataFrame({"d": [today], "t": ["오늘"]})
        rule = alt.Chart(tdf).mark_rule(color=MUTED, strokeDash=[4, 4], strokeWidth=1.5).encode(x="d:T")
        rule_txt = alt.Chart(tdf).mark_text(dy=-8, fontSize=11, fontWeight="bold", color=MUTED, baseline="bottom").encode(
            x="d:T", y=alt.value(0), text="t:N")
        st.altair_chart((track + band + band_txt + pts + rule + rule_txt)
                        .properties(height=70 + 46 * len(kinds), padding={"top": 18, "left": 4, "right": 12, "bottom": 4})
                        .configure_view(strokeWidth=0), width="stretch")
        st.caption("점 = 개최한 날, 둥근 막대 = 다음 예상 구간(과거 간격으로 본 추정), 점선 = 오늘. 점에 마우스를 올리면 내용과 출처가 나옵니다.")

        st.subheader("주기", divider=False)
        tbl = cyc.assign(마지막=cyc["last"].dt.strftime("%Y-%m-%d"),
                         예상=[window_text(r) for r in cyc.to_dict("records")])
        for _c in ("gap_min", "gap_mean", "gap_max"):  # one-off events have no gap: show "-" (Streamlit prints NaN as None)
            tbl[_c] = [f"{x:.0f}일" if pd.notna(x) else "-" for x in pd.to_numeric(tbl[_c], errors="coerce")]
        st.dataframe(tbl[["kind", "count", "마지막", "days_since", "gap_min", "gap_mean", "gap_max", "예상"]]
                     .rename(columns={"kind": "이벤트", "count": "횟수", "days_since": "지난 날", "gap_min": "최소 간격",
                                      "gap_mean": "평균 간격", "gap_max": "최대 간격", "예상": "다음 예상"}),
                     hide_index=True, width="stretch", column_config={
                         "지난 날": st.column_config.NumberColumn(format="%d일")})

        act = events.my_activity(ev)
        st.subheader("이벤트 날 내가 한 강화", divider=False)
        if act.empty:
            st.caption("이벤트 날짜와 겹치는 강화 기록이 없습니다(강화 기록은 받아 둔 기간만 있습니다).")
        else:
            cols = [x for x in ("cube", "potential", "soul-potential", "starforce") if x in act]
            st.dataframe(act.sort_values("date", ascending=False)[["date", "kind", "detail"] + cols]
                         .rename(columns={"date": "날짜", "kind": "이벤트", "detail": "내용", "cube": "큐브",
                                          "potential": "메소 재설정", "soul-potential": "소울 재설정", "starforce": "스타포스"}),
                         hide_index=True, width="stretch",
                         column_config={"날짜": st.column_config.DateColumn(format="YYYY-MM-DD")})
        with st.expander("전체 이력", icon=":material/list:"):
            st.dataframe(ev.sort_values("date", ascending=False).rename(
                columns={"date": "날짜", "kind": "이벤트", "detail": "내용", "source": "출처"}),
                hide_index=True, width="stretch", column_config={"날짜": st.column_config.DateColumn(format="YYYY-MM-DD")})
        st.caption("출처: 넥슨 공지(maplestory.nexon.com/News/Event/번호), 인벤 역대 썬데이 정리(47579), 10_조사/20260926_강화이벤트_조사.md.")

# ---------- 사용설명서 ----------
with tab_manual:
    if tab_manual.open or ALL_TABS:
        manual_view.render(manual_view.load())

# ---------- 체크리스트 ----------
# daily / weekly progress per character from the scheduler snapshot (roadmap 06 rank 1, 2026-09-27)
with tab_check:
    if tab_check.open or ALL_TABS:
        ck_names = main_first(cfg.get("characters") or basic["name"].unique())
        ck = checklist.latest(list(ck_names))
        now_kst = db.now_kst().replace(tzinfo=None)
        rs = checklist.next_resets(now_kst)

        def left(t):
            s = int((t - now_kst).total_seconds())
            return f"{s // 86400}일 {s % 86400 // 3600}시간" if s >= 86400 else f"{s // 3600}시간 {s % 3600 // 60}분"
        r0 = MetricRow()
        r0.metric("일일 초기화까지", left(rs["daily"]), icon=":material/schedule:", help="매일 00:00")
        r0.metric("주간 보스 · 에픽 던전 초기화", left(rs["thursday"]), icon=":material/swords:", help="목요일 00:00")
        r0.metric("주간 퀘스트 초기화", left(rs["monday"]), icon=":material/calendar_today:", help="월요일 00:00 [추정]")
        show_all = st.toggle("스케줄러에 등록 안 한 항목도 보기", value=False, key="ck_all",
                             help="게임 안 스케줄러에 등록한 항목만 기본으로 보여 줍니다")
        if not ck:
            st.info("스케줄러 정보가 없습니다. '지금 갱신' 을 눌러 주세요.")
        cols = st.columns(min(3, max(1, len(ck))))
        for i, (n, v) in enumerate(ck.items()):
            with cols[i % len(cols)]:
                with st.container(border=True):
                    head = st.container(horizontal=True, vertical_alignment="center", gap="small")
                    if CHAR_IMG.get(n):
                        head.image(CHAR_IMG[n], width=56)
                    head.markdown(f"**{'★ ' if n == MAIN else ''}{n}**  \n:gray-badge[{v['class']}] :orange-badge[Lv.{v['level']}]")
                    st.progress(min(1.0, v["boss_count"] / v["boss_limit"]),
                                text=f"주간 보스 {v['boss_count']} / {v['boss_limit']}")
                    for key, title in (("daily", "오늘 할 일"), ("weekly", "이번 주 할 일")):
                        items = [x for x in v[key] if show_all or x["registered"]]
                        done = sum(x["done"] for x in items)
                        st.progress(done / len(items) if items else 0.0, text=f"{title} {done} / {len(items)}")
                        # open when something is left (UI 점검: 기본 접힘이라 남은 일이 안 보였음)
                        with st.expander(f"{title} 목록", icon=":material/checklist:", expanded=done < len(items)):
                            if not items:
                                st.caption("등록된 항목이 없습니다.")
                            for x in sorted(items, key=lambda x: x["done"]):
                                cnt = f" ({x['now']}/{x['max']})" if x["max"] else ""
                                mark = ":green[:material/check_circle:]" if x["done"] else ":gray[:material/radio_button_unchecked:]"
                                st.markdown(f"{mark} {x['name']}{cnt}")
                    wk = checklist.weekly_bosses(v["bosses"], show_all)  # cleared ones even if not in the scheduler
                    if wk:
                        # boss grid: cleared = full colour with a check, left = faded (UI 점검: 글자뿐이던 목록)
                        cells = []
                        for b in sorted(wk, key=lambda b: (b["done"], b["name"])):
                            ic = boss_icon(b["name"])
                            img = (f"<img src='{ic}' style='width:44px;height:44px;border-radius:8px;"
                                   f"opacity:{1 if b['done'] else .32}'>" if ic else
                                   "<div style='width:44px;height:44px;border-radius:8px;border:1px dashed rgba(128,128,128,.5)'></div>")
                            tick = "✓ " if b["done"] else ""
                            cells.append(f"<div title='{b['name']} {DIFF_KO.get(b['diff'], b['diff'])}' style='display:inline-block;"
                                         f"width:64px;margin:3px;text-align:center;font-size:.72rem;line-height:1.2'>{img}<br>"
                                         f"{tick}{DIFF_KO.get(b['diff'], b['diff'])}<br><span style='opacity:.7'>"
                                         f"{b['name'][:6]}</span></div>")
                        # count = NEXON weekly_boss_clear_count / limit (12), same as the bar above
                        st.markdown(f"**:material/swords: 이번 주 보스** {v['boss_count']} / {v['boss_limit']}")
                        st.markdown("<div>" + "".join(cells) + "</div>", unsafe_allow_html=True)
                    st.caption(f"기준 {v['fetched_at'][:16].replace('T', ' ')} (지금 갱신을 누른 시점)")
        st.caption("넥슨 스케줄러 API 기준입니다. 에픽 던전은 최대 횟수가 0 으로 와서 한 번이라도 했으면 완료로 셉니다. "
                   "무릉도장은 API 가 0/0 으로 줘서 판정하지 않습니다.")
