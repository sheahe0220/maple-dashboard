"""Daily / weekly checklist per character from the scheduler snapshot (no extra API calls).

Why: roadmap 06 rank 1 (2026-09-27): what is left today / this week, weekly boss count and reset countdowns.
Field rules measured on the DB (05_스펙업수단_일퀘_연동.md B): quests are done when quest_state == "2";
contents with max_count 0 (에픽 던전) are done when now_count > 0; registration_flag "true" = the user added it to
the in-game scheduler. Resets: daily 00:00, weekly boss / 에픽 던전 Thursday 00:00 (DB + official 2024-08-08),
weekly quests Monday 00:00 [추정].

Self-test:
    C:\\Users\\jeong\\Documents\\story\\.venv\\Scripts\\python.exe -X utf8 C:\\Users\\jeong\\Documents\\story\\checklist.py
"""
import json
from datetime import datetime, timedelta

import db

QUEST_DONE = "2"


def _done(c: dict) -> bool:
    if c.get("type") == "quest":
        return str(c.get("quest_state")) == QUEST_DONE
    now, mx = int(c.get("now_count") or 0), int(c.get("max_count") or 0)
    return now >= mx if mx > 0 else now > 0


def latest(names: list[str]) -> dict:
    """name -> {date, fetched_at, level, class, boss (count, limit, list), daily [...], weekly [...]}."""
    con = db.connect()
    out = {}
    for n in names:
        row = con.execute("SELECT s.date, s.fetched_at, s.json FROM snapshot s JOIN characters c USING (ocid) "
                          "WHERE c.name=? AND s.endpoint='scheduler' AND s.json NOT LIKE '%_error%' "
                          "ORDER BY s.date DESC LIMIT 1", (n,)).fetchone()
        if not row:
            continue
        d = json.loads(row[2])
        items = lambda key: [{"name": c["content_name"], "type": c.get("type"), "registered": str(c.get("registration_flag")) == "true",
                              "done": _done(c), "now": int(c.get("now_count") or 0), "max": int(c.get("max_count") or 0)}
                             for c in d.get(key) or []]
        bosses = [{"name": b["content_name"], "diff": b.get("difficulty"), "cycle": b.get("cycle"),
                   "registered": str(b.get("registration_flag")) == "true", "done": str(b.get("complete_flag")) == "true"}
                  for b in d.get("boss_contents") or []]
        out[n] = {"date": row[0], "fetched_at": row[1], "level": d.get("character_level"), "class": d.get("character_class"),
                  "boss_count": int(d.get("weekly_boss_clear_count") or 0),
                  "boss_limit": int(d.get("weekly_boss_clear_limit_count") or 12) or 12,
                  "bosses": bosses, "daily": items("daily_contents"), "weekly": items("weekly_contents")}
    con.close()
    return out


def next_resets(now: datetime) -> dict:
    """KST now -> next daily (00:00), Thursday 00:00 (weekly boss · 에픽 던전), Monday 00:00 (weekly quests)."""
    day = (now + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)

    def next_weekday(wd: int) -> datetime:
        d = (wd - now.weekday()) % 7 or 7
        return (now + timedelta(days=d)).replace(hour=0, minute=0, second=0, microsecond=0)
    return {"daily": day, "thursday": next_weekday(3), "monday": next_weekday(0)}


def selftest() -> None:
    assert _done({"type": "quest", "quest_state": "2"}) and not _done({"type": "quest", "quest_state": "0"})
    assert _done({"type": "contents", "now_count": 14, "max_count": 14})
    assert _done({"type": "contents", "now_count": 5, "max_count": 0})  # 에픽 던전
    assert not _done({"type": "contents", "now_count": 0, "max_count": 1})
    r = next_resets(datetime(2026, 9, 27, 5, 0))  # Sunday
    assert r["thursday"] == datetime(2026, 10, 1) and r["monday"] == datetime(2026, 9, 28) and r["daily"] == datetime(2026, 9, 28)
    con = db.connect()
    names = [x[0] for x in con.execute("SELECT DISTINCT c.name FROM snapshot s JOIN characters c USING (ocid) "
                                       "WHERE s.endpoint='scheduler' LIMIT 3")]
    con.close()
    data = latest(names)
    assert data, "no scheduler snapshot"
    for n, v in data.items():
        reg_d = [x for x in v["daily"] if x["registered"]]
        print(n, v["date"], f"보스 {v['boss_count']}/{v['boss_limit']}", f"일일 {sum(x['done'] for x in reg_d)}/{len(reg_d)}")
    print("selftest ok")


if __name__ == "__main__":
    selftest()
