@echo off
chcp 65001 >nul
rem Stops the hidden dashboard started by the desktop shortcut (whatever listens on port 8501).
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":8501" ^| findstr "LISTENING"') do taskkill /PID %%p /F
echo 대시보드를 껐습니다.
timeout /t 2 >nul
