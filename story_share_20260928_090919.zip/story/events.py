"""Enhancement event history (미라클 타임 · 샤이닝 스타포스 · 주흔 할인 ...) and next-date estimates.

Why: 2026-09-27 user: "미라클 데이 어떻게 되고 있는지 주기 같은 게 있을 수 있으니, 이때 이런 거 했다 ... 사이트에 넣어 주면".
Data: ref/event_history_20260927.csv, built from 10_조사/20260926_강화이벤트_조사.md (official notices
https://maplestory.nexon.com/News/Event/ID + 인벤 47579 date list) and data/kb/events_2026_09_10.csv.
Next dates are estimates from past intervals, not announcements (October 2026 was not announced on 2026-09-27).

Self-test:
    C:\\Users\\jeong\\Documents\\story\\.venv\\Scripts\\python.exe -X utf8 C:\\Users\\jeong\\Documents\\story\\events.py
"""
import json
from pathlib import Path

import pandas as pd

import db

CSV = Path(__file__).resolve().parent / "ref" / "event_history_20260927.csv"

# (date, kind, detail, source) ; kinds are the effects players plan around
_ROWS = [
    ("2025-01-19", "미라클 타임", "", "공식 1086"),
    ("2025-04-20", "미라클 타임", "천장 1회씩(이후 계속)", "공식 1124"),
    ("2025-06-29", "미라클 타임", "", "인벤 47579"),
    ("2025-10-19", "미라클 타임", "", "인벤 47579"),
    ("2026-01-04", "미라클 타임", "", "인벤 47579"),
    ("2026-03-01", "미라클 타임", "", "공식 1283"),
    ("2026-05-10", "미라클 타임", "", "게임플 2026-05-08"),
    ("2026-06-28", "미라클 타임", "+ 어빌리티 50%", "공식 1352"),
    ("2026-08-02", "미라클 타임", "", "공식 1367"),
    ("2026-09-27", "미라클 타임", "소울 잠재 재설정 첫 포함", "공식 1391"),
    ("2025-01-05", "샤이닝 스타포스", "30% 할인 + 5·10·15성 100%", "인벤 47579"),
    ("2025-03-02", "샤이닝 스타포스", "30% 할인 + 5·10·15성 100%", "공식 1105"),
    ("2025-05-04", "샤이닝 스타포스", "30% 할인 + 파괴 30% 감소", "인벤 47579"),
    ("2025-07-20", "샤이닝 스타포스", "30% + 파괴 감소 + 5·10·15성 100%", "공식 1177"),
    ("2025-09-21", "샤이닝 스타포스", "30% 할인 + 파괴 30% 감소", "인벤 47579"),
    ("2025-11-16", "샤이닝 스타포스", "30% 할인 + 파괴 30% 감소", "인벤 47579"),
    ("2025-12-14", "샤이닝 스타포스", "30% 할인 + 파괴 30% 감소", "인벤 47579"),
    ("2026-01-18", "샤이닝 스타포스", "30% 할인 + 파괴 30% 감소", "인벤 47579"),
    ("2026-02-15", "샤이닝 스타포스", "30% 할인 + 파괴 30% 감소", "인벤 47579"),
    ("2026-03-29", "샤이닝 스타포스", "+ 흔적 복구 20% (첫 등장)", "공식 1302"),
    ("2026-04-26", "샤이닝 스타포스", "30% + 파괴 감소 + 흔적 복구 20%", "인벤 47579"),
    ("2026-05-31", "샤이닝 스타포스", "30% + 파괴 감소 + 흔적 복구 20%", "인벤 47579"),
    ("2026-07-05", "샤이닝 스타포스", "30% + 파괴 감소 + 흔적 복구 20%", "인벤 47579"),
    ("2026-08-16", "샤이닝 스타포스", "+ HEXA 스탯", "공식 1369"),
    ("2026-09-06", "샤이닝 스타포스", "30% + 파괴 감소 + 흔적 복구 20%", "공식 1377"),
    ("2025-02-02", "10성 이하 1+1", "", "공식 1090"),
    ("2025-06-15", "10성 이하 1+1", "", "인벤 47579"),
    ("2025-07-06", "10성 이하 1+1", "", "인벤 47579"),
    ("2025-08-03", "10성 이하 1+1", "", "인벤 47579"),
    ("2025-08-24", "10성 이하 1+1", "", "인벤 47579"),
    ("2026-01-11", "10성 이하 1+1", "", "인벤 47579"),
    ("2026-07-12", "10성 이하 1+1", "+ 주흔 50% · 어빌리티 50%", "공식 1355"),
    ("2025-03-23", "주흔 50%", "+ 21성 이하 파괴 30% 감소(단독)", "공식 1112"),
    ("2026-07-12", "주흔 50%", "1+1 과 함께", "공식 1355"),
    ("2026-08-30", "주흔 50%", "", "공식 1376"),
    ("2026-09-20", "주흔 50%", "메소 주문서는 미적용", "공식 1390"),
    ("2025-04-06", "스타포스 30% 할인(단독)", "+ HEXA 스탯", "공식 1115"),
    ("2025-05-18", "5·10·15성 100%(단독)", "마지막 개최", "인벤 47579"),
]
KIND_ORDER = ["미라클 타임", "샤이닝 스타포스", "주흔 50%", "10성 이하 1+1", "스타포스 30% 할인(단독)", "5·10·15성 100%(단독)"]


MAX_GAP = 180  # days; gaps above this are pauses (e.g. 주흔 50% 2025-03 -> 2026-07), not the cycle


def _sunday_on_or_after(d: pd.Timestamp) -> pd.Timestamp:
    """썬데이 메이플 events are on Sundays (weekday 6)."""
    return d + pd.Timedelta(days=(6 - d.weekday()) % 7)


def _sunday_on_or_before(d: pd.Timestamp) -> pd.Timestamp:
    return d - pd.Timedelta(days=(d.weekday() - 6) % 7)


def build_csv() -> Path:
    """Write the history table once (the file is data, kept next to the other ref tables)."""
    df = pd.DataFrame(_ROWS, columns=["date", "kind", "detail", "source"]).sort_values(["kind", "date"])
    df.to_csv(CSV, index=False, encoding="utf-8-sig")
    return CSV


def load() -> pd.DataFrame:
    if not CSV.exists():
        build_csv()
    df = pd.read_csv(CSV, encoding="utf-8-sig", keep_default_na=False)
    df["date"] = pd.to_datetime(df["date"])
    return df


def cycles(df: pd.DataFrame, today: pd.Timestamp, recent: int = 6) -> pd.DataFrame:
    """Per kind: count, last date, interval stats over the most recent `recent` gaps, next-date window."""
    rows = []
    for kind in KIND_ORDER:
        d = df[df["kind"] == kind].sort_values("date")
        if d.empty:
            continue
        gaps = d["date"].diff().dt.days.dropna()
        gaps = gaps[gaps <= MAX_GAP].tail(recent)  # a longer gap means the event was not being run then
        last = d["date"].iloc[-1]
        r = {"kind": kind, "count": len(d), "last": last, "days_since": (today - last).days}
        if len(gaps) >= 2:
            r |= {"gap_mean": gaps.mean(), "gap_min": int(gaps.min()), "gap_max": int(gaps.max()),
                  "next_from": _sunday_on_or_after(last + pd.Timedelta(days=int(gaps.min()))),
                  "next_to": _sunday_on_or_before(last + pd.Timedelta(days=int(gaps.max()))),
                  "next_mid": last + pd.Timedelta(days=int(round(gaps.median())))}
        rows.append(r)
    return pd.DataFrame(rows)


def my_activity(df: pd.DataFrame) -> pd.DataFrame:
    """What I enhanced on each event day (account history: cube / 재설정 / starforce counts)."""
    con = db.connect()
    hist = con.execute("SELECT kind, substr(date_create, 1, 10) AS d, COUNT(*) FROM history GROUP BY kind, d").fetchall()
    con.close()
    h = pd.DataFrame(hist, columns=["hkind", "date", "n"])
    if h.empty:
        return pd.DataFrame()
    h["date"] = pd.to_datetime(h["date"])
    piv = h.pivot_table(index="date", columns="hkind", values="n", aggfunc="sum", fill_value=0)
    out = df.merge(piv, left_on="date", right_index=True, how="inner")
    return out


def selftest() -> None:
    df = load()
    assert len(df) == len(_ROWS), (len(df), len(_ROWS))
    c = cycles(df, pd.Timestamp("2026-09-27"))
    mir = c[c["kind"] == "미라클 타임"].iloc[0]
    assert mir["count"] == 10 and mir["last"] == pd.Timestamp("2026-09-27")
    sh = c[c["kind"] == "샤이닝 스타포스"].iloc[0]
    assert sh["last"] == pd.Timestamp("2026-09-06") and 20 <= sh["gap_min"] <= sh["gap_max"] <= 60, sh
    assert sh["next_from"].weekday() == 6 and sh["next_to"].weekday() == 6
    ju = c[c["kind"] == "주흔 50%"].iloc[0]
    assert ju["gap_max"] <= MAX_GAP, ju
    print(c[["kind", "count", "last", "gap_min", "gap_max", "next_from", "next_to"]].to_string(index=False))
    act = my_activity(df)
    print("event days with my enhancement records:", len(act))
    print("selftest ok")


if __name__ == "__main__":
    selftest()
