"""Daily collector: character snapshots, boss scheduler, enhancement history, backfill.

Why: the API only serves past data by date (character data from 2023-12-21,
scheduler only 14 days back), so the growth graph and boss income need a local
store that is filled every day. The dashboard (app.py) reads only the DB.

Rerun (daily via Task Scheduler, or by hand):
    C:\\Users\\jeong\\Documents\\story\\.venv\\Scripts\\python.exe -X utf8 C:\\Users\\jeong\\Documents\\story\\collector.py
Options:
    --live-only   only refresh today's live data (what the dashboard button runs)
    --no-backfill skip walking back into past days
    --history-only backfill enhancement history only (no past snapshots), use the whole
                  remaining daily budget instead of backfill_calls_per_run

Order of spending the daily quota (most time-critical first):
    1 character list  2 live (today) snapshots  3 last complete day snapshots
    4 scheduler, 14-day window (older days are lost for good)
    5 backfill, newest day first: history kinds then snapshots of that day
"""
import argparse
import sys
from datetime import date as Date, datetime, time, timedelta
from pathlib import Path

import yaml
from functools import partial

from tqdm import tqdm as _tqdm

import db
from nexon_api import ApiError, BudgetExhausted, NexonAPI, daily_budget, load_key

tqdm = partial(_tqdm, mininterval=2, ascii=True)
ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "config.yaml"
KST = db.KST
RECENT_HISTORY_DAYS = 7  # how far back the every-run history catch-up looks


def permanent_400(e: ApiError) -> bool:
    """400 that will not change on retry. OPENAPI00009 (데이터 준비 중) is temporary, so such days are retried
    instead of being marked as having no data (01_API_전수.md, 2026-09-27)."""
    return e.status == 400 and "OPENAPI00009" not in str(e)


def day_range_desc(newest: Date, oldest: Date):
    d = newest
    while d >= oldest:
        yield d
        d -= timedelta(days=1)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--live-only", action="store_true")
    ap.add_argument("--no-backfill", action="store_true")
    ap.add_argument("--history-only", action="store_true")
    args = ap.parse_args()

    cfg = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
    con = db.connect()
    used = db.calls_today(con)
    remaining = daily_budget(cfg) - used
    print(f"오늘 사용 {used}건, 이번 실행 예산 {remaining}건")
    if remaining <= 0:
        print("오늘 예산을 다 썼습니다. 내일 다시 실행하세요.")
        return
    api = NexonAPI(load_key(), budget=remaining, on_call=lambda: db.add_call(con))
    stats = {"snapshot": 0, "scheduler": 0, "history_days": 0, "history_rows": 0, "errors": 0}

    def fetch_snapshot(ocid, day_str, ep, live=False):
        if not live and db.has_snapshot(con, ocid, day_str, ep):
            return
        try:
            data = api.character(ep, ocid, None if live else day_str)
        except ApiError as e:
            stats["errors"] += 1
            _tqdm.write(f"  [오류] {ep} {day_str}: {e}")
            if not live and permanent_400(e):
                db.put_snapshot(con, ocid, day_str, ep, {"_error": 400})  # don't retry every run
            return
        db.put_snapshot(con, ocid, day_str, ep, data)
        stats["snapshot"] += 1

    try:
        # 1. targets
        chars = api.character_list()
        assert chars, "character list is empty"
        for c in chars:
            db.upsert_character(con, c)
        con.commit()
        pick = cfg.get("characters") or []
        targets = [c for c in chars if c["world_name"] == cfg["world"]
                   and (c["character_name"] in pick if pick else int(c["character_level"]) >= cfg["min_level"])]
        assert targets, f"no character matches world={cfg['world']} names={pick} level>={cfg['min_level']}"
        if pick:
            missing = set(pick) - {c["character_name"] for c in targets}
            assert not missing, f"characters not found in {cfg['world']}: {missing}"
        print(f"대상 캐릭터 {len(targets)}명 ({cfg['world']}, "
              + (", ".join(pick) if pick else f"{cfg['min_level']}+") + ")")

        now = db.now_kst()
        today = now.date()
        # previous day is published from 02:00 KST; give it a margin
        last_done = today - timedelta(days=1 if now.hour >= 3 else 2)
        # union is per account; one character per account is enough
        union_ocids = {}
        for c in targets:
            union_ocids.setdefault(c.get("account_id") or "_", c["ocid"])
        union_ocids = list(dict.fromkeys(union_ocids.values()))

        # 2. live snapshot (dated today, overwritten each run)
        t = today.isoformat()
        for c in tqdm(targets, desc="[2/5] 실시간", unit="캐릭"):
            for ep in cfg["daily_endpoints"] + cfg.get("spec_endpoints", []):
                fetch_snapshot(c["ocid"], t, ep, live=True)
            try:
                db.put_snapshot(con, c["ocid"], t, "scheduler", api.scheduler(c["ocid"]))
                stats["scheduler"] += 1
            except ApiError as e:
                stats["errors"] += 1
                _tqdm.write(f"  [오류] scheduler {t}: {e}")
        # 2b. recent enhancement history (real time; cube up to 30 min late per api_spec 17).
        # Before 2026-09-26 this ran only inside the backfill, so the refresh button never
        # fetched it and the cube tab stopped at the last full run.
        # Days after the last finished day (at most 7 back) up to today; a day is marked
        # finished only once it ended more than an hour ago, so today is refetched every run.
        for kind in cfg["history_kinds"]:
            last = con.execute("SELECT MAX(date) FROM history_done WHERE kind=?", (kind,)).fetchone()[0]
            start = today - timedelta(days=RECENT_HISTORY_DAYS)
            if last:
                start = max(start, Date.fromisoformat(last) + timedelta(days=1))
            for x in reversed(list(day_range_desc(today, start))):
                try:
                    rows = api.history_day(kind, x.isoformat())
                except ApiError as e:
                    stats["errors"] += 1
                    _tqdm.write(f"  [오류] history {kind} {x}: {e}")
                    continue
                closed = now - timedelta(hours=1) >= datetime.combine(x + timedelta(days=1), time(), KST)
                db.put_history(con, kind, x.isoformat(), rows, done=closed)
                stats["history_days"] += 1
                stats["history_rows"] += len(rows)
        if args.live_only:
            return

        # 3. last complete day
        d = last_done.isoformat()
        for c in tqdm(targets, desc=f"[3/5] {d}", unit="캐릭"):
            for ep in cfg["daily_endpoints"]:
                fetch_snapshot(c["ocid"], d, ep)
        for ocid in union_ocids:
            fetch_snapshot(ocid, d, "union")

        # 4. scheduler window (API keeps 14 days)
        window = list(day_range_desc(today - timedelta(days=1), today - timedelta(days=13)))
        todo = [(c, x.isoformat()) for x in window for c in targets
                if not db.has_snapshot(con, c["ocid"], x.isoformat(), "scheduler")]
        for c, x in tqdm(todo, desc="[4/5] 스케줄러 14일", unit="건"):
            try:
                db.put_snapshot(con, c["ocid"], x, "scheduler", api.scheduler(c["ocid"], x))
                stats["scheduler"] += 1
            except ApiError as e:
                stats["errors"] += 1
                _tqdm.write(f"  [오류] scheduler {x} {c['character_name']}: {e}")
                if permanent_400(e):  # e.g. not logged in that day; keep a marker
                    db.put_snapshot(con, c["ocid"], x, "scheduler", {"_error": 400})

        if args.no_backfill:
            return

        # 5. backfill, newest first, interleaving history and snapshots per day
        per_run = remaining if args.history_only else cfg.get("backfill_calls_per_run", 0)
        cap = api.calls + per_run
        if per_run <= 0:
            return
        # NEXON serves the last 2 years: today - 729 answers, today - 730 is HTTP 400 (checked 2026-09-28).
        # Always walk the whole window (2026-09-28 user: 친구도 2년 데이터 받게); config history_start is no longer
        # used, so a friend's old value (e.g. 2024-12-19, kept by updater) cannot shorten it.
        keep = db.now_kst().date() - timedelta(days=cfg.get("history_keep_days", 730) - 1)
        hist_start = keep.isoformat()
        oldest = (Date.fromisoformat(hist_start) if args.history_only
                  else min(Date.fromisoformat(hist_start), Date.fromisoformat(cfg["backfill_start"])))
        days = list(day_range_desc(last_done, oldest))
        bar = tqdm(days, desc="[5/5] 과거 채우기", unit="일")
        for x in bar:
            if api.calls >= cap:
                print(f"\n과거 채우기 한도 {cfg['backfill_calls_per_run']}건 도달. 다음 실행에서 이어서 채웁니다.")
                break
            xs = x.isoformat()
            if xs >= hist_start:
                for kind in cfg["history_kinds"]:
                    if kind == "potential" and xs < "2024-01-25":
                        continue
                    if db.history_done(con, kind, xs):
                        continue
                    try:
                        rows = api.history_day(kind, xs)
                    except ApiError as e:
                        stats["errors"] += 1
                        _tqdm.write(f"  [오류] history {kind} {xs}: {e}")
                        continue
                    db.put_history(con, kind, xs, rows)
                    stats["history_days"] += 1
                    stats["history_rows"] += len(rows)
            if xs >= cfg["backfill_start"] and not args.history_only:
                for c in targets:
                    for ep in cfg["backfill_endpoints"]:
                        fetch_snapshot(c["ocid"], xs, ep)
            bar.set_postfix(호출=api.calls)
    except BudgetExhausted:
        print("\n예산 소진으로 여기서 멈춥니다. 남은 과거 기록은 다음 실행에서 이어서 채웁니다.")
    finally:
        print(f"\n이번 실행: 호출 {api.calls}건, 스냅샷 {stats['snapshot']}건, 스케줄러 {stats['scheduler']}건, "
              f"강화기록 {stats['history_days']}일치 {stats['history_rows']}행, 오류 {stats['errors']}건")
        con.close()
    if api.calls == 0:
        sys.exit("API 호출이 0건입니다. 설정을 확인하세요.")


if __name__ == "__main__":
    main()
