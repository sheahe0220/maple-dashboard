"""One-click launcher for the dashboard (used by the desktop shortcut).

Why: run_dashboard.bat leaves a console window open and must be found in the folder.
This starts Streamlit hidden if it is not already running, waits for the port,
then opens the browser. Double-clicking again just opens the browser.

Rerun:
    C:\\Users\\jeong\\Documents\\story\\.venv\\Scripts\\pythonw.exe C:\\Users\\jeong\\Documents\\story\\launch_dashboard.pyw
Stop the dashboard: stop_dashboard.bat
"""
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
# pythonw, not python: the venv python.exe is a stub that starts the base interpreter as a child, and that child
# got its own console, shown by Windows Terminal as an empty black window (2026-09-27 user). pythonw has none.
PY = ROOT / ".venv" / "Scripts" / "pythonw.exe"
LOG = ROOT / "data" / "streamlit.log"
PORT = 8501
URL = f"http://localhost:{PORT}"
WAIT_S = 60


def port_open() -> bool:
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", PORT)) == 0


# self-update first (friend's copy only: runs when update.yaml exists; failures keep the current version).
# A running dashboard picks up replaced files by itself (runOnSave), so this also runs when it is already up.
if (ROOT / "update.yaml").exists() and (ROOT / "updater.py").exists():
    try:
        subprocess.run([str(PY), "-X", "utf8", str(ROOT / "updater.py")], cwd=ROOT, timeout=180,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    except Exception:
        pass
    # folder moved or copied by the friend -> point the 04:00 task and the desktop icon here (relink.py, 2026-09-28)
    try:
        subprocess.run([str(PY), "-X", "utf8", str(ROOT / "relink.py")], cwd=ROOT, timeout=120,
                       creationflags=subprocess.CREATE_NO_WINDOW)
    except Exception:
        pass

if not port_open():
    LOG.parent.mkdir(exist_ok=True)
    log = open(LOG, "a", encoding="utf-8")
    subprocess.Popen(
        [str(PY), "-m", "streamlit", "run", str(ROOT / "app.py"),
         "--server.headless", "true", "--server.port", str(PORT)],
        cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS)
    t0 = time.time()
    while not port_open():
        if time.time() - t0 > WAIT_S:
            sys.exit(f"dashboard did not start within {WAIT_S}s, see {LOG}")
        time.sleep(0.5)
webbrowser.open(URL)
