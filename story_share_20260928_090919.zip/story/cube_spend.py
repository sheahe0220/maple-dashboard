"""Cube / potential-reset spending and grade-up luck from the account history.

Why: the history API gives every reset but no cost. The cube tab needs "how much did I
spend" in 억 메소, 메포 and 원, grouped by item / character / type / date (2026-09-26 user
request, modelled on chuchu.gg's cube history which shows 누적 소모 재화 and a luck score).

Cost per record
    메소 재설정 (potential kind: 잠재능력 재설정, 에디셔널 잠재능력 재설정)
        calc_cube.reset_cost(kind, item_level, grade BEFORE the reset). The history field
        potential_option_grade is the grade AFTER (checked on 5 successes 2026-09-26), so the
        before grade is the best grade among before_*_option lines.
    cube items (카르마 블랙 큐브, 메멘토 ... 큐브, 펄스 인핸서 ...)
        user-entered price per cube name in data/cube_prices.yaml, in 메소 or 메포.
        Default 0: most of these come from events / rewards.
Luck = actual grade-ups / expected grade-ups, expected = sum of the official one-try
probability (ref/cube_gradeup_20260918.csv) over tries made below 레전드리. The guarantee
(천장) is ignored in the expectation [추정: slightly underestimates expected ups].

Self-test:
    C:\\Users\\jeong\\Documents\\story\\.venv\\Scripts\\python.exe -X utf8 C:\\Users\\jeong\\Documents\\story\\cube_spend.py
"""
from pathlib import Path

import pandas as pd
import yaml

import calc_cube

PRICES_PATH = Path(__file__).resolve().parent / "data" / "cube_prices.yaml"
EOK = 100_000_000
GRADES = ["노멀", "레어", "에픽", "유니크", "레전드리"]
MESO_RESETS = {"잠재능력 재설정": "potential", "에디셔널 잠재능력 재설정": "additional"}

# cube name keyword -> method row in cube_gradeup csv (first match wins, order matters)
METHOD_BY_KEYWORD = [
    ("에디셔널 잠재능력 재설정", "에디셔널 잠재능력 재설정"),
    ("잠재능력 재설정", "잠재능력 재설정/블랙 큐브"),
    ("블랙 큐브", "잠재능력 재설정/블랙 큐브"),
    ("브론즈 에디셔널", "수상한 에디셔널 큐브 / 브론즈 에디셔널 큐브"),
    ("수상한 에디셔널", "수상한 에디셔널 큐브 / 브론즈 에디셔널 큐브"),
    ("에디셔널 큐브", "에디셔널 큐브/화이트 에디셔널 큐브"),
    ("골드 큐브", "명장의 큐브 / 골드 큐브"),
    ("명장의 큐브", "명장의 큐브 / 골드 큐브"),
    ("실버 큐브", "장인의 큐브 / 실버 큐브"),
    ("장인의 큐브", "장인의 큐브 / 실버 큐브"),
    ("수상한 큐브", "수상한 큐브"),
]


def is_additional(kind_name: str) -> bool:
    return "에디셔널" in kind_name


def before_grade(r: dict, additional: bool) -> str:
    lines = r.get("before_additional_potential_option" if additional else "before_potential_option")
    gs = [x.get("grade") for x in lines] if isinstance(lines, list) else []
    gs = [g for g in gs if g in GRADES]
    if gs:
        return max(gs, key=GRADES.index)
    return r.get("additional_potential_option_grade" if additional else "potential_option_grade") or ""


def method_of(kind_name: str) -> str | None:
    for kw, m in METHOD_BY_KEYWORD:
        if kw in kind_name:
            return m
    return None


def is_miracle(flag) -> bool:
    """API miracle_time_flag: "이벤트 적용중" on 미라클 타임 records (seen 2026-09-27, 196 rows),
    "이벤트 적용되지 않음" otherwise."""
    f = str(flag or "")
    return "적용" in f and "않" not in f


def load_prices() -> dict:
    if not PRICES_PATH.exists():
        return {}
    return yaml.safe_load(PRICES_PATH.read_text(encoding="utf-8")) or {}


def save_prices(prices: dict) -> None:
    PRICES_PATH.parent.mkdir(exist_ok=True)
    PRICES_PATH.write_text(yaml.safe_dump(prices, allow_unicode=True, sort_keys=True), encoding="utf-8")


def enrich(cu: pd.DataFrame, prices: dict, mp_per_eok: float, miracle_mult: float = 2.0) -> pd.DataFrame:
    """Adds 종류, 이전 등급, 메소, 메포 (direct 메포 spend), 기대 등업 columns.

    cu needs the raw history columns plus 'cube_type' (cube name or 재설정 type).
    miracle_mult: grade-up multiplier on records flagged as 미라클 타임 [추정 2배, see 10_조사].
    """
    gt = calc_cube.gradeup_table()
    prob = {(m, s): float(p) for m, s, p in zip(gt["method"], gt["step"], gt["prob"])}
    out = cu.copy()
    recs = out.to_dict("records")
    meso, mp, grade, exp_up = [], [], [], []
    for r in recs:
        name = str(r["cube_type"])
        add = is_additional(name)
        g = before_grade(r, add)
        grade.append(g)
        if name in MESO_RESETS:
            lev = int(r.get("item_level") or 0)
            meso.append(float(calc_cube.reset_cost(MESO_RESETS[name], lev, g)) if g in GRADES[1:] else 0.0)
            mp.append(0.0)
        else:
            e = prices.get(name) or {}
            v = float(e.get("price") or 0)
            if e.get("unit") == "메포":
                meso.append(0.0)
                mp.append(v)
            else:
                meso.append(v)
                mp.append(0.0)
        m = method_of(name)
        p = 0.0
        if m and g in GRADES[1:4]:
            p = prob.get((m, f"{g} → {GRADES[GRADES.index(g) + 1]}"), 0.0)
            if is_miracle(r.get("miracle_time_flag")):
                p = min(1.0, p * miracle_mult)
        exp_up.append(p)
    out["이전 등급"] = grade
    out["메소"] = meso
    out["메포 직접"] = mp
    # everything in meso-equivalent and 메포-equivalent so groups can be summed in one unit
    out["메소 환산"] = out["메소"] + (out["메포 직접"] / mp_per_eok * EOK if mp_per_eok > 0 else 0.0)
    out["메포 환산"] = out["메포 직접"] + out["메소"] / EOK * mp_per_eok
    out["기대 등업"] = exp_up
    out["등업"] = (out["item_upgrade_result"] == "성공").astype(int)
    return out


def summarize(df: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    g = df.groupby(by, dropna=False).agg(횟수=("등업", "size"), 등업=("등업", "sum"),
                                         기대등업=("기대 등업", "sum"), 메소=("메소 환산", "sum"),
                                         메포=("메포 환산", "sum")).reset_index()
    g["억"] = g["메소"] / EOK
    g["운"] = (g["등업"] / g["기대등업"]).where(g["기대등업"] > 0)
    return g.sort_values("메소", ascending=False)


def selftest() -> None:
    rows = pd.DataFrame([
        {"cube_type": "잠재능력 재설정", "item_level": 200, "item_upgrade_result": "실패",
         "before_potential_option": [{"grade": "레전드리"}, {"grade": "유니크"}], "miracle_time_flag": "이벤트 적용되지 않음"},
        {"cube_type": "잠재능력 재설정", "item_level": 200, "item_upgrade_result": "성공",
         "before_potential_option": [{"grade": "유니크"}], "miracle_time_flag": "이벤트 적용되지 않음"},
        {"cube_type": "에디셔널 잠재능력 재설정", "item_level": 250, "item_upgrade_result": "실패",
         "before_additional_potential_option": [{"grade": "유니크"}], "miracle_time_flag": "이벤트 적용되지 않음"},
        {"cube_type": "카르마 블랙 큐브", "item_level": 200, "item_upgrade_result": "실패",
         "before_potential_option": [{"grade": "유니크"}], "miracle_time_flag": "이벤트 적용되지 않음"},
    ])
    assert is_miracle("이벤트 적용중") and not is_miracle("이벤트 적용되지 않음") and not is_miracle(None)
    m = enrich(rows.iloc[[1]].assign(miracle_time_flag="이벤트 적용중"), {}, mp_per_eok=1250)
    assert abs(m["기대 등업"].iloc[0] - 0.028) < 1e-9, m["기대 등업"].iloc[0]  # 1.4% x2
    e = enrich(rows, {"카르마 블랙 큐브": {"price": 1000, "unit": "메포"}}, mp_per_eok=1250)
    assert e["메소"].tolist() == [calc_cube.reset_cost("potential", 200, "레전드리"),
                                 calc_cube.reset_cost("potential", 200, "유니크"),
                                 calc_cube.reset_cost("additional", 250, "유니크"), 0.0], e["메소"].tolist()
    assert e["이전 등급"].tolist() == ["레전드리", "유니크", "유니크", "유니크"]
    assert e.loc[0, "기대 등업"] == 0 and e.loc[1, "기대 등업"] > 0 and e.loc[3, "기대 등업"] == e.loc[1, "기대 등업"]
    assert abs(e.loc[3, "메소 환산"] - 1000 / 1250 * EOK) < 1
    s = summarize(e, ["cube_type"])
    assert len(s) == 3 and s["횟수"].sum() == 4
    print(e[["cube_type", "이전 등급", "메소", "메포 환산", "기대 등업"]].to_string())
    print("selftest ok")


if __name__ == "__main__":
    selftest()
