"""Daily collection without any window, for Windows Task Scheduler (2026-09-27).

Why: the task ran run_collector_daily.bat through cmd.exe, which opens a console window at 04:00; the user asked
that nothing stays visible. This runs the same `collector.py --history-only` with pythonw (no console) and appends
the output to data/collector_daily.log. Manual run with a window: run_collector_daily.bat.

Rerun:
    C:\\Users\\jeong\\Documents\\story\\.venv\\Scripts\\pythonw.exe C:\\Users\\jeong\\Documents\\story\\collect_hidden.pyw
"""
import subprocess
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PYW = ROOT / ".venv" / "Scripts" / "pythonw.exe"
LOG = ROOT / "data" / "collector_daily.log"

LOG.parent.mkdir(exist_ok=True)
with open(LOG, "a", encoding="utf-8") as log:
    log.write(f"===== {datetime.now():%Y-%m-%d %H:%M:%S} (hidden)\n")
    log.flush()
    if (ROOT / "update.yaml").exists() and (ROOT / "updater.py").exists():  # friend's copy: update before collecting
        u = subprocess.run([str(PYW), "-X", "utf8", str(ROOT / "updater.py")], cwd=ROOT, stdout=log,
                           stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW, timeout=600)
        log.flush()
    # one-time job table check against the game (owner's PC only: the script lives in 10_조사, not in the share build)
    vj = ROOT / "10_조사" / "20260927_직업정보" / "검증" / "verify_jobs_api.py"
    if vj.exists() and not (ROOT / "ref" / "jobs" / "verify_20260927.csv").exists():
        subprocess.run([str(PYW), "-X", "utf8", str(vj)], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                       creationflags=subprocess.CREATE_NO_WINDOW, timeout=600)
        log.flush()
    r = subprocess.run([str(PYW), "-X", "utf8", str(ROOT / "collector.py"), "--history-only"], cwd=ROOT,
                       stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
    log.write(f"===== exit {r.returncode}\n")
