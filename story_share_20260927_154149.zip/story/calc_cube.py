"""Cube option probability: chance that one reroll meets a target, and cubes needed.

Why: official per-line option probabilities (maplestory.nexon.com probability guide,
collected 2026-09-18 into ref/cube_options_20260918.csv) give each line's
distribution; the chance of a 3-line target follows by enumerating the lines.

Lines are drawn in order. Options capped per item (at most 1: 쓸만한 skills, 피격 후
무적시간; at most 2: 피격 시 데미지 무시, 피격 시 무적) are removed from later lines once the
cap is reached and the rest renormalised, the same rule mesulive applies
(src/app/(potential-calc)/calc/potential/_lib/logics.ts, local copy 10_조사/ref_mesulive).

Grade-up probability and guarantee count: official pages, ref/cube_gradeup_20260918.csv.
Meso reset cost: ref/reset_cost_20260918.yaml (see 10_조사/cube_grade/build_cube_refs.py).
"""
import math
import re
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

REF = Path(__file__).resolve().parent / "ref"
TABLE = REF / "cube_options_20260918.csv"
GRADEUP = REF / "cube_gradeup_20260918.csv"
COST = REF / "reset_cost_20260927.yaml"  # official 737 / 746 (20260918 = 메산기 proposal values, wrong)
MAX_ONE = [r"쓸만한", r"피격 후 무적시간"]
MAX_TWO = [r"피격 시 .*데미지의 .*무시", r"피격 시 .*초간 무적"]

CUBES = {"5062010": "윗잠 (메소 재설정 · 블랙 · 프라임)",
         "5062500": "에디 (메소 재설정 · 에디셔널 큐브 · 화이트 · 프라임)"}

# family name -> regex on option text; value is the first number captured
FAMILIES = {
    "STR%": r"^STR \+(\d+)%$", "DEX%": r"^DEX \+(\d+)%$", "INT%": r"^INT \+(\d+)%$",
    "LUK%": r"^LUK \+(\d+)%$", "최대 HP%": r"^최대 HP \+(\d+)%$", "올스탯%": r"^올스탯 \+(\d+)%$",
    "공격력%": r"^공격력 \+(\d+)%$", "마력%": r"^마력 \+(\d+)%$",
    "데미지%": r"^데미지 \+(\d+)%$", "보스 데미지%": r"^보스 몬스터 데미지 \+(\d+)%$",
    "방어율 무시%": r"^몬스터 방어율 무시 \+(\d+)%$", "크리티컬 데미지%": r"^크리티컬 데미지 \+(\d+)%$",
    "쿨타임 감소(초)": r"^스킬 재사용 대기시간 -(\d+)초$",
    "메소 획득량%": r"^메소 획득량 \+(\d+)%$", "아이템 드롭률%": r"^아이템 드롭률 \+(\d+)%$",
}
# allstat counts toward any single main stat (usual "주스탯%" convention)
# 올스탯% raises STR/DEX/INT/LUK but not 최대 HP% (나무 스탯 각주 16; kb_enh_notes 2026-09-27), so HP is not listed
MAIN_STATS = ["STR%", "DEX%", "INT%", "LUK%"]


@lru_cache(maxsize=1)
def load() -> pd.DataFrame:
    d = pd.read_csv(TABLE, encoding="utf-8-sig", dtype={"cube_id": str})
    d["p"] = d["prob"].str.rstrip("%").astype(float) / 100
    assert len(d) > 10000, f"cube table too small: {len(d)}"
    return d


def slot_tables(cube_id: str, grade: str, part: str, req_lev: int) -> list[pd.DataFrame]:
    d = load()
    sel = d[(d.cube_id == cube_id) & (d.grade == grade) & (d.part == part) & (d.req_lev == req_lev)]
    tables = [sel[sel.slot == s][["option", "p"]].reset_index(drop=True) for s in (1, 2, 3)]
    assert all(len(t) for t in tables), f"no rows for {cube_id} {grade} {part} {req_lev}"
    return tables


# line-count families: a line counts if it is any of the member options (weapon "유효 줄")
COMBOS = {
    "유효 줄 (공격력% · 보공 · 방무)": ["공격력%", "보스 데미지%", "방어율 무시%"],
    "유효 줄 (마력% · 보공 · 방무)": ["마력%", "보스 데미지%", "방어율 무시%"],
}


def family_value(option: str, family: str) -> float:
    if family in COMBOS:
        return float(any(family_value(option, f) for f in COMBOS[family]))
    if family in MAIN_STATS:
        m = re.match(FAMILIES[family], option) or re.match(FAMILIES["올스탯%"], option)
    else:
        m = re.match(FAMILIES[family], option)
    return float(m.group(1)) if m else 0.0


def _capped(option: str) -> tuple[str, int] | None:
    for rx in MAX_ONE:
        if re.search(rx, option):
            return rx, 1
    for rx in MAX_TWO:
        if re.search(rx, option):
            return rx, 2
    return None


def joint_outcomes(tables):
    """Probability of each (line1, line2, line3) index triple, with per-item caps.
    Returns (idx array n x 3, prob array n)."""
    opts = [t["option"].tolist() for t in tables]
    probs = [t["p"].to_numpy() for t in tables]
    caps = [[_capped(o) for o in line] for line in opts]

    def allowed(line, used):
        mask = np.array([c is None or used.get(c[0], 0) < c[1] for c in caps[line]])
        q = np.where(mask, probs[line], 0.0)
        return q / q.sum()

    idx, pr = [], []
    q1 = probs[0] / probs[0].sum()
    for i in np.nonzero(q1)[0]:
        used1 = {}
        if caps[0][i]:
            used1[caps[0][i][0]] = 1
        q2 = allowed(1, used1)
        for j in np.nonzero(q2)[0]:
            used2 = dict(used1)
            if caps[1][j]:
                used2[caps[1][j][0]] = used2.get(caps[1][j][0], 0) + 1
            q3 = allowed(2, used2)
            ks = np.nonzero(q3)[0]
            idx.append(np.column_stack([np.full(len(ks), i), np.full(len(ks), j), ks]))
            pr.append(q1[i] * q2[j] * q3[ks])
    return np.vstack(idx), np.concatenate(pr)


def success_prob(tables, conditions: list[dict]) -> float:
    """conditions: OR-list of {"family", "mode": "sum"|"lines", "min"}.
    A reroll succeeds if any condition holds on the 3 lines."""
    idx, pr = joint_outcomes(tables)
    ok = np.zeros(len(pr), dtype=bool)
    for c in conditions:
        v = [t["option"].map(lambda o: family_value(o, c["family"])).to_numpy() for t in tables]
        if c["mode"] == "lines":
            v = [(x > 0).astype(float) for x in v]
        total = v[0][idx[:, 0]] + v[1][idx[:, 1]] + v[2][idx[:, 2]]
        ok |= total >= c["min"]
    return float(pr[ok].sum())


def _line_values(tables, family: str, mode: str) -> list[np.ndarray]:
    v = [t["option"].map(lambda o: family_value(o, family)).to_numpy() for t in tables]
    return [(x > 0).astype(float) for x in v] if mode == "lines" else v


def success_prob_sets(tables, sets: list[list[dict]]) -> float:
    """sets: OR-list of AND-lists of {"family", "mode": "sum"|"lines", "min"} (mesulive's option-set
    model: e.g. [[INT% sum>=21]] or [[INT% lines>=2, 보공 lines>=1]]). Empty sets are ignored."""
    idx, pr = joint_outcomes(tables)
    ok = np.zeros(len(pr), dtype=bool)
    for conds in sets:
        if not conds:
            continue
        hit = np.ones(len(pr), dtype=bool)
        for c in conds:
            v = _line_values(tables, c["family"], c["mode"])
            hit &= (v[0][idx[:, 0]] + v[1][idx[:, 1]] + v[2][idx[:, 2]]) >= c["min"] - 1e-9
        ok |= hit
    return float(pr[ok].sum())


def threshold_table(tables, family: str, mode: str) -> pd.DataFrame:
    """P(total >= v) for every reachable total v of one family: the cost curve of raising the target."""
    idx, pr = joint_outcomes(tables)
    v = _line_values(tables, family, mode)
    total = np.round(v[0][idx[:, 0]] + v[1][idx[:, 1]] + v[2][idx[:, 2]], 6)
    rows = []
    for x in sorted(set(total) - {0.0}):
        rows.append({"목표": x, "확률": float(pr[total >= x].sum())})
    return pd.DataFrame(rows, columns=["목표", "확률"])


def presets(part: str, main: str, atk: str, tables) -> dict[str, list[list[dict]]]:
    """Common targets per part (same kinds mesulive / maplescouter / chuchu offer), keeping only those
    reachable in this table. main = 주스탯 family (e.g. 'INT%'), atk = '공격력%' | '마력%'."""
    L = lambda f, n: {"family": f, "mode": "lines", "min": n}
    S = lambda f, n: {"family": f, "mode": "sum", "min": n}
    weapon = part.startswith(("무기", "보조무기", "포스실드", "엠블렘"))
    eff = "유효 줄 (공격력% · 보공 · 방무)" if atk == "공격력%" else "유효 줄 (마력% · 보공 · 방무)"
    if weapon:
        out = {f"{atk} 3줄": [[L(atk, 3)]], f"{atk} 2줄 이상": [[L(atk, 2)]],
               f"{atk} 2줄 + 보공": [[L(atk, 2), L("보스 데미지%", 1)]],
               f"{atk} 1줄 + 보공 2줄": [[L(atk, 1), L("보스 데미지%", 2)]],
               "유효 3줄 (공 · 보공 · 방무)": [[L(eff, 3)]], "유효 2줄 이상": [[L(eff, 2)]]}
    else:
        out = {f"{main} 3줄": [[L(main, 3)]], f"{main} 2줄 이상": [[L(main, 2)]]}
        if part == "모자":
            out |= {"쿨감 2초 이상": [[S("쿨타임 감소(초)", 2)]],
                    f"쿨감 1초 + {main} 2줄": [[S("쿨타임 감소(초)", 1), L(main, 2)]],
                    f"쿨감 2초 + {main} 1줄": [[S("쿨타임 감소(초)", 2), L(main, 1)]]}
        if part == "장갑":
            out |= {"크뎀 2줄": [[L("크리티컬 데미지%", 2)]],
                    f"크뎀 1줄 + {main} 2줄": [[L("크리티컬 데미지%", 1), L(main, 2)]]}
        out |= {"드롭률 2줄": [[L("아이템 드롭률%", 2)]], "메획 2줄": [[L("메소 획득량%", 2)]],
                "메획 1줄 + 드롭 1줄": [[L("메소 획득량%", 1), L("아이템 드롭률%", 1)]]}
    fams = lambda sets: {c["family"] for conds in sets for c in conds}
    return {k: v for k, v in out.items()
            if all(achievable_values(tables, f) for f in fams(v)) and success_prob_sets(tables, v) > 0}


# ---------- grade up ----------
def gradeup_table() -> pd.DataFrame:
    return pd.read_csv(GRADEUP, encoding="utf-8-sig")


def gradeup_stats(p: float, ceil: float | None, done: int = 0) -> dict:
    """Attempts until one grade step succeeds; the ceil-th attempt is guaranteed.
    done: failures already stacked on the guarantee counter (it carries over between sessions, 2026-09-27),
    so only ceil - done attempts remain at most."""
    if ceil and not math.isnan(ceil):
        n = max(1, int(ceil) - int(done))
        mean = (1 - (1 - p) ** n) / p
        q = lambda x: min(n, math.ceil(math.log(1 - x) / math.log(1 - p)))
    else:
        mean = 1 / p
        q = lambda x: math.ceil(math.log(1 - x) / math.log(1 - p))
    return {"mean": mean, "q50": q(0.5), "q90": q(0.9), "max": n if ceil and not math.isnan(ceil) else None}


def reset_cost(kind: str, item_level: int, grade: str) -> int:
    """kind: 'potential' | 'additional'. Level bands 1 / 160 / 200 / 250."""
    table = yaml.safe_load(COST.read_text(encoding="utf-8"))[kind]
    band = max(b for b in table if b <= item_level)
    return int(table[band][grade])


def cubes_needed(p: float, q: float) -> float:
    """Rerolls needed to succeed at least once with probability q."""
    if p <= 0:
        return math.inf
    if p >= 1:
        return 1
    return math.ceil(math.log(1 - q) / math.log(1 - p))


def achievable_values(tables, family: str) -> list[float]:
    vals = sorted({family_value(o, family) for t in tables for o in t["option"]} - {0.0})
    return vals
