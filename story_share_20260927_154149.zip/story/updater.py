"""Self-update for the friend's copy: fetch the newest share build and swap the code in place.

Why: 2026-09-27 the user keeps improving the dashboard and the friend cannot do anything by hand ("대시보드를 킨 순간
알아서 업데이트"). launch_dashboard.pyw (every start) and collect_hidden.pyw (daily 04:00) call this first.

Source: update.yaml `source:` is a folder or an http(s) URL that holds `latest.json`
    {"version": "20260927_1530", "zip": "story_share_20260927_1530.zip", "sha256": "..."}
("zip" relative to the source, or a full URL). make_share.py writes both.

What is replaced: code and reference files from the zip (UPDATE_GLOBS / UPDATE_DIRS).
Never touched: .env (API key), data/ (records), config.yaml values the owner set; keys that are new in the build are
appended to config.yaml. Replaced files are kept in _update_backup/<old version>/ so a bad build can be undone
(python updater.py --rollback). Any failure leaves the current version running and is written to data/update.log.

Run:
    .venv\\Scripts\\python.exe -X utf8 updater.py            check and update
    .venv\\Scripts\\python.exe -X utf8 updater.py --rollback restore the files replaced by the last update
Self-test (no network, uses temp folders):
    .venv\\Scripts\\python.exe -X utf8 updater.py --selftest
"""
import argparse
import hashlib
import io
import json
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent
VERSION_FILE = ROOT / "VERSION"
UPDATE_CFG = ROOT / "update.yaml"
LOG = ROOT / "data" / "update.log"
BACKUP = ROOT / "_update_backup"
KEEP = {".env", "config.yaml", "update.yaml"}           # owner / friend specific, never overwritten from the zip
UPDATE_GLOBS = ["*.py", "*.pyw", "*.bat", "requirements.txt", "crystal_prices.yaml", "README.txt", "VERSION"]
UPDATE_DIRS = ["ref", ".streamlit"]
TIMEOUT_S = 20


def log(msg: str) -> None:
    LOG.parent.mkdir(exist_ok=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {msg}\n")


def local_version(root: Path = ROOT) -> str:
    p = root / "VERSION"
    return p.read_text(encoding="utf-8").strip() if p.exists() else ""


def _read(source: str, name: str) -> bytes:
    if source.startswith(("http://", "https://")):
        url = name if name.startswith(("http://", "https://")) else source.rstrip("/") + "/" + name
        with urllib.request.urlopen(url, timeout=TIMEOUT_S) as r:
            return r.read()
    return (Path(source) / name).read_bytes()


def _members(z: zipfile.ZipFile) -> dict:
    """zip path 'story/x/y' -> relative 'x/y' for the files an update may replace."""
    out = {}
    for n in z.namelist():
        if n.endswith("/") or not n.startswith("story/"):
            continue
        rel = n[len("story/"):]
        top = rel.split("/")[0]
        if rel in KEEP or top == "data":
            continue
        if "/" in rel:
            if top in UPDATE_DIRS:
                out[n] = rel
        elif any(Path(rel).match(g) for g in UPDATE_GLOBS):
            out[n] = rel
    return out


def merge_config(old_text: str, new_text: str) -> str:
    """Keep every value the friend has; append top-level keys that only the new build has."""
    old, new = yaml.safe_load(old_text) or {}, yaml.safe_load(new_text) or {}
    extra = {k: v for k, v in new.items() if k not in old}
    if not extra:
        return old_text
    add = yaml.safe_dump(extra, allow_unicode=True, sort_keys=False, default_flow_style=False)
    return old_text.rstrip("\n") + f"\n# added by update {datetime.now():%Y-%m-%d}\n" + add


def apply_zip(data: bytes, root: Path = ROOT) -> dict:
    old_ver = local_version(root) or "unknown"
    bdir = root / "_update_backup" / old_ver
    changed, req_changed = [], False
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert z.testzip() is None, "broken zip"
        members = _members(z)
        assert "app.py" in members.values(), "zip has no app.py"
        for n, rel in members.items():
            body = z.read(n)
            dst = root / rel
            if dst.exists() and dst.read_bytes() == body:
                continue
            if dst.exists():
                (bdir / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, bdir / rel)
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(body)
            changed.append(rel)
            req_changed |= rel == "requirements.txt"
        if "story/config.yaml" in z.namelist() and (root / "config.yaml").exists():
            cur = (root / "config.yaml").read_text(encoding="utf-8")
            merged = merge_config(cur, z.read("story/config.yaml").decode("utf-8"))
            if merged != cur:
                (bdir).mkdir(parents=True, exist_ok=True)
                (bdir / "config.yaml").write_text(cur, encoding="utf-8")
                (root / "config.yaml").write_text(merged, encoding="utf-8")
                changed.append("config.yaml (새 설정 항목 추가)")
    if changed:
        (bdir).mkdir(parents=True, exist_ok=True)
        (root / "_update_backup" / "LAST").write_text(old_ver, encoding="utf-8")
    return {"changed": changed, "requirements": req_changed, "backup": bdir}


def check_and_update(root: Path = ROOT, pip: bool = True) -> str:
    """Returns a one-line status. Never raises: the dashboard must start even when this fails."""
    try:
        cfg = yaml.safe_load((root / "update.yaml").read_text(encoding="utf-8")) if (root / "update.yaml").exists() else {}
        source = (cfg or {}).get("source")
        if not source:
            return "업데이트 주소 없음 (update.yaml)"
        latest = json.loads(_read(source, "latest.json"))
        cur = local_version(root)
        if latest["version"] <= cur:
            return f"최신 ({cur})"
        data = _read(source, latest["zip"])
        if latest.get("sha256") and hashlib.sha256(data).hexdigest() != latest["sha256"]:
            raise ValueError("downloaded zip checksum mismatch")
        res = apply_zip(data, root)
        if pip and res["requirements"]:
            py = root / ".venv" / "Scripts" / "python.exe"
            subprocess.run([str(py), "-m", "pip", "install", "--disable-pip-version-check", "-q", "-r",
                            str(root / "requirements.txt")], cwd=root, capture_output=True,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), timeout=600)
        msg = f"업데이트 {cur or '처음'} -> {latest['version']}, 파일 {len(res['changed'])}개"
        log(msg + ": " + ", ".join(res["changed"][:30]))
        return msg
    except Exception as e:  # keep running the current version
        log(f"업데이트 실패: {type(e).__name__}: {e}")
        return f"업데이트 실패 (지금 판 그대로 사용): {e}"


def rollback(root: Path = ROOT) -> str:
    last = root / "_update_backup" / "LAST"
    assert last.exists(), "되돌릴 업데이트가 없습니다"
    ver = last.read_text(encoding="utf-8").strip()
    bdir = root / "_update_backup" / ver
    n = 0
    for p in bdir.rglob("*"):
        if p.is_file():
            dst = root / p.relative_to(bdir)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
            n += 1
    (root / "VERSION").write_text(ver, encoding="utf-8")
    log(f"되돌림 -> {ver}, 파일 {n}개")
    return f"{ver} 로 되돌림 ({n}개)"


def selftest() -> None:
    def build(ver: str, app_body: str, cfg: str) -> bytes:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as z:
            z.writestr("story/app.py", app_body)
            z.writestr("story/VERSION", ver)
            z.writestr("story/config.yaml", cfg)
            z.writestr("story/.env", "NEXON_OPEN_API_KEY=SHOULD_NOT_COPY\n")
            z.writestr("story/data/maple.db", "SHOULD_NOT_COPY")
            z.writestr("story/ref/t.csv", "a,b\n")
            z.writestr("story/10_조사/x.md", "not an update file")
        return buf.getvalue()

    with tempfile.TemporaryDirectory() as t:
        t = Path(t)
        src, friend = t / "src", t / "friend"
        src.mkdir(); friend.mkdir(); (friend / "data").mkdir()
        (friend / "app.py").write_text("old", encoding="utf-8")
        (friend / "VERSION").write_text("20260927_0001", encoding="utf-8")
        (friend / ".env").write_text("NEXON_OPEN_API_KEY=friend_key\n", encoding="utf-8")
        (friend / "data" / "maple.db").write_text("friend records", encoding="utf-8")
        (friend / "config.yaml").write_text("world: 스카니아\nmin_level: 230\n", encoding="utf-8")
        (friend / "update.yaml").write_text(f"source: '{src}'\n", encoding="utf-8")

        new = build("20260927_0002", "new app", "world: 에오스\nmin_level: 260\nnew_key: 5\n")
        (src / "z.zip").write_bytes(new)
        (src / "latest.json").write_text(json.dumps({"version": "20260927_0002", "zip": "z.zip",
                                                     "sha256": hashlib.sha256(new).hexdigest()}), encoding="utf-8")
        s = check_and_update(friend, pip=False)
        print(" ", s)
        assert (friend / "app.py").read_text(encoding="utf-8") == "new app"
        assert local_version(friend) == "20260927_0002"
        assert "friend_key" in (friend / ".env").read_text(encoding="utf-8")
        assert (friend / "data" / "maple.db").read_text(encoding="utf-8") == "friend records"
        cfg = yaml.safe_load((friend / "config.yaml").read_text(encoding="utf-8"))
        assert cfg == {"world": "스카니아", "min_level": 230, "new_key": 5}, cfg
        assert (friend / "ref" / "t.csv").exists() and not (friend / "10_조사").exists()
        assert check_and_update(friend, pip=False).startswith("최신")
        # bad checksum keeps the current version
        (src / "latest.json").write_text(json.dumps({"version": "20260927_0003", "zip": "z.zip", "sha256": "0" * 64}),
                                         encoding="utf-8")
        s = check_and_update(friend, pip=False)
        print(" ", s)
        assert s.startswith("업데이트 실패") and local_version(friend) == "20260927_0002"
        # rollback restores the replaced app.py and the version
        print(" ", rollback(friend))
        assert (friend / "app.py").read_text(encoding="utf-8") == "old" and local_version(friend) == "20260927_0001"
    print("selftest ok")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--rollback", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        LOG = Path(tempfile.gettempdir()) / "maple_update_selftest.log"
        selftest()
    elif a.rollback:
        print(rollback())
    else:
        print(check_and_update())
