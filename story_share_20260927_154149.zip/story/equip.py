"""Equipment view and 드메 (drop / meso) set optimizer from the item-equipment snapshots.

Why: 2026-09-27 user asked for (1) an item list like maplescouter / chuchu (star, potential grades, main-stat
% total, scrolls, 추옵, 가위), and (2) a 드메 optimizer that starts from the 드메 preset already worn and
says which items to add or remove, using only items with at least 2 드메 lines.

Data: snapshot endpoint 'item-equipment' has item_equipment_preset_1..3 and preset_no (the worn preset).
Items outside the three presets (inventory, storage) are not in the API, so the optimizer only sees
what is in some preset.

Self-test:
    <설치 폴더>\\.venv\\Scripts\\python.exe -X utf8 <설치 폴더>\\equip.py
"""
import itertools
import json
import re

import pandas as pd

import db

# slot groups that can swap items between each other (4 ring slots, 2 pendant slots)
SLOT_GROUP = {"반지1": "반지", "반지2": "반지", "반지3": "반지", "반지4": "반지",
              "펜던트": "펜던트", "펜던트2": "펜던트"}
GROUP_SIZE = {"반지": 4, "펜던트": 2}
DROP_RX = re.compile(r"^아이템 드롭률 \+(\d+)%$")
MESO_RX = re.compile(r"^메소 획득량 \+(\d+)%$")

# caps on 드롭률 / 메획 from equipment potential (10_조사/20260927_드메_환산_조사.md: 나무 잠재능력 8.3절 2026-09-25,
# 나무 메이플스토리/팁 2.4절 2026-09-08, fmkorea 2025-05-15 · 2026-06-15 agree; no official sentence found [판정보류])
DROP_CAP, MESO_CAP = 200, 100
CAP_SOURCE = ("장비 잠재 한도 드롭 200% · 메획 100% (나무위키 잠재능력 8.3절 2026-09-25 외 3곳 일치, 공식 문구 미확인). "
              "에디 드메 +5% 도 같은 한도로 셈 [추정].")
# community: 67/100 is the baseline (meso drops for sure from 67%), 200/100 = 풀드메
DEFAULT_DROP_TARGET, DEFAULT_MESO_TARGET = 200, 100


def main_pct(line: str | None, main: str) -> float:
    """Main-stat % of one potential line, 올스탯% counted (same convention as the fan sites' 'INT 34.4%')."""
    if not line:
        return 0.0
    m = re.match(rf"^(?:{main}|올스탯) \+(\d+)%$", line)
    return float(m.group(1)) if m else 0.0


def load(name: str, date: str | None = None) -> dict:
    """Latest (or given date) item-equipment snapshot of one character, parsed per preset."""
    con = db.connect()
    q = ("SELECT s.date, s.json FROM snapshot s JOIN characters c USING (ocid) "
         "WHERE s.endpoint='item-equipment' AND c.name=?" + (" AND s.date=?" if date else "") +
         " ORDER BY s.date DESC LIMIT 1")
    row = con.execute(q, (name, date) if date else (name,)).fetchone()
    con.close()
    assert row, f"no item-equipment snapshot for {name}"
    data = json.loads(row[1])
    return {"date": row[0], "class": data.get("character_class"), "preset_no": int(data.get("preset_no") or 1),
            "presets": {p: data.get(f"item_equipment_preset_{p}") or [] for p in (1, 2, 3)}}


def icon_map() -> dict[str, str]:
    """Item name -> icon URL from every stored item-equipment snapshot (all characters, all presets).
    The enhancement history has no icons, so tables of past cubes / starforce look them up here; items
    never seen in a collected character's presets have no icon."""
    con = db.connect()
    out = {}
    for (js,) in con.execute("SELECT json FROM snapshot WHERE endpoint='item-equipment' ORDER BY date"):
        data = json.loads(js)
        for k in ("item_equipment", "item_equipment_preset_1", "item_equipment_preset_2", "item_equipment_preset_3"):
            for it in data.get(k) or []:
                if it.get("item_icon"):
                    out[it["item_name"]] = it["item_icon"]
    con.close()
    return out


def character_images() -> dict[str, str]:
    """Character name -> latest look image URL (basic.character_image)."""
    con = db.connect()
    out = {}
    for name, js in con.execute("SELECT c.name, s.json FROM snapshot s JOIN characters c USING (ocid) "
                                "WHERE s.endpoint='basic' ORDER BY s.date"):
        img = json.loads(js).get("character_image")
        if img:
            out[name] = img
    con.close()
    return out


def crop_character(url: str, margin: int = 8) -> str | None:
    """Nexon's look image is 300x300 with the character in a ~110x100 box; crop the transparent border so the
    character shows at a readable size. Returns a PNG data URL (None on failure)."""
    import base64
    import io

    import requests
    from PIL import Image
    try:
        im = Image.open(io.BytesIO(requests.get(url, timeout=15).content)).convert("RGBA")
    except Exception:  # network or image error: the caller falls back to the plain URL
        return None
    box = im.getbbox()
    if not box:
        return None
    l, t, r, b = box
    im = im.crop((max(0, l - margin), max(0, t - margin), min(im.width, r + margin), min(im.height, b + margin)))
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def frame(items: list[dict], main: str) -> pd.DataFrame:
    rows = []
    for it in items:
        pot = [it.get(f"potential_option_{i}") for i in (1, 2, 3)]
        add = [it.get(f"additional_potential_option_{i}") for i in (1, 2, 3)]
        drop = [float(m.group(1)) for x in pot if x and (m := DROP_RX.match(x))]
        meso = [float(m.group(1)) for x in pot if x and (m := MESO_RX.match(x))]
        # 에디 +5% lines add to the totals but not to the line count (드메템 = 윗잠 2줄 단위, community usage)
        drop_add = [float(m.group(1)) for x in add if x and (m := DROP_RX.match(x))]
        meso_add = [float(m.group(1)) for x in add if x and (m := MESO_RX.match(x))]
        rows.append({
            "slot": it.get("item_equipment_slot"), "group": SLOT_GROUP.get(it.get("item_equipment_slot"),
                                                                           it.get("item_equipment_slot")),
            "name": it.get("item_name"), "icon": it.get("item_icon"),
            "star": int(it.get("starforce") or 0),
            "pot_grade": it.get("potential_option_grade"), "add_grade": it.get("additional_potential_option_grade"),
            "pot": [x for x in pot if x], "add": [x for x in add if x],
            "main_pct": sum(main_pct(x, main) for x in pot + add),
            # 공/마% lines (마력 for INT mages, else 공격력): what weapon / secondary / emblem are judged by
            "atk_pct": sum(float(m.group(1)) for x in pot + add
                           if x and (m := re.match(rf"^{'마력' if main == 'INT' else '공격력'} \+(\d+)%$", x))),
            "drop": sum(drop) + sum(drop_add), "meso": sum(meso) + sum(meso_add), "deme_lines": len(drop) + len(meso),
            "scroll": int(it.get("scroll_upgrade") or 0), "cut": it.get("cuttable_count"),
            "special_ring": int(it.get("special_ring_level") or 0),
            "level": int((it.get("item_base_option") or {}).get("base_equipment_level") or 0),
            "add_option": it.get("item_add_option") or {},
        })
    return pd.DataFrame(rows)


def optimize(boss: pd.DataFrame, pool: pd.DataFrame, drop_target: float, meso_target: float,
             drop_cap: float, meso_cap: float, min_lines: int = 2, keep_special: bool = False) -> dict:
    """Pick 드메 items to swap into the boss set.

    boss: the boss preset (one row per slot). pool: every item in any preset. Candidates are pool items
    with >= min_lines 드메 lines. Each candidate replaces the boss item with the lowest main-stat % in
    its slot group. Among all candidate subsets that fit the group sizes, pick the one that reaches both
    targets (after caps) with the least main-stat % lost, then fewest swaps. If none reaches the targets,
    pick the one closest to them. Brute force: candidates are few (usually < 12).
    keep_special: never replace special (seed) rings.
    """
    cands = (pool[pool["deme_lines"] >= min_lines]
             .drop_duplicates(["name", "group", "drop", "meso", "main_pct"])  # same item in several presets
             .reset_index(drop=True))
    base_drop = boss["drop"].sum()
    base_meso = boss["meso"].sum()
    best = None
    for k in range(len(cands) + 1):
        for combo in itertools.combinations(range(len(cands)), k):
            chosen = cands.loc[list(combo)]
            if any(n > GROUP_SIZE.get(g, 1) for g, n in chosen["group"].value_counts().items()):
                continue
            # replace the weakest boss items in each group; an item already in the boss set costs nothing
            lost, removed, pairs = 0.0, [], []
            ok = True
            for g, grp in chosen.groupby("group"):
                slots = boss[boss["group"] == g]
                if keep_special:  # seed rings (리스트레인트 등) have no potential, so main_pct 0 would put them first
                    slots = slots[slots["special_ring"] == 0]
                slots = slots.sort_values("main_pct")
                if len(slots) < len(grp):
                    ok = False
                    break
                out = slots.head(len(grp))
                lost += out["main_pct"].sum() - grp["main_pct"].sum()
                removed += out.index.tolist()
                pairs += list(zip([g] * len(grp), out["name"], grp["name"]))
            if not ok:
                continue
            kept = boss.drop(index=removed)
            d = min(drop_cap, kept["drop"].sum() + chosen["drop"].sum())
            m = min(meso_cap, kept["meso"].sum() + chosen["meso"].sum())
            short = max(0.0, drop_target - d) + max(0.0, meso_target - m)
            key = (short, lost, k)
            if best is None or key < best["key"]:
                best = {"key": key, "chosen": chosen, "removed": boss.loc[removed], "pairs": pairs, "drop": d, "meso": m,
                        "lost": lost, "short": short}
    best["base"] = (base_drop, base_meso)
    best["candidates"] = cands
    return best


# ---------- 빈 칸 계획 (2026-09-27 user: keep my 2-line 드메 items, skip the 정펜 slot, tell me what to put
# in the remaining slots — keep / boss item / buy 드드 etc. — to reach 풀드메 200/100) ----------
DEME_SLOTS = ["얼굴장식", "눈장식", "귀고리", "반지1", "반지2", "반지3", "반지4", "펜던트", "펜던트2"]
CUBE_PART = {"얼굴장식": "얼굴장식", "눈장식": "눈장식", "귀고리": "귀고리", "펜던트": "펜던트", "펜던트2": "펜던트",
             "반지1": "반지", "반지2": "반지", "반지3": "반지", "반지4": "반지"}
# (label, drop, meso, lines): legendary 윗잠 드메 line = +20% (ref/cube_options_20260918.csv)
BUY = [("드드", 40, 0, 2), ("드메", 20, 20, 2), ("메메", 0, 40, 2),
       ("드드드", 60, 0, 3), ("드드메", 40, 20, 3), ("드메메", 20, 40, 3)]


def plan_open_slots(deme: pd.DataFrame, boss: pd.DataFrame, pool: pd.DataFrame, fixed: list[str],
                    excluded_slots: list[str], drop_t: float, meso_t: float, drop_cap: float, meso_cap: float,
                    allow_3line: bool = False, top: int = 5) -> dict:
    """Enumerate what to put in every open 드메 slot.

    deme: the 드메 preset now worn; fixed: item names kept as they are; excluded_slots: slots left untouched
    (e.g. the 정펜 pendant). Open slots = 드메-capable slots minus fixed items' slots minus excluded.
    Per open slot the options are: keep the item there now, the boss preset's item for that slot, another owned
    드메 item of the same slot group not used elsewhere, or buying a 2-line (3-line if allowed) 드메 item
    (bought items counted with 0 main-stat %). Plans are ranked by (misses target, items to buy, 3-line buys,
    main-stat % given up, over-cap waste)."""
    fixed_rows = deme[deme["name"].isin(fixed)]
    fixed_slots = set(fixed_rows["slot"])
    base_rows = deme[deme["slot"].isin(set(excluded_slots)) & ~deme["slot"].isin(fixed_slots)]
    base_drop = fixed_rows["drop"].sum() + base_rows["drop"].sum()
    base_meso = fixed_rows["meso"].sum() + base_rows["meso"].sum()
    open_slots = [x for x in DEME_SLOTS if x not in fixed_slots and x not in excluded_slots
                  and (x in set(deme["slot"]) or x in set(boss["slot"]))]
    used = set(fixed) | set(base_rows["name"])
    options = {}
    for sl in open_slots:
        opts, seen = [], set()
        grp = SLOT_GROUP.get(sl, sl)
        for src, df in (("유지", deme), ("보스템", boss)):
            for r in df[df["slot"] == sl].to_dict("records"):
                if r["name"] not in seen:
                    seen.add(r["name"])
                    opts.append({"kind": src, "name": r["name"], "drop": r["drop"], "meso": r["meso"],
                                 "main": r["main_pct"], "lines": r["deme_lines"]})
        spare = pool[(pool["group"] == grp) & (pool["deme_lines"] > 0) & ~pool["name"].isin(used | seen)]
        for r in spare.drop_duplicates("name").to_dict("records"):
            opts.append({"kind": "보유 드메템", "name": r["name"], "drop": r["drop"], "meso": r["meso"],
                         "main": r["main_pct"], "lines": r["deme_lines"]})
        for label, d, m, n in BUY:
            if n == 3 and not allow_3line:
                continue
            opts.append({"kind": "구매", "name": label, "drop": d, "meso": m, "main": 0.0, "lines": n})
        options[sl] = opts
    plans = []
    for combo in itertools.product(*(options[sl] for sl in open_slots)):
        owned = [o["name"] for o in combo if o["kind"] != "구매"]
        if len(owned) != len(set(owned)):
            continue  # one item cannot sit in two slots
        raw_d = base_drop + sum(o["drop"] for o in combo)
        raw_m = base_meso + sum(o["meso"] for o in combo)
        d, m = min(drop_cap, raw_d), min(meso_cap, raw_m)
        short = max(0.0, drop_t - d) + max(0.0, meso_t - m)
        buys = [o for o in combo if o["kind"] == "구매"]
        key = (short, len(buys), sum(o["lines"] == 3 for o in buys), -sum(o["main"] for o in combo),
               (raw_d - d) + (raw_m - m))
        plans.append({"key": key, "slots": dict(zip(open_slots, combo)), "drop": d, "meso": m,
                      "raw_drop": raw_d, "raw_meso": raw_m, "short": short, "buys": len(buys),
                      "main": sum(o["main"] for o in combo)})
    plans.sort(key=lambda x: x["key"])
    # keep distinct outcomes (same buys on different slots count once)
    out, sigs = [], set()
    for pl in plans:
        sig = tuple(sorted((o["kind"], o["name"]) for o in pl["slots"].values()))
        if sig in sigs:
            continue
        sigs.add(sig)
        out.append(pl)
        if len(out) >= top:
            break
    return {"base_drop": base_drop, "base_meso": base_meso, "open_slots": open_slots, "fixed": fixed_rows,
            "excluded": base_rows, "plans": out, "options": options}


def selftest() -> None:
    mk = lambda slot, name, pot, main="INT": {"item_equipment_slot": slot, "item_name": name,
                                             **{f"potential_option_{i + 1}": p for i, p in enumerate(pot)}}
    boss = frame([mk("반지1", "보스A", ["INT +12%", "INT +9%", "INT +9%"]),
                  mk("반지2", "보스B", ["INT +9%", "INT +6%", "INT +6%"]),
                  mk("눈장식", "보스눈", ["INT +12%", "INT +9%", "INT +12%"])], "INT")
    pool = frame([mk("반지1", "드롭2", ["아이템 드롭률 +20%", "아이템 드롭률 +20%", "INT +9%"]),
                  mk("반지3", "메획2", ["메소 획득량 +20%", "메소 획득량 +20%", "최대 HP +9%"]),
                  mk("눈장식", "드롭1", ["아이템 드롭률 +20%", "INT +9%", "INT +9%"])], "INT")
    assert boss["main_pct"].tolist() == [30, 21, 33]
    assert pool["deme_lines"].tolist() == [2, 2, 1]
    r = optimize(boss, pool, drop_target=40, meso_target=40, drop_cap=100, meso_cap=100)
    assert set(r["chosen"]["name"]) == {"드롭2", "메획2"}, r["chosen"]
    assert set(r["removed"]["name"]) == {"보스A", "보스B"}  # both rings go, eye stays (1-line item excluded)
    assert r["drop"] == 40 and r["meso"] == 40 and r["short"] == 0
    assert r["lost"] == (30 + 21) - (9 + 0)
    r2 = optimize(boss, pool, drop_target=40, meso_target=0, drop_cap=100, meso_cap=100)
    assert list(r2["chosen"]["name"]) == ["드롭2"] and list(r2["removed"]["name"]) == ["보스B"]
    # plan: fixed 2-line items give drop 60 / meso 40; two open slots; target 100/40 -> buy one 드드, keep boss eye
    deme = frame([mk("반지1", "드롭2", ["아이템 드롭률 +20%", "아이템 드롭률 +20%", "INT +9%"]),
                  mk("반지2", "드메", ["아이템 드롭률 +20%", "메소 획득량 +20%", "INT +9%"]),
                  mk("반지3", "메획2", ["메소 획득량 +20%"]),
                  mk("눈장식", "드롭1눈", ["아이템 드롭률 +20%", "INT +9%", "INT +9%"]),
                  mk("펜던트", "정펜", [])], "INT")
    boss2 = frame([mk("눈장식", "보스눈", ["INT +12%", "INT +9%", "INT +12%"]),
                   mk("얼굴장식", "보스얼굴", ["INT +12%", "INT +9%", "INT +9%"])], "INT")
    pl = plan_open_slots(deme, boss2, deme, ["드롭2", "드메"], ["펜던트"], 100, 40, 200, 100)
    assert pl["base_drop"] == 60 and pl["base_meso"] == 20, (pl["base_drop"], pl["base_meso"])
    assert "반지3" in pl["open_slots"] and "펜던트" not in pl["open_slots"]
    best = pl["plans"][0]
    assert best["short"] == 0 and best["drop"] >= 100 and best["meso"] >= 40, best
    print("plan best:", {k: (v["kind"], v["name"]) for k, v in best["slots"].items()}, best["buys"], "buys")
    print("selftest ok")


if __name__ == "__main__":
    selftest()
