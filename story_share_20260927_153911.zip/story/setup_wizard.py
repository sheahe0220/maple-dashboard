"""First-time setup for a friend's PC: asks only for the API key, decides everything else.

Why: 2026-09-27 the user's friend cannot use a terminal ("딸깍 해서 되게"). 설치하기.bat installs Python and the
packages, then runs this. It
  1. shows a small window to paste the NEXON Open API key (opens openapi.nexon.com), checks it with
     /character/list (1 call) and writes .env,
  2. picks the world of the highest-level character, main character = that character, and a min level that
     keeps the top characters of that world, then writes config.yaml (characters: [] = everyone >= min level),
  3. registers the daily collection task (Windows Task Scheduler, 04:00) and a desktop shortcut.
Nothing here needs the user to type anything except the key.

Rerun (asks again, keeps nothing secret on screen):
    .venv\\Scripts\\python.exe -X utf8 setup_wizard.py
Test without the window (uses the key already in .env, writes config to a copy only):
    .venv\\Scripts\\python.exe -X utf8 setup_wizard.py --dry-run
"""
import argparse
import re
import subprocess
import sys
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENV = ROOT / ".env"
CONFIG = ROOT / "config.yaml"
HIDDEN = ROOT / "collect_hidden.pyw"  # daily task runs this with pythonw: no window at 04:00
LAUNCHER = ROOT / "launch_dashboard.pyw"
PYW = ROOT / ".venv" / "Scripts" / "pythonw.exe"
TASK = "MapleDashboard_DailyCollect"
KEY_PAGE = "https://openapi.nexon.com/"
TOP_N = 6          # keep about this many characters of the chosen world
LEVEL_FLOOR = 200  # never collect below this level

sys.path.insert(0, str(ROOT))
from nexon_api import ApiError, NexonAPI  # noqa: E402

GUIDE = ("넥슨 API 키를 넣어 주세요.\n\n"
         "1. 방금 열린 openapi.nexon.com 에서 넥슨 계정으로 로그인\n"
         "2. 애플리케이션(키) 등록 -> 개발 단계로 발급\n"
         "3. 발급된 키를 복사해서 아래 칸에 붙여 넣기 (Ctrl+V)\n\n"
         "키는 이 PC 의 .env 파일에만 저장되고 다른 곳으로 보내지 않습니다.")


def ask_key_window(error: str = "") -> str | None:
    """Small Tk window with one text box. Returns None if closed."""
    import tkinter as tk
    root = tk.Tk()
    root.title("메이플 대시보드 설치")
    root.attributes("-topmost", True)
    root.resizable(False, False)
    out = {"key": None}
    tk.Label(root, text=GUIDE, justify="left", font=("Malgun Gothic", 11), padx=16, pady=12).pack()
    if error:
        tk.Label(root, text=error, fg="#c0392b", font=("Malgun Gothic", 10, "bold"), padx=16).pack(anchor="w")
    e = tk.Entry(root, width=64, font=("Consolas", 11))
    e.pack(padx=16, pady=8)
    e.focus_set()

    def ok(_=None):
        out["key"] = e.get().strip()
        root.destroy()
    tk.Button(root, text="확인", width=12, font=("Malgun Gothic", 11, "bold"), command=ok).pack(pady=(0, 14))
    root.bind("<Return>", ok)
    root.eval("tk::PlaceWindow . center")
    root.mainloop()
    return out["key"]


def message(text: str, title: str = "메이플 대시보드 설치") -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk()
        r.withdraw()
        r.attributes("-topmost", True)
        messagebox.showinfo(title, text, parent=r)
        r.destroy()
    except Exception:
        print(text)


def check_key(key: str) -> list[dict]:
    api = NexonAPI(key, budget=3)
    chars = api.character_list()
    assert chars, "이 키의 계정에 캐릭터가 없습니다"
    return chars


def choose(chars: list[dict]) -> dict:
    """world of the highest-level character, that character as main, min level keeping the top TOP_N."""
    rows = [c for c in chars if c.get("character_level")]
    top = max(rows, key=lambda c: int(c["character_level"]))
    world = top["world_name"]
    levels = sorted((int(c["character_level"]) for c in rows if c["world_name"] == world), reverse=True)
    cut = levels[min(TOP_N, len(levels)) - 1]
    min_level = max(LEVEL_FLOOR, cut // 10 * 10) if levels[0] >= LEVEL_FLOOR else levels[-1]
    picked = [l for l in levels if l >= min_level]
    return {"world": world, "main": top["character_name"], "min_level": min_level, "count": len(picked),
            "main_level": int(top["character_level"]), "main_class": top.get("character_class", "")}


def write_config(text: str, pick: dict) -> str:
    subs = [(r"^world:.*$", f"world: {pick['world']}"),
            (r"^min_level:.*$", f"min_level: {pick['min_level']}"),
            (r"^characters:.*$", "characters: []"),
            (r"^main_character:.*$", f"main_character: {pick['main']}")]
    for pat, rep in subs:
        text, n = re.subn(pat, rep, text, count=1, flags=re.M)
        assert n == 1, f"config.yaml has no line for {pat}"
    return text


def powershell(script: str) -> subprocess.CompletedProcess:
    # PowerShell 5.1 prints in the OEM code page (cp949); force UTF-8 so Korean paths decode correctly
    script = "[Console]::OutputEncoding = [Text.Encoding]::UTF8; " + script
    return subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                          capture_output=True, text=True, encoding="utf-8", errors="replace")


def register_task() -> bool:
    ps = (f'$a = New-ScheduledTaskAction -Execute "{PYW}" -Argument \'"{HIDDEN}"\' -WorkingDirectory "{ROOT}";'
          '$t = New-ScheduledTaskTrigger -Daily -At 4:00AM;'
          '$s = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries '
          '-ExecutionTimeLimit (New-TimeSpan -Hours 2);'
          f'Register-ScheduledTask -TaskName "{TASK}" -Action $a -Trigger $t -Settings $s -Force | Out-Null;'
          f'(Get-ScheduledTask -TaskName "{TASK}").State')
    r = powershell(ps)
    return r.returncode == 0 and "Ready" in r.stdout


def make_shortcut() -> Path | None:
    ps = ('$d = [Environment]::GetFolderPath("Desktop");'
          '$l = Join-Path $d "메이플 대시보드.lnk";'
          '$s = (New-Object -ComObject WScript.Shell).CreateShortcut($l);'
          f'$s.TargetPath = "{PYW}"; $s.Arguments = \'"{LAUNCHER}"\'; $s.WorkingDirectory = "{ROOT}";'
          '$s.Description = "메이플 대시보드 켜기"; $s.Save(); $l')
    r = powershell(ps)
    p = Path(r.stdout.strip().splitlines()[-1]) if r.returncode == 0 and r.stdout.strip() else None
    return p if p and p.exists() else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="use the key in .env, no window, no task/shortcut")
    args = ap.parse_args()

    if args.dry_run:
        from nexon_api import load_key
        key = load_key()
    else:
        webbrowser.open(KEY_PAGE)
        key, err = None, ""
        while True:
            key = ask_key_window(err)
            if key is None:
                print("키 입력 창을 닫아서 설치를 멈춥니다. 설치하기.bat 을 다시 실행하면 이어서 합니다.")
                sys.exit(1)
            if len(key) < 20:
                err = "키가 너무 짧습니다. 발급 화면의 키 전체를 복사해 주세요."
                continue
            try:
                chars = check_key(key)
                break
            except (ApiError, AssertionError, Exception) as e:  # show any failure in the window and ask again
                err = f"키 확인 실패: {str(e)[:120]}"
    if args.dry_run:
        chars = check_key(key)
    pick = choose(chars)
    print(f"캐릭터 {len(chars)}명 확인. 월드 {pick['world']}, 본캐 {pick['main']} (Lv.{pick['main_level']} {pick['main_class']}), "
          f"{pick['min_level']}레벨 이상 {pick['count']}명을 수집합니다.")

    new_cfg = write_config(CONFIG.read_text(encoding="utf-8"), pick)
    if args.dry_run:
        out = ROOT / "config.dryrun.yaml"
        out.write_text(new_cfg, encoding="utf-8")
        print(f"dry run: {out} 에만 썼습니다. 작업 스케줄러 · 바로가기는 건드리지 않았습니다.")
        return
    ENV.write_text(f"NEXON_OPEN_API_KEY={key}\n", encoding="utf-8")
    CONFIG.write_text(new_cfg, encoding="utf-8")
    task_ok = register_task()
    lnk = make_shortcut()
    print("매일 자동 수집 등록:", "완료 (매일 04:00)" if task_ok else "실패 (나중에 다시 설치하기.bat)")
    print("바탕화면 아이콘:", lnk or "실패")
    message(f"설정 끝!\n\n월드 {pick['world']} · 본캐 {pick['main']}\n{pick['min_level']}레벨 이상 {pick['count']}명을 모읍니다.\n\n"
            "확인을 누르면 첫 수집을 시작합니다(5~10분). 검은 창은 끝날 때까지 닫지 마세요.\n"
            "다음부터는 바탕화면의 '메이플 대시보드' 아이콘만 누르면 됩니다.")


if __name__ == "__main__":
    main()
