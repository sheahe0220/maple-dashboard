"""Keep the 04:00 task and the desktop icon pointing at this folder after a friend moves or copies it.

Why: 2026-09-28 user: a friend may unzip anywhere or move the folder into 문서 by hand. The code and the .venv run
from any place (moved venv checked with `pythonw -m`), but setup_wizard stores absolute paths in the scheduled task
and the desktop shortcut, so after a move the icon points at nothing and 04:00 collection silently stops.
launch_dashboard.pyw (and 대시보드 켜기.bat through it) runs this at every start: when the folder differs from the one
recorded in data/install_path.txt, the task and the icon are registered again for this folder.
Friend copy only (update.yaml exists): the owner's PCs keep their own task (run_collector_daily.bat + DB upload).

Rerun:
    .venv\\Scripts\\python.exe -X utf8 relink.py             re-point if the folder moved
    .venv\\Scripts\\python.exe -X utf8 relink.py --selftest  move a temp folder, check task + shortcut follow it
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MARK_NAME = Path("data") / "install_path.txt"


def mark(root: Path = ROOT) -> None:
    p = root / MARK_NAME
    p.parent.mkdir(exist_ok=True)
    p.write_text(str(root), encoding="utf-8")


def ensure(root: Path = ROOT, task: str | None = None, desktop: Path | None = None) -> str:
    """One-line status. Never raises: the dashboard must start even when this fails."""
    try:
        if not (root / "update.yaml").exists():
            return "건너뜀 (배포 판 아님)"
        p = root / MARK_NAME
        if p.exists() and p.read_text(encoding="utf-8").strip() == str(root):
            return "그대로"
        sys.path.insert(0, str(ROOT))
        import setup_wizard as w
        task_ok = w.register_task(root, task or w.TASK)
        lnk = w.make_shortcut(root, desktop)
        if task_ok and lnk:
            mark(root)
            return f"새 위치로 다시 연결: {root}"
        return f"다시 연결 실패 (작업 {task_ok}, 아이콘 {lnk}), 다음 실행 때 다시 시도"
    except Exception as e:
        return f"다시 연결 실패: {type(e).__name__}: {e}"


def selftest() -> None:
    import shutil
    import tempfile
    sys.path.insert(0, str(ROOT))
    import setup_wizard as w
    task = "MapleDashboard_RelinkSelftest"  # never the real task name: the owner's PC has its own
    with tempfile.TemporaryDirectory() as t:
        t = Path(t)
        a, b, desk = t / "풀어 둔 곳" / "story", t / "문서" / "story", t / "desk"
        a.mkdir(parents=True), desk.mkdir()
        (a / "update.yaml").write_text("source: x\n", encoding="utf-8")
        assert ensure(a, task, desk).startswith("새 위치"), "first link"
        assert ensure(a, task, desk) == "그대로", "unchanged folder must not re-register"
        b.parent.mkdir()
        shutil.move(str(a), str(b))
        s = ensure(b, task, desk)
        assert s.startswith("새 위치"), s
        q = w.powershell(f'$t = Get-ScheduledTask -TaskName "{task}"; $t.Actions[0].Execute + "|" + $t.Actions[0].Arguments;'
                         f'$s = (New-Object -ComObject WScript.Shell).CreateShortcut("{desk}\\메이플 대시보드.lnk");'
                         '"|" + $s.TargetPath + "|" + $s.Arguments')
        w.powershell(f'Unregister-ScheduledTask -TaskName "{task}" -Confirm:$false')
        out = q.stdout.strip()
        print(out)
        assert out.count(str(b)) == 4 and str(a) not in out, "task / shortcut still point at the old folder"
        (b / "update.yaml").unlink()
        assert ensure(b, task, desk).startswith("건너뜀"), "owner copy must be left alone"
    print("relink selftest OK")


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        selftest()
    else:
        print(ensure())
