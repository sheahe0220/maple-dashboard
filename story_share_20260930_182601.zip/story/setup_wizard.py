"""First-time setup for a friend's PC: asks only for the API key, decides everything else.

Why: 2026-09-27 the user's friend cannot use a terminal ("딸깍 해서 되게"). 설치하기.bat installs Python and the
packages, then runs this. It
  1. shows a small window to paste the NEXON Open API key (opens openapi.nexon.com), checks it with
     /character/list (1 call) and writes .env,
  2. picks the world of the highest-level character, main character = that character, and a min level that
     keeps the top characters of that world, then writes config.yaml (characters: [] = everyone >= min level),
  3. registers the daily collection task (Windows Task Scheduler, 04:00) and a desktop shortcut.
Nothing here needs the user to type anything except the key.

Rerun (asks again, keeps nothing secret on screen):
    .venv\\Scripts\\python.exe -X utf8 setup_wizard.py
Test without the window (uses the key already in .env, writes config to a copy only):
    .venv\\Scripts\\python.exe -X utf8 setup_wizard.py --dry-run
"""
import argparse
import re
import subprocess
import sys
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ENV = ROOT / ".env"
CONFIG = ROOT / "config.yaml"
TASK = "MapleDashboard_DailyCollect"
KEY_PAGE = "https://openapi.nexon.com/"
TOP_N = 6          # keep about this many characters of the chosen world
LEVEL_FLOOR = 200  # never collect below this level
DEFAULT_PICK = 3   # characters ticked by default in the picker (보통 주보돌이 몇 명, 나머지는 유니온용)

sys.path.insert(0, str(ROOT))
from nexon_api import ApiError, NexonAPI  # noqa: E402

GUIDE = ("넥슨 API 키를 넣어 주세요.\n\n"
         "1. 방금 열린 openapi.nexon.com 에서 넥슨 계정으로 로그인\n"
         "2. 내 애플리케이션 -> 애플리케이션 등록하기 -> '서비스 단계' 선택, 칸은 받은 안내대로 채우기\n"
         "   (어려우면 '개발 단계' 도 됩니다. 서비스명만 아무거나, 과거 기록이 며칠에 걸쳐 채워질 뿐)\n"
         "3. 발급된 키를 복사해서 아래 칸에 붙여 넣기 (Ctrl+V)\n\n"
         "키는 이 PC 의 .env 파일에만 저장되고 다른 곳으로 보내지 않습니다.")


def ask_key_window(error: str = "") -> str | None:
    """Small Tk window with one text box. Returns None if closed."""
    import tkinter as tk
    root = tk.Tk()
    root.title("메이플 대시보드 설치")
    root.attributes("-topmost", True)
    root.resizable(False, False)
    out = {"key": None}
    tk.Label(root, text=GUIDE, justify="left", font=("Malgun Gothic", 11), padx=16, pady=12).pack()
    if error:
        tk.Label(root, text=error, fg="#c0392b", font=("Malgun Gothic", 10, "bold"), padx=16).pack(anchor="w")
    e = tk.Entry(root, width=64, font=("Consolas", 11))
    e.pack(padx=16, pady=8)
    e.focus_set()

    def ok(_=None):
        out["key"] = e.get().strip()
        root.destroy()
    tk.Button(root, text="확인", width=12, font=("Malgun Gothic", 11, "bold"), command=ok).pack(pady=(0, 14))
    root.bind("<Return>", ok)
    root.eval("tk::PlaceWindow . center")
    root.mainloop()
    return out["key"]


def pick_window(chars: list[dict], default: dict) -> dict | None:
    """World drop-down, a tick list of that world's characters (level order) and the 본캐 drop-down.
    Returns {"world", "characters", "main"}; None if the window is closed (then the defaults are used)."""
    import tkinter as tk
    from tkinter import ttk
    rows = [c for c in chars if c.get("character_level")]
    worlds = sorted({c["world_name"] for c in rows},
                    key=lambda w: -max(int(c["character_level"]) for c in rows if c["world_name"] == w))
    root = tk.Tk()
    root.title("메이플 대시보드 설치 - 캐릭터 고르기")
    root.minsize(500, 0)
    root.attributes("-topmost", True)
    out = {"sel": None}
    font = ("Malgun Gothic", 11)
    tk.Label(root, text="대시보드에 보여 줄 캐릭터를 골라 주세요.\n보통 보스 도는 캐릭터만 고르면 됩니다(유니온용은 빼도 됨).",
             justify="left", font=font, padx=16, pady=10, wraplength=460).pack(anchor="w")
    top = tk.Frame(root, padx=16)
    top.pack(fill="x")
    tk.Label(top, text="월드", font=font).pack(side="left")
    wvar = tk.StringVar(value=default["world"])
    wbox = ttk.Combobox(top, textvariable=wvar, values=worlds, state="readonly", width=14, font=font)
    wbox.pack(side="left", padx=8)
    frame = tk.Frame(root, padx=16, pady=6)
    frame.pack(fill="both", expand=True)
    canvas = tk.Canvas(frame, height=320, width=420, highlightthickness=0)
    bar = tk.Scrollbar(frame, orient="vertical", command=canvas.yview)
    inner = tk.Frame(canvas)
    inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=inner, anchor="nw")
    canvas.configure(yscrollcommand=bar.set)
    canvas.pack(side="left", fill="both", expand=True)
    bar.pack(side="right", fill="y")
    canvas.bind_all("<MouseWheel>", lambda e: canvas.yview_scroll(int(-e.delta / 120), "units"))
    checks: dict[str, tk.BooleanVar] = {}
    bottom = tk.Frame(root, padx=16, pady=8)
    bottom.pack(fill="x")
    tk.Label(bottom, text="본캐", font=font).pack(side="left")
    mvar = tk.StringVar()
    mbox = ttk.Combobox(bottom, textvariable=mvar, state="readonly", width=16, font=font)
    mbox.pack(side="left", padx=8)
    warn = tk.Label(root, text="", fg="#c0392b", font=("Malgun Gothic", 10, "bold"))
    warn.pack()

    def refresh_main(*_):
        names = [n for n, v in checks.items() if v.get()]
        mbox["values"] = names
        if mvar.get() not in names:
            mvar.set(names[0] if names else "")

    def fill(*_):
        for w in inner.winfo_children():
            w.destroy()
        checks.clear()
        in_world = sorted((c for c in rows if c["world_name"] == wvar.get()), key=lambda c: -int(c["character_level"]))
        preset = set(default["characters"]) if wvar.get() == default["world"] else \
            {c["character_name"] for c in in_world[:DEFAULT_PICK]}
        for c in in_world:
            v = tk.BooleanVar(value=c["character_name"] in preset)
            checks[c["character_name"]] = v
            tk.Checkbutton(inner, variable=v, command=refresh_main, font=font, anchor="w",
                           text=f"Lv.{c['character_level']}  {c['character_name']}  ({c.get('character_class', '')})"
                           ).pack(fill="x", anchor="w")
        refresh_main()
        if default["main"] in mbox["values"]:
            mvar.set(default["main"])
    wbox.bind("<<ComboboxSelected>>", fill)
    fill()

    def ok():
        names = [n for n, v in checks.items() if v.get()]
        if not names:
            warn.config(text="캐릭터를 한 명 이상 골라 주세요.")
            return
        out["sel"] = {"world": wvar.get(), "characters": names, "main": mvar.get() or names[0]}
        root.destroy()
    tk.Button(root, text="확인", width=12, font=("Malgun Gothic", 11, "bold"), command=ok).pack(pady=(0, 14))
    root.eval("tk::PlaceWindow . center")
    root.mainloop()
    return out["sel"]


def message(text: str, title: str = "메이플 대시보드 설치") -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk()
        r.withdraw()
        r.attributes("-topmost", True)
        messagebox.showinfo(title, text, parent=r)
        r.destroy()
    except Exception:
        print(text)


def saved_key() -> str | None:
    """The key in .env from an earlier setup, or None (missing file, placeholder, too short)."""
    if not ENV.exists():
        return None
    for line in ENV.read_text(encoding="utf-8").splitlines():
        if line.startswith("NEXON_OPEN_API_KEY="):
            k = line.split("=", 1)[1].strip()
            return k if len(k) >= 20 and "여기에" not in k else None
    return None


def configured(cfg_text: str) -> dict | None:
    """world / main character / min level already set by an earlier setup (main_character not empty)."""
    import yaml
    c = yaml.safe_load(cfg_text) or {}
    if not c.get("main_character"):
        return None
    return {"world": c.get("world"), "main": c["main_character"], "min_level": c.get("min_level")}


def check_key(key: str) -> list[dict]:
    api = NexonAPI(key, budget=3)
    chars = api.character_list()
    assert chars, "이 키의 계정에 캐릭터가 없습니다"
    return chars


def choose(chars: list[dict]) -> dict:
    """world of the highest-level character, that character as main, min level keeping the top TOP_N."""
    rows = [c for c in chars if c.get("character_level")]
    top = max(rows, key=lambda c: int(c["character_level"]))
    world = top["world_name"]
    levels = sorted((int(c["character_level"]) for c in rows if c["world_name"] == world), reverse=True)
    cut = levels[min(TOP_N, len(levels)) - 1]
    min_level = max(LEVEL_FLOOR, cut // 10 * 10) if levels[0] >= LEVEL_FLOOR else levels[-1]
    picked = [l for l in levels if l >= min_level]
    in_world = sorted((c for c in rows if c["world_name"] == world), key=lambda c: -int(c["character_level"]))
    return {"world": world, "main": top["character_name"], "min_level": min_level, "count": len(picked),
            "characters": [c["character_name"] for c in in_world[:DEFAULT_PICK]],
            "main_level": int(top["character_level"]), "main_class": top.get("character_class", "")}


def write_config(text: str, pick: dict) -> str:
    subs = [(r"^world:.*$", f"world: {pick['world']}"),
            (r"^min_level:.*$", f"min_level: {pick['min_level']}"),
            (r"^characters:.*$", "characters: [" + ", ".join(pick.get("characters") or []) + "]"),
            (r"^main_character:.*$", f"main_character: {pick['main']}")]
    for pat, rep in subs:
        text, n = re.subn(pat, rep, text, count=1, flags=re.M)
        assert n == 1, f"config.yaml has no line for {pat}"
    return text


def powershell(script: str) -> subprocess.CompletedProcess:
    # PowerShell 5.1 prints in the OEM code page (cp949); force UTF-8 so Korean paths decode correctly
    script = "[Console]::OutputEncoding = [Text.Encoding]::UTF8; " + script
    return subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                          capture_output=True, text=True, encoding="utf-8", errors="replace")


def register_task(root: Path = ROOT, task: str = TASK) -> bool:
    """04:00 daily collection for the folder `root` (re-run by relink.py when the folder moved)."""
    pyw, hidden = root / ".venv" / "Scripts" / "pythonw.exe", root / "collect_hidden.pyw"
    ps = (f'$a = New-ScheduledTaskAction -Execute "{pyw}" -Argument \'"{hidden}"\' -WorkingDirectory "{root}";'
          '$t = New-ScheduledTaskTrigger -Daily -At 4:00AM;'
          '$s = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries '
          '-ExecutionTimeLimit (New-TimeSpan -Hours 2);'
          f'Register-ScheduledTask -TaskName "{task}" -Action $a -Trigger $t -Settings $s -Force | Out-Null;'
          f'(Get-ScheduledTask -TaskName "{task}").State')
    r = powershell(ps)
    return r.returncode == 0 and "Ready" in r.stdout


def make_shortcut(root: Path = ROOT, desktop: Path | None = None) -> Path | None:
    """Desktop icon that starts the dashboard of the folder `root` (desktop: test folder instead of the Desktop)."""
    pyw, launcher = root / ".venv" / "Scripts" / "pythonw.exe", root / "launch_dashboard.pyw"
    where = f'"{desktop}"' if desktop else '[Environment]::GetFolderPath("Desktop")'
    ps = (f'$d = {where};'
          '$l = Join-Path $d "메이플 대시보드.lnk";'
          '$s = (New-Object -ComObject WScript.Shell).CreateShortcut($l);'
          f'$s.TargetPath = "{pyw}"; $s.Arguments = \'"{launcher}"\'; $s.WorkingDirectory = "{root}";'
          '$s.Description = "메이플 대시보드 켜기"; $s.Save(); $l')
    r = powershell(ps)
    p = Path(r.stdout.strip().splitlines()[-1]) if r.returncode == 0 and r.stdout.strip() else None
    return p if p and p.exists() else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="use the key in .env, no window, no task/shortcut")
    args = ap.parse_args()

    if args.dry_run:
        from nexon_api import load_key
        key = load_key()
    else:
        # a key saved by an earlier setup is reused without asking (2026-09-27 user: "다시 안 적어도 되게");
        # the window only appears when there is no key yet or Nexon rejects the saved one
        key, err, chars = saved_key(), "", None
        if key:
            try:
                chars = check_key(key)
                print("저장된 API 키를 그대로 씁니다.")
            except Exception as e:
                err = f"저장된 키가 더 이상 안 됩니다: {str(e)[:100]}"
                key = None
        if not key:
            webbrowser.open(KEY_PAGE)
        while not key:
            key = ask_key_window(err)
            if key is None:
                print("키 입력 창을 닫아서 설치를 멈춥니다. 설치하기.bat 을 다시 실행하면 이어서 합니다.")
                sys.exit(1)
            if len(key) < 20:
                err = "키가 너무 짧습니다. 발급 화면의 키 전체를 복사해 주세요."
                continue
            try:
                chars = check_key(key)
            except (ApiError, AssertionError, Exception) as e:  # show any failure in the window and ask again
                err = f"키 확인 실패: {str(e)[:120]}"
                key = None
    if args.dry_run:
        chars = check_key(key)
    pick = choose(chars)
    print(f"캐릭터 {len(chars)}명 확인. 월드 {pick['world']}, 본캐 {pick['main']} (Lv.{pick['main_level']} {pick['main_class']}), "
          f"{pick['min_level']}레벨 이상 {pick['count']}명을 수집합니다.")

    cur_cfg = CONFIG.read_text(encoding="utf-8")
    kept = configured(cur_cfg)
    if kept and not args.dry_run:  # re-run: keep the world / main character chosen before
        pick.update(kept)
        pick["count"] = sum(1 for c in chars if c.get("world_name") == pick["world"]
                            and int(c.get("character_level") or 0) >= int(pick["min_level"] or 0))
        print(f"기존 설정을 유지합니다: 월드 {pick['world']}, 본캐 {pick['main']}")
        new_cfg = cur_cfg
    else:
        sel = None if args.dry_run else pick_window(chars, pick)
        if sel:
            pick.update(sel)
        pick["count"] = len(pick["characters"])
        print(f"보여 줄 캐릭터 {pick['count']}명: {', '.join(pick['characters'])} (본캐 {pick['main']})")
        new_cfg = write_config(cur_cfg, pick)
    if args.dry_run:
        out = ROOT / "config.dryrun.yaml"
        out.write_text(new_cfg, encoding="utf-8")
        print(f"dry run: {out} 에만 썼습니다. 작업 스케줄러 · 바로가기는 건드리지 않았습니다.")
        return
    if key != saved_key():  # a reused key stays as it is (other lines in .env are kept)
        ENV.write_text(f"NEXON_OPEN_API_KEY={key}\n", encoding="utf-8")
    CONFIG.write_text(new_cfg, encoding="utf-8")
    task_ok = register_task()
    lnk = make_shortcut()
    if task_ok and lnk:  # relink.py re-registers both only when the folder has moved since
        import relink
        relink.mark(ROOT)
    print("매일 자동 수집 등록:", "완료 (매일 04:00)" if task_ok else "실패 (나중에 다시 설치하기.bat)")
    print("바탕화면 아이콘:", lnk or "실패")
    message(f"설정 끝!\n\n월드 {pick['world']} · 본캐 {pick['main']}\n캐릭터 {pick['count']}명을 모읍니다.\n\n"
            "확인을 누르면 첫 수집을 시작합니다(5~10분). 검은 창은 끝날 때까지 닫지 마세요.\n"
            "다음부터는 바탕화면의 '메이플 대시보드' 아이콘만 누르면 됩니다.")


if __name__ == "__main__":
    main()
