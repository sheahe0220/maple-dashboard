# ref/jobs: 직업 기준표

2026-09-27 작성. KMS 정규 직업 48개(나무위키 "메이플스토리/직업" 8절 직업의 순서, 2026-09-26 09:20:59 수정본)를
한 줄에 하나씩 담는다. "직업 정보" 탭의 입력이다. 만든 스크립트는 `10_조사/20260927_직업정보/f1~f4_*.py`,
조사 보고서는 같은 폴더의 `보고서.md` 에 있다.

```text
jobs_20260927.csv    직업당 1행, UTF-8 BOM, 57열 (아래 표)
jobs_20260927.yaml   meta · jobs(48) · overseas_in_maplescouter(6). 항목마다 source 를 붙였다
```

값은 출처에서 옮긴 그대로이며 계산하거나 추정해서 채운 칸은 없다. 빈 칸은 출처에서 찾지 못한 값이다.
`sc_` 로 시작하는 열은 maplescouter, `namu_` 로 시작하는 열은 나무위키 직업 문서 "스펙" 절 표다.
두 출처는 기준이 다르므로 값이 달라도 틀린 것으로 보지 않는다(보고서 3절).

## 열 설명

| 열 | 뜻 | 출처 |
|---|---|---|
| order | 인게임 직업 순서(1~48) | 나무 직업 8절 |
| job | 직업명(나무 표기) | 나무 직업 8절 |
| api_class_name | Open API character_class 표기. 확인된 차이는 듀얼블레이드 -> 듀얼블레이더 하나 | data/maple.db characters |
| branch | 계열(전사 · 마법사 · 궁수 · 도적 · 해적 · 하이브리드) | 나무 직업 문서 인포박스 |
| group | 직업군 분류: 모험가 · 시그너스 · 영웅 · 레지스탕스 · 레프 · 아니마 · 노바 · 기타(데몬 · 초월자 · 프렌즈 월드 · 마족) | race 에서 변환 |
| race | 나무 인포박스의 종족 · 직업군 원문 | 나무 인포박스 |
| main_stat · sub_stat | 주스탯 · 부스탯 원문 | 나무 인포박스 |
| main_weapon · sub_weapon | 주무기 · 보조무기 원문 | 나무 인포박스 |
| scouter_main · scouter_sub | maplescouter 주 · 부스탯 코드 | maplescouter 4850#22866 |
| weapon_const_scouter | 무기 상수(한 값) | maplescouter weaponConstant |
| weapon_const_namu · weapon_const_namu_basis | 무기 상수 원문과 해당 무기(한손 · 두손처럼 두 값이면 둘 다) | 나무 스펙 절 |
| proficiency_scouter · proficiency_namu | 숙련도(0.94 형식 · % 형식) | 각각 |
| attack_speed_namu | 공격 속도 단계와 근거 | 나무 스펙 절 |
| sc_main_stat_flat · sc_main_stat_pct | 패시브 주스탯 고정값 · % | maplescouter spec 판1 칸 0 · 1 |
| sc_atk_flat · sc_atk_pct | 패시브 공격력(마력) 고정값 · % | spec 칸 6 · 7 |
| sc_damage_pct · sc_boss_pct | 패시브 데미지% · 보스 데미지% | spec 칸 8 · 9 |
| sc_final_damage_pct | 패시브 최종 데미지 합성% | spec 칸 10 (= finalDamage) |
| sc_ignore_def_pct · sc_crit_rate_pct · sc_crit_dmg_pct | 방무 · 크확 · 크뎀 | spec 칸 11 · 12 · 13 |
| sc_final_damage_pct_passive_plus1 | 패시브 스킬 레벨 +1 일 때 최종 데미지 | spec 판2 |
| namu_main_stat_bonus · namu_atk · namu_damage · namu_boss | 스펙 절 주스탯 · 공마 · 데미지 · 보공 원문 | 나무 스펙 절 |
| namu_final_damage · namu_ignore_def · namu_crit_rate · namu_crit_dmg | 스펙 절 최종뎀 · 방무 · 크확 · 크뎀 원문(괄호는 조건부 최대) | 나무 스펙 절 |
| namu_spec_note | 스펙 절 기준 문구(예: 5, 6차 스킬 30레벨 기준) | 나무 스펙 절 |
| link_skill · link_master_level · link_effect_max | 링크 스킬 이름 · 마스터 레벨 · 최대 레벨 효과(전수받은 쪽 기준) | 나무 "링크 스킬" 6절 |
| union_effect | 유니온 공격대원 효과, 값은 B/A/S/SS/SSS 순 | 나무 "메이플 유니온/공격대원" 4.1절 |
| union_shared_row | Y = 원표에서 윗 직업과 칸을 합쳐 쓴 행(같은 효과) | 같은 표 |
| ability_keywords | 어빌리티 절에 나온 옵션을 언급 순서대로 자동 추출 [추정] | 나무 어빌리티 절 |
| hexa_mastery · hexa_enhance · hexa_skill | 6차 마스터리 · 강화 · 스킬 코어 이름 | 나무 직업/스킬 6차 절 |
| v_job_cores | 5차 직업 코어 이름 | 나무 직업/스킬 5차 절 |
| hyper_active | 하이퍼 액티브 스킬 이름 | 나무 직업/스킬 하이퍼 절 |
| hunt_note · boss_note | 운용 절 사냥 · 보스 첫 문장 인용 | 나무 직업 문서 |
| icon_url | 공식 직업 이미지 URL. 이번에는 비어 있다 [판정보류] | - |
| src_* | 각 열 묶음의 URL 과 나무 수정 시각 | - |

## YAML 구조

`jobs.<직업>` 아래 basic · maplescouter(constants 전체, spec 판1 · 판2) · namu_specs(스펙 표 전체) · link_skill(레벨별 효과,
본인 전용 효과) · union_raider · ability(키워드 + 원문 발췌) · skills(차수별 스킬 이름, 하이퍼 액티브, V · HEXA 코어) ·
play_notes · 본인 캐릭터가 있는 직업(키네시스 · 레테 · 에반)은 own_characters_db(Open API skill-6 이름 · 레벨 · 아이콘 URL,
보유 링크, 어빌리티, 하이퍼 스탯).

## 주의

- maplescouter spec 칸 7(공마%) · 10(최종뎀)은 JS 에서 `t.G[직업]` 로 모듈 65854 를 참조한다. 이 모듈은 수집본에 없어
  같은 필드명의 4850 모듈 22866 값을 넣었다 [추정]. 확인 방법: maplescouter 페이지에서 65854 가 든 청크를 받아 비교.
- 해외 전용 6개(하야토 · 칸나 · 린 · 묵현 · 시아 · 에렐)는 maplescouter 에만 있어 CSV 에서 뺐고 YAML 끝에 따로 둔다.
- 캐논슈터의 인게임 표기(나무 8절은 "캐논마스터")와 Open API 표기는 [판정보류]. 본인 계정에 해당 캐릭터가 없다.
