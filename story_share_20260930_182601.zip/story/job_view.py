"""직업 · 효율 sub-tab of the 스펙 tab: job reference for the chosen character, stat efficiency, and all 48 jobs.

Why: 2026-09-27 user asked for per-job information (주 · 부스탯, 무기, 패시브 최종뎀 · 보공 ..., 링크, 유니온, 어빌,
스킬 · 코어) for every character, with pictures, plus 효율 계산 per character.
Data: ref/jobs/jobs_20260927.csv (48 jobs; maplescouter constants + 나무위키, sources per row; report
10_조사/20260927_직업정보/보고서.md), images from ref/icons_extra via icons_extra.py, efficiency.py for the math.
"""
from functools import lru_cache
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st

import efficiency
import icons_extra

JOBS_CSV = Path(__file__).resolve().parent / "ref" / "jobs" / "jobs_20260927.csv"
SPECIAL_MAIN = {"제논", "데몬어벤져"}  # 3 main stats / HP based: the 4 x 주 + 부 model does not apply [판정보류]


@lru_cache(maxsize=1)
def jobs() -> pd.DataFrame:
    return pd.read_csv(JOBS_CSV)


STALE_CSV = JOBS_CSV.with_name("stale_812_20260927.csv")  # official patch check (10_조사/20260927_직업정보/검증)
# found by hand in the same check (공식대조.md 8번): 812 changed these but the 나무위키 스펙표 does not show it yet
STALE_EXTRA = {"키네시스": ["namu_ignore_def"], "아델": ["namu_atk"], "일리움": ["namu_damage"]}
VERIFY_CSV = JOBS_CSV.with_name("verify_20260927.csv")  # game check (verify_jobs_api.py), absent until it has run


def verify_status(job: str) -> str:
    """Badge text: game check result for this job, or that it has not been checked yet."""
    stale, notes = stale_info(job)
    patch = (":red-badge[패치 812 전 수치 포함]" if stale else
             ":blue-badge[공식 패치노트 대조: 확인할 점 있음]" if notes else ":green-badge[공식 패치노트 대조: 스펙표 최신]")
    if not VERIFY_CSV.exists():
        return patch + " :orange-badge[링크 스킬 게임 대조 전]"
    v = pd.read_csv(VERIFY_CSV)
    hit = v[v["job"] == job]
    if hit.empty:
        return ":orange-badge[게임 대조 없음]"
    verdict = hit.iloc[0]["verdict"]
    color = {"일치": "green", "이름만 일치": "blue"}.get(verdict, "red")
    return patch + f" :{color}-badge[링크 스킬 게임 대조: {verdict}]"


@lru_cache(maxsize=1)
def _stale_table() -> pd.DataFrame:
    return pd.read_csv(STALE_CSV) if STALE_CSV.exists() else pd.DataFrame()


def stale_info(job: str) -> tuple[set, list[str]]:
    """(fields quoting pre-812 values, notes) for this job."""
    t = _stale_table()
    fields, notes = set(STALE_EXTRA.get(job, [])), []
    if len(t) and job in set(t["job"]):
        r = t[t["job"] == job].iloc[0]
        fields |= set(str(r.get("stale_fields_confirmed") or "").split()) - {"nan"}
        if str(r.get("main_before_patch")) == "예":
            notes.append("나무위키 메인 문서가 패치 812 전 판입니다")
        if pd.notna(r.get("conditional_party_buff")):
            notes.append(f"괄호 안 데미지에 812 에서 파티 버프 기능이 삭제된 스킬({r['conditional_party_buff']})이 들어 있을 수 있습니다 [판정보류]")
        if pd.notna(r.get("other_doubts")):
            notes.append(f"812 변경: {r['other_doubts']}")
    return fields, notes


def job_row(class_name: str) -> pd.Series | None:
    j = jobs()
    hit = j[(j["api_class_name"] == class_name) | (j["job"] == class_name)]
    return hit.iloc[0] if len(hit) else None


def _txt(v) -> str:
    return "" if pd.isna(v) else str(v)


def _chips(text: str, icon_cat: str | None = None, job: str = "") -> str:
    """'a | b / c' -> inline chips, with a skill icon in front when one was fetched."""
    parts = [p.strip() for p in str(text).replace(" / ", " | ").split("|") if p.strip()]
    out = []
    for p in parts:
        # skill icons are saved as "<job>_<name>" with ":" turned into "_" (10_조사/20260927_그림보강)
        ic = (icons_extra.extra_icon(icon_cat, f"{job}_{p.replace(':', '_')}")
              or icons_extra.extra_icon(icon_cat, p)) if icon_cat else None
        img = f"<img src='{ic}' style='height:22px;vertical-align:middle;margin-right:4px'>" if ic else ""
        out.append(f"<span style='display:inline-block;padding:3px 9px;margin:2px;border-radius:12px;"
                   f"border:1px solid rgba(128,128,128,.35);font-size:.9rem'>{img}{p}</span>")
    return "".join(out)


def render(who: str, class_name: str, level: int, sp: dict, row_factory, is_main: bool = False) -> None:
    r = job_row(class_name)
    if r is None:
        st.info(f"'{class_name}' 직업 정보가 기준표에 없습니다.")
        return
    job = r["job"]
    # header: official job illustration + badges
    with st.container(border=True):
        head = st.container(horizontal=True, gap="large", vertical_alignment="center")
        art = icons_extra.extra_icon("job_art_s", job)
        if art:
            head.image(art, width=170)
        box = head.container(width="stretch")
        box.markdown(f"### {job}  \n:blue-badge[{r['branch']}] :violet-badge[{r['group']}] :gray-badge[{_txt(r['race'])}]"
                     f" :orange-badge[{'★ ' if is_main else ''}{who} · Lv.{level}]")
        box.caption(f"주무기 {r['main_weapon']} · 보조무기 {r['sub_weapon']}")
        box.markdown(verify_status(job), help="표의 수치는 나무위키 문서(수정 시각은 맨 아래 출처)와 maplescouter 상수입니다. "
                     "공식 패치노트 대조와 넥슨 API(게임 실제 값) 대조로 검증합니다.")
        k = row_factory()
        k.metric("주스탯 · 부스탯", f"{r['scouter_main']} · {r['scouter_sub']}", icon=":material/fitness_center:")
        k.metric("무기 상수", f"{r['weapon_const_namu']}", icon=":material/swords:",
                 help=f"무기 상수 기준: {_txt(r['weapon_const_namu_basis'])} (나무위키 · maplescouter 일치)")
        k.metric("숙련도", f"{_txt(r['proficiency_namu'])}%", icon=":material/tune:",
                 help=f"maplescouter 는 {float(r['proficiency_scouter']) * 100:.0f}% (패시브 +1 반영으로 보임 [추정])")
        k.metric("공격 속도", _txt(r["attack_speed_namu"]) or "-", icon=":material/speed:")

    left, right = st.columns([1, 1], gap="large")
    with left:
        st.markdown("**:material/shield: 패시브로 얻는 스탯 (스킬 기본값)**")
        rows = [("최종 데미지", r["namu_final_damage"], r["sc_final_damage_pct"]),
                ("데미지", r["namu_damage"], r["sc_damage_pct"]), ("보스 데미지", r["namu_boss"], r["sc_boss_pct"]),
                ("방어율 무시", r["namu_ignore_def"], r["sc_ignore_def_pct"]),
                ("크리티컬 확률", r["namu_crit_rate"], r["sc_crit_rate_pct"]),
                ("크리티컬 데미지", r["namu_crit_dmg"], r["sc_crit_dmg_pct"]),
                ("공격력 · 마력", r["namu_atk"], f"+{r['sc_atk_pct']}% +{r['sc_atk_flat']}"),
                ("주스탯", r["namu_main_stat_bonus"], f"+{r['sc_main_stat_pct']}% +{r['sc_main_stat_flat']}")]
        stale, notes = stale_info(job)
        col_of = {"최종 데미지": "namu_final_damage", "데미지": "namu_damage", "보스 데미지": "namu_boss",
                  "방어율 무시": "namu_ignore_def", "크리티컬 확률": "namu_crit_rate", "크리티컬 데미지": "namu_crit_dmg",
                  "공격력 · 마력": "namu_atk", "주스탯": "namu_main_stat_bonus"}
        df = pd.DataFrame([{"항목": a, "나무위키 스펙표": _txt(b), "maplescouter": _txt(c),
                            "상태": "패치 812 전 값" if col_of.get(a) in stale else ""} for a, b, c in rows])
        st.dataframe(df, hide_index=True, width="stretch", height="content")
        if stale or notes:
            st.warning("공식 패치노트 대조(업데이트 812, 2026-09-17 적용) 결과 이 직업은 "
                       + ("'상태'에 표시한 줄이 패치 전 값입니다. " if stale else "")
                       + " ".join(notes) + " 인게임 스탯창 · 스킬 툴팁이 정확합니다.", icon=":material/warning:")
        st.caption("두 출처는 정의가 달라 숫자가 다를 수 있습니다. maplescouter 는 크확 +10%p · 크뎀 +8%p 공용 버프와 "
                   "패시브 +1 을 기본으로 넣은 것으로 보입니다 [추정]. 괄호 안 값은 조건부 최대치입니다.")
    with right:
        st.markdown("**:material/link: 링크 스킬 · 유니온**")
        link_ic = icons_extra.extra_icon("skill_link", _txt(r["link_skill"]))
        with st.container(border=True):
            lh = st.container(horizontal=True, vertical_alignment="center", gap="small")
            if link_ic:
                lh.image(link_ic, width=36)
            lh.markdown(f"**{_txt(r['link_skill'])}** :gray-badge[최대 {_txt(r['link_master_level'])}레벨]")
            st.caption(_txt(r["link_effect_max"]))
        with st.container(border=True):
            st.markdown(f"**유니온 공격대원** :gray-badge[B ~ SSS]")
            st.caption(_txt(r["union_effect"]))
        # recommended ability vs the character's own
        st.markdown("**:material/psychology: 어빌리티**")
        mine = []
        for a in ((sp.get("ability") or {}).get("ability_info") or []):
            mine.append(f"{a.get('ability_grade', '')} {a.get('ability_value', '')}".strip())
        with st.container(border=True):
            st.markdown(f"추천 (나무위키 본문 순): **{_txt(r['ability_keywords']) or '-'}**")
            if mine:
                st.caption("내 캐릭터 지금: " + " / ".join(mine))

    st.markdown("**:material/hexagon: 6차 · 5차 코어**")
    for title, col, cat in (("스킬 코어", "hexa_skill", "skill_hexa"), ("마스터리 코어", "hexa_mastery", "skill_hexa"),
                            ("강화 코어", "hexa_enhance", "skill_hexa"), ("5차 직업 코어", "v_job_cores", "skill_v"),
                            ("하이퍼 액티브", "hyper_active", None)):
        if _txt(r[col]):
            st.markdown(f"<div style='margin:4px 0'><b style='font-size:.9rem;opacity:.75'>{title}</b><br>"
                        f"{_chips(r[col], cat, job)}</div>", unsafe_allow_html=True)
    notes = [x for x in (_txt(r["hunt_note"]), _txt(r["boss_note"])) if x]
    if notes:
        with st.expander("직업 한 줄 메모 (나무위키 본문 발췌)", icon=":material/notes:"):
            for n in notes:
                st.caption(n)
    st.caption("출처: " + " · ".join(x for x in (_txt(r["src_namu_main"]), _txt(r["src_namu_skill"]),
                                                   _txt(r["src_link"]), _txt(r["src_scouter"])) if x))

    efficiency_section(who, r, sp)


def efficiency_section(who: str, r: pd.Series, sp: dict) -> None:
    st.subheader("스탯 효율", divider=False, help="이 캐릭터의 지금 스탯에서 무엇을 올려야 보스 딜이 가장 많이 오르는지")
    stat = sp.get("stat") or {}
    fs = efficiency.final_stats(stat)
    if not fs:
        st.info("스탯 기록이 없습니다. '지금 갱신'을 눌러 주세요.")
        return
    if r["job"] in SPECIAL_MAIN:
        st.warning(f"{r['job']}은(는) 주스탯 규칙이 달라(제논: 스탯 3개, 데몬어벤져: HP) 주스탯 · 공마 줄은 뺐습니다.")
    main, sub = str(r["scouter_main"]), str(r["scouter_sub"])
    magic = r["branch"] == "마법사"
    rows = pd.DataFrame(efficiency.table(fs, main, sub, magic))
    if r["job"] in SPECIAL_MAIN:
        rows = rows[~rows["항목"].str.match(rf"^({main}|{sub}|공격력|마력) 1$")]
    c1, c2 = st.columns([3, 2], gap="large")
    with c1:
        chart = rows[rows["항목"].str.contains("%")].copy()
        chart["보공 % 환산"] = chart["보공 % 환산"].round(2)
        st.altair_chart(
            alt.Chart(chart).mark_bar(cornerRadiusEnd=4).encode(
                x=alt.X("보공 % 환산:Q", title="보공 몇 %와 같은가"),
                y=alt.Y("항목:N", sort="-x", title=None),
                tooltip=["항목", alt.Tooltip("보공 % 환산:Q", format=".2f"), alt.Tooltip("딜 증가(%):Q", format=".3f")])
            + alt.Chart(chart).mark_text(align="left", dx=4, fontWeight="bold",
                                         color="#e6e6e6" if st.context.theme.type == "dark" else "#31333f").encode(
                x="보공 % 환산:Q", y=alt.Y("항목:N", sort="-x"), text=alt.Text("보공 % 환산:Q", format=".2f")),
            width="stretch")
    with c2:
        st.dataframe(rows, hide_index=True, width="stretch", height="content", column_config={
            "딜 증가(%)": st.column_config.NumberColumn(format="+%.4f%%"),
            "보공 % 환산": st.column_config.NumberColumn(format="%.3f"),
            "딜 1% 에 필요": st.column_config.NumberColumn(format="%,.2f")})
    best = rows[rows["항목"].str.contains("%") & ~rows["항목"].str.startswith("최종뎀")].nlargest(1, "보공 % 환산")
    if len(best):
        b = best.iloc[0]
        st.success(f"지금 {who}에게 1%당 가장 값진 옵션은 **{b['항목']}** (보공 {b['보공 % 환산']:.2f}%와 같음). "
                   "최종뎀은 곱연산이라 늘 가장 높습니다.", icon=":material/lightbulb:")
    st.caption(f"기준 스탯: 보공 {fs.get('보스 몬스터 데미지', 0):.0f}% · 데미지 {fs.get('데미지', 0):.0f}% · "
               f"크뎀 {fs.get('크리티컬 데미지', 0):.0f}% · 방무 {fs.get('방어율 무시', 0):.2f}%. API 스탯은 저장 시점 버프가 "
               "들어간 값이라 인게임 노버프 스탯창과 조금 다를 수 있습니다. 식은 maplescouter 와 같은 곱셈 모형(검증 0.004% 이내).")


def all_jobs_section() -> None:
    j = jobs().copy()
    branches = ["전체"] + list(dict.fromkeys(j["branch"]))
    pick = st.segmented_control("계열", branches, default="전체", key="jobs_branch") or "전체"
    if pick != "전체":
        j = j[j["branch"] == pick]
    j.insert(0, "그림", [icons_extra.extra_icon("job_thumb_s", n) for n in j["job"]])
    show = j[["그림", "job", "branch", "group", "scouter_main", "weapon_const_namu", "namu_final_damage",
              "namu_boss", "namu_ignore_def", "link_skill", "union_effect"]].rename(columns={
        "job": "직업", "branch": "계열", "group": "직업군", "scouter_main": "주스탯", "weapon_const_namu": "무기 상수",
        "namu_final_damage": "패시브 최종뎀", "namu_boss": "패시브 보공", "namu_ignore_def": "패시브 방무",
        "link_skill": "링크 스킬", "union_effect": "유니온 효과"})
    st.dataframe(show, hide_index=True, width="stretch", row_height=56, height=min(40 + 57 * len(show), 700),
                 column_config={"그림": st.column_config.ImageColumn(" ", width="small")})
    st.caption(f"{len(show)}개 직업. 기준표 ref/jobs/jobs_20260927.csv (나무위키 직업 · 스킬 문서, maplescouter 상수, 2026-09-27).")
