"""Thin wrapper over NEXON Open API (MapleStory).

Why: one place for auth header, per-second throttle, 429/5xx retry and the
daily call budget, so collector.py only deals with what to fetch.
Spec source: 10_조사/api_spec/*.yaml (downloaded 2026-09-18 from openapi.nexon.com).
"""
import time
from pathlib import Path

import requests

BASE = "https://open.api.nexon.com"
ENV_PATH = Path(__file__).resolve().parent / ".env"


class BudgetExhausted(Exception):
    pass


class ApiError(Exception):
    def __init__(self, status: int, path: str, body: str):
        super().__init__(f"HTTP {status} {path}: {body[:300]}")
        self.status = status


def load_key() -> str:
    assert ENV_PATH.exists(), f".env not found: {ENV_PATH} (copy .env.example and put your key)"
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        if line.startswith("NEXON_OPEN_API_KEY="):
            key = line.split("=", 1)[1].strip()
            assert key and "여기에" not in key, "NEXON_OPEN_API_KEY is empty in .env"
            return key
    raise AssertionError("NEXON_OPEN_API_KEY missing in .env")


def daily_budget(cfg: dict) -> int:
    """Calls allowed per KST day for the key in .env. Service-stage keys (live_) get daily_call_budget_live
    (NEXON limit 20,000,000/day); dev keys (test_, 1,000/day) keep daily_call_budget. 2026-09-28: the owner moved
    to a service key while friends keep dev keys, so one config.yaml serves both."""
    try:
        live = load_key().startswith("live_")
    except AssertionError:
        live = False
    return int(cfg.get("daily_call_budget_live", 50000)) if live else int(cfg["daily_call_budget"])


class NexonAPI:
    def __init__(self, key: str, budget: int, on_call=None):
        self.key = key
        self.budget = budget          # calls allowed in this run
        self.calls = 0
        self.on_call = on_call        # callback to persist the daily count
        # dev keys are 5/s; stay under it. live keys allow 500/s, no need to push.
        self.min_interval = 0.22 if key.startswith("test_") else 0.05
        self._last = 0.0
        self.session = requests.Session()
        self.session.headers["x-nxopen-api-key"] = key

    def get(self, path: str, **params) -> dict:
        for attempt in range(6):
            if self.calls >= self.budget:
                raise BudgetExhausted(f"budget {self.budget} used")
            wait = self.min_interval - (time.monotonic() - self._last)
            if wait > 0:
                time.sleep(wait)
            self._last = time.monotonic()
            r = self.session.get(BASE + path, params=params, timeout=20)
            self.calls += 1
            if self.on_call:
                self.on_call()
            if r.status_code == 200:
                return r.json()
            if r.status_code == 429 or r.status_code >= 500:
                time.sleep(2 ** attempt)
                continue
            raise ApiError(r.status_code, path, r.text)
        raise ApiError(r.status_code, path, "retries exhausted")

    # --- endpoints used by the collector ---
    def character_list(self) -> list[dict]:
        d = self.get("/maplestory/v1/character/list")
        return [{**c, "account_id": acc["account_id"]}
                for acc in d["account_list"] for c in acc["character_list"]]

    def character(self, endpoint: str, ocid: str, date: str | None = None) -> dict:
        params = {"ocid": ocid}
        if date:
            params["date"] = date
        if endpoint.startswith("skill-"):  # "skill-6" = /character/skill?character_skill_grade=6 (hexa, icons)
            params["character_skill_grade"] = endpoint.split("-", 1)[1]
            endpoint = "skill"
        # union, union-raider, union-artifact, union-champion live under /user/ (api_spec 18)
        prefix = "/maplestory/v1/user/" if endpoint.startswith("union") else "/maplestory/v1/character/"
        return self.get(prefix + endpoint, **params)

    def scheduler(self, ocid: str, date: str | None = None) -> dict:
        # today's state must be requested without date (date=today returns 400, checked 2026-09-18)
        params = {"ocid": ocid}
        if date:
            params["date"] = date
        return self.get("/maplestory/v1/scheduler/character-state", **params)

    def history_day(self, kind: str, date: str) -> list[dict]:
        """All records of one KST day, following next_cursor."""
        list_key = {"starforce": "starforce_history", "potential": "potential_history",
                    "cube": "cube_history", "soul-potential": "soul_potential_history"}[kind]
        out, cursor = [], None
        while True:
            params = {"count": 1000}
            params.update({"cursor": cursor} if cursor else {"date": date})
            d = self.get(f"/maplestory/v1/history/{kind}", **params)
            out.extend(d.get(list_key) or [])
            cursor = d.get("next_cursor")
            if not cursor:
                return out
