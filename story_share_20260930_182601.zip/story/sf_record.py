"""Starforce record analysis: meso spent, luck (이득 / 손해) per attempt and per item, and trivia.

Why: 2026-09-27 user asked for efficiency on the 스타포스 기록 tab ("얼마 이득이고 얼마 손해"), a per-item view like
other sites, and extra trivia. The API record has no meso field, so the cost of each attempt is rebuilt from the
official cost formula (calc_starforce.tables) with that attempt's own events, 파괴 방지 and the item level
(from item-equipment snapshots).

Luck of one attempt at star s, with V(x) = expected meso to reach the item's highest star from x under that
attempt's own setup (V solved exactly, same linear system as calc_starforce.expected):
    value = V(s) - V(s')        s' = star after (success / keep) or 12 (destroy)
    luck  = value - cost        > 0 : 평균보다 이득,  < 0 : 손해
By the Bellman equation E[value] = cost at every state, so luck has mean 0 for any mix of events and 파방;
selftest checks this by simulation. A destroy therefore counts as the meso it takes on average to climb back.
Not included: 흔적 복구 · 스페어 비용 (not in the record), PC방 discount, 강화권 uses (no meso).

Self-test:
    <설치 폴더>\\.venv\\Scripts\\python.exe -X utf8 <설치 폴더>\\sf_record.py
"""
import json
from functools import lru_cache

import numpy as np
import pandas as pd

import calc_starforce as sfc

RESULT_OK, RESULT_KEEP, RESULT_BOOM = "성공", "실패(유지)", "파괴"


def level_map(con) -> dict:
    """item name -> required level, from every stored item-equipment snapshot (all presets)."""
    out = {}
    for (j,) in con.execute("SELECT json FROM snapshot WHERE endpoint='item-equipment' AND json NOT LIKE '%_error%'"):
        for v in json.loads(j).values():
            if isinstance(v, list):
                for it in v:
                    if isinstance(it, dict) and it.get("item_name"):
                        lv = (it.get("item_base_option") or {}).get("base_equipment_level")
                        if lv:
                            out[it["item_name"]] = int(lv)
    return out


def _in_range(rng, star: int) -> bool:
    if not rng:
        return True
    rng = str(rng)
    if "~" in rng:
        a, b = rng.split("~")
        return int(a) <= star <= int(b)
    return str(star) in rng.split(",")


def event_set(events, star: int) -> frozenset:
    """API starforce_event_list -> calc_starforce flags that apply at this star."""
    flags = set()
    for e in events if isinstance(events, list) else []:
        if not _in_range(e.get("starforce_event_range"), star):
            continue
        if str(e.get("cost_discount_rate")) == "30":
            flags.add("discount30")
        if str(e.get("destroy_decrease_rate")) == "30":
            flags.add("destroy_down")
        if e.get("plus_value"):
            flags.add("one_plus_one")
        if str(e.get("success_rate")) == "100":
            flags.add("guarantee")
    return frozenset(flags)


@lru_cache(maxsize=4096)
def _setup_tables(level: int, flags: frozenset, mvp: str, guard: bool, star: int):
    s = sfc.Setup(level=level, start=star, target=min(star + 1, 30), event=set(flags), mvp=mvp,
                  safeguard={star} if guard else set())
    return sfc.tables(s)


@lru_cache(maxsize=4096)
def values(level: int, flags: frozenset, mvp: str, guard: bool, star: int, target: int) -> np.ndarray:
    """V[x] for x in 0..target (V[target..] = 0): expected meso to first reach `target` from x, where the attempt
    setup (events, 파방 at `star` only) is the one of the attempt being scored. Same system as sfc.expected."""
    prob, cost, dest_star, dest_cost = _setup_tables(level, flags, mvp, guard, star)
    step2 = "one_plus_one" in flags
    lo = min(star, sfc.DESTROY_RESET_STAR)
    n = target - lo
    A = np.eye(n)
    b = np.zeros(n)
    for i in range(n):
        st = lo + i
        p, m, d = prob[st]
        A[i, i] -= m
        nxt = st + (2 if step2 and st <= 10 else 1)
        if nxt < target:
            A[i, nxt - lo] -= p
        if d > 0:
            A[i, dest_star[st] - lo] -= d
        b[i] = cost[st] + d * dest_cost[st]
    v = np.zeros(max(target, 30) + 3)
    v[lo:target] = np.linalg.solve(A, b)
    return v


def analyze(sf: pd.DataFrame, levels: dict, mvp: str = "없음"):
    """sf: starforce history rows (API fields, date_create as datetime). Returns (attempts, items, trivia)."""
    a = sf.sort_values("date_create").copy()
    a["렙제"] = a["target_item"].map(levels)
    a["강화권"] = a["upgrade_item"].fillna("").astype(str).str.len() > 0
    a["파방"] = a["destroy_defence"].astype(str).eq("파괴 방지 적용")
    # the item's highest star in the record is the goal the luck is measured against
    a["목표"] = a.groupby(["character_name", "target_item"])["after_starforce_count"].transform("max")
    a["목표"] = np.maximum(a["목표"], a["before_starforce_count"] + 1).clip(upper=30)
    cost, value, ps, pdes, flags_txt = [], [], [], [], []
    for r in a.itertuples():
        st = int(r.before_starforce_count)
        if r.강화권 or pd.isna(r.렙제) or st >= 30:
            cost.append(np.nan); value.append(np.nan); ps.append(np.nan); pdes.append(np.nan); flags_txt.append("")
            continue
        fl = event_set(r.starforce_event_list, st)
        lv, tgt = int(r.렙제), int(r.목표)
        prob, c, _, _ = _setup_tables(lv, fl, mvp, bool(r.파방), st)
        v = values(lv, fl, mvp, bool(r.파방), st, tgt)
        if r.item_upgrade_result == RESULT_BOOM:
            nxt = sfc.DESTROY_RESET_STAR
        elif r.item_upgrade_result == RESULT_OK:
            nxt = int(r.after_starforce_count)
        else:
            nxt = st
        cost.append(float(c[st]))
        value.append(float(v[st] - v[min(nxt, len(v) - 1)]))
        ps.append(float(prob[st, 0])); pdes.append(float(prob[st, 2]))
        flags_txt.append(" · ".join(sorted({"discount30": "30% 할인", "destroy_down": "파괴 감소",
                                            "one_plus_one": "1+1", "guarantee": "100%"}[f] for f in fl)))
    a["비용"], a["가치"], a["성공 확률"], a["파괴 확률"], a["이벤트"] = cost, value, ps, pdes, flags_txt
    a["이득"] = a["가치"] - a["비용"]

    g = a.groupby(["character_name", "target_item"], sort=False)
    items = pd.DataFrame({
        "시도": g.size(),
        "시작": g["before_starforce_count"].first(),
        "최종": g["after_starforce_count"].last(),
        "최고": g["after_starforce_count"].max(),
        "성공": g["item_upgrade_result"].apply(lambda s: (s == RESULT_OK).sum()),
        "실패": g["item_upgrade_result"].apply(lambda s: (s == RESULT_KEEP).sum()),
        "파괴": g["item_upgrade_result"].apply(lambda s: (s == RESULT_BOOM).sum()),
        "기대 파괴": g["파괴 확률"].sum(),
        "쓴 메소": g["비용"].sum(min_count=1),
        "평균 비용": g["가치"].sum(min_count=1),
        "이득": g["이득"].sum(min_count=1),
        "렙제": g["렙제"].first(),
        "마지막": g["date_create"].max(),
    }).reset_index()
    items["운"] = items["평균 비용"] / items["쓴 메소"]

    trivia = {}
    m = a.dropna(subset=["비용"])
    if len(m):
        best = m[m["item_upgrade_result"] == RESULT_OK].nsmallest(1, "성공 확률")
        if len(best):
            b = best.iloc[0]
            trivia["가장 운 좋은 성공"] = (f"{b.target_item} {int(b.before_starforce_count)}→{int(b.after_starforce_count)}성 "
                                     f"(성공 확률 {b['성공 확률']:.1%})")
        big = m.nlargest(1, "비용").iloc[0]
        trivia["가장 비싼 한 번"] = f"{big.target_item} {int(big.before_starforce_count)}성 {big['비용'] / 1e8:,.2f}억"
        lucky = m.nlargest(1, "이득").iloc[0]
        trivia["가장 이득 본 한 번"] = (f"{lucky.target_item} {int(lucky.before_starforce_count)}성 "
                                   f"{lucky.item_upgrade_result} (+{lucky['이득'] / 1e8:,.2f}억)")
        worst = m.nsmallest(1, "이득").iloc[0]
        trivia["가장 손해 본 한 번"] = (f"{worst.target_item} {int(worst.before_starforce_count)}성 "
                                   f"{worst.item_upgrade_result} ({worst['이득'] / 1e8:,.2f}억)")
        guard = m[m["파방"]]
        if len(guard):
            extra = sum(sfc.base_cost(int(r.렙제), int(r.before_starforce_count)) * 2 for r in guard.itertuples())
            trivia["파괴 방지"] = f"{len(guard)}회 사용, 추가금 {extra / 1e8:,.2f}억"
        ev = m[m["이벤트"] != ""]
        trivia["이벤트 날 강화"] = f"{len(ev)} / {len(m)}회 ({len(ev) / len(m):.0%})"
        day = m.groupby(m["date_create"].dt.date)["비용"].sum()
        trivia["가장 많이 쓴 날"] = f"{day.idxmax()} {day.max() / 1e8:,.2f}억"
    streak_best, streak_item = 0, ""
    for (ch, it), s in a.groupby(["character_name", "target_item"])["item_upgrade_result"]:
        run = 0
        for x in s:
            run = run + 1 if x == RESULT_KEEP else 0
            if run > streak_best:
                streak_best, streak_item = run, it
    if streak_best:
        trivia["최장 연속 실패"] = f"{streak_item} {streak_best}연속"
    trivia["_제외"] = int(a["비용"].isna().sum())
    trivia["_제외_렙제모름"] = sorted(a.loc[a["렙제"].isna(), "target_item"].unique())
    trivia["_강화권"] = int(a["강화권"].sum())
    return a, items, trivia


def selftest() -> None:
    # 1) luck has mean 0: simulate one item 12 -> 22 under a mixed setup (샤타포스 on half the attempts,
    #    파방 at 15~17 sometimes) and score it with analyze()
    rng = np.random.default_rng(7)
    lv, runs, lucks = 200, 1500, []
    shining = [{"cost_discount_rate": "30", "starforce_event_range": "0~29"},
               {"destroy_decrease_rate": "30", "starforce_event_range": "15,16,17,18,19,20,21"}]
    for k in range(runs):
        rows, st, t = [], 12, 0
        while st < 22:
            ev = shining if rng.random() < 0.5 else None
            guard = st in (15, 16, 17) and rng.random() < 0.5
            prob, *_ = _setup_tables(lv, event_set(ev, st), "없음", guard, st)
            r = rng.random()
            res = RESULT_OK if r < prob[st, 0] else (RESULT_BOOM if r >= 1 - prob[st, 2] else RESULT_KEEP)
            after = st + 1 if res == RESULT_OK else (0 if res == RESULT_BOOM else st)
            rows.append({"before_starforce_count": st, "after_starforce_count": after, "item_upgrade_result": res,
                         "starforce_event_list": ev, "destroy_defence": "파괴 방지 적용" if guard else "파괴 방지 미적용",
                         "upgrade_item": "", "character_name": "x", "target_item": "t",
                         "date_create": pd.Timestamp("2026-01-01") + pd.Timedelta(seconds=t)})
            st = st + 1 if res == RESULT_OK else (sfc.DESTROY_RESET_STAR if res == RESULT_BOOM else st)
            t += 1
        df = pd.DataFrame(rows)
        df.loc[df.index[-1], "after_starforce_count"] = 22  # goal fixed at 22 for every run
        a, items, _ = analyze(df, {"t": lv})
        lucks.append(a["이득"].sum())
    lucks = np.array(lucks)
    z = lucks.mean() / (lucks.std() / np.sqrt(runs))
    print(f"simulated luck mean {lucks.mean() / 1e8:,.3f}억 (sd {lucks.std() / 1e8:,.1f}억), z = {z:.2f}")
    assert abs(z) < 3, z
    # 2) event parsing
    assert event_set(shining, 16) == {"discount30", "destroy_down"} and event_set(shining, 22) == {"discount30"}
    # 3) real records
    import db
    con = db.connect()
    rows = [json.loads(j) for (j,) in con.execute("SELECT json FROM history WHERE kind='starforce'")]
    lv_map = level_map(con)
    con.close()
    assert rows and lv_map, "no starforce records or item levels"
    sf = pd.DataFrame(rows)
    sf["date_create"] = pd.to_datetime(sf["date_create"], format="ISO8601")
    a, items, trivia = analyze(sf, lv_map)
    assert len(items) > 0 and a["비용"].notna().sum() > 0
    print(f"records {len(a)}, scored {a['비용'].notna().sum()}, items {len(items)}, "
          f"spent {a['비용'].sum() / 1e8:,.2f}억, luck {a['이득'].sum() / 1e8:+,.2f}억")
    for k, v in trivia.items():
        print(" ", k, v)
    print("selftest ok")


if __name__ == "__main__":
    selftest()
