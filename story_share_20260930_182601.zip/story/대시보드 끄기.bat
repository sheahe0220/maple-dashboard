@echo off
rem Stop the dashboard (2026-09-28, friendly name for stop_dashboard.bat). CP949 + CRLF (write_bats.py).
chcp 949 > nul
call "%~dp0stop_dashboard.bat"
