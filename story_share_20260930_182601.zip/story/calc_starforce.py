"""Starforce expected cost / destroys: exact Markov solve + Monte Carlo quantiles.

Why: answer "how much does N -> M star cost on average, and in a bad case".
Rules and numbers (re-implemented, not copied; source is AGPL):
    probability table (star catch always on since 2026-03-19), cost formula,
    discount order, safeguard, trace-restore table
    <- kurateh/mesulive src/entities/starforce/constants.ts, utils.ts
       (commit 2026-03-21 "Fix starforce starcatch"), docs/starforce-simulator-system.md
       local copy: 10_조사/ref_mesulive/
    cross-check: 17->18 = 15.75 / 77.51 / 6.74 %, same as the displayed rate quoted by
       meaegi.com/statistics/starforce (2026-09-18 search).
The two methods are checked against each other in selftest().

Rerun self-test:
    <설치 폴더>\\.venv\\Scripts\\python.exe -X utf8 <설치 폴더>\\calc_starforce.py
"""
import math
from dataclasses import dataclass, field

import numpy as np

# [success, maintain, destroy] per current star 0..29
PROB = np.array([
    [0.9975, 0.0025, 0], [0.945, 0.055, 0], [0.8925, 0.1075, 0], [0.8925, 0.1075, 0],
    [0.84, 0.16, 0], [0.7875, 0.2125, 0], [0.735, 0.265, 0], [0.6825, 0.3175, 0],
    [0.63, 0.37, 0], [0.5775, 0.4225, 0], [0.525, 0.475, 0], [0.4725, 0.5275, 0],
    [0.42, 0.58, 0], [0.3675, 0.6325, 0], [0.315, 0.685, 0],
    [0.315, 0.66445, 0.02055], [0.315, 0.66445, 0.02055],
    [0.1575, 0.7751, 0.0674], [0.1575, 0.7751, 0.0674], [0.1575, 0.75825, 0.08425],
    [0.315, 0.58225, 0.10275], [0.1575, 0.716125, 0.126375], [0.1575, 0.674, 0.1685],
    [0.105, 0.716, 0.179], [0.105, 0.716, 0.179], [0.105, 0.716, 0.179],
    [0.0735, 0.7412, 0.1853], [0.0525, 0.758, 0.1895], [0.0315, 0.7748, 0.1937],
    [0.0105, 0.7916, 0.1979],
])
# row 26: source has maintain 0.7416 (sums to 1.0004); recomputed from pre-catch 0.07/0.744/0.186 -> 0.7412
assert np.allclose(PROB.sum(axis=1), 1.0)

DIVISOR = {10: 571, 11: 314, 12: 214, 13: 157, 14: 107, 17: 150, 18: 70, 19: 45, 21: 125}
DESTROY_RESET_STAR = 12
SAFEGUARD_STARS = (15, 16, 17)

EVENTS = {
    "없음": set(),
    "30% 할인": {"discount30"},
    "21성 이하 파괴 30% 감소": {"destroy_down"},
    "5/10/15성 100%": {"guarantee"},
    "10성 이하 1+1": {"one_plus_one"},
    "흔적 복구 비용 20% 할인": {"restore20"},
    "샤이닝 스타포스": {"discount30", "destroy_down"},
    "샤이닝 스타포스 (+흔적 복구 20% 할인)": {"discount30", "destroy_down", "restore20"},
    "샤이닝 스타포스 (+5/10/15성 100%)": {"discount30", "destroy_down", "guarantee"},
}


def event_flags(event) -> set:
    """A preset name from EVENTS, or any iterable of flags (the dashboard combines effects freely).
    Flags and ranges checked against the API starforce_event_list of 2026-09-06 샤이닝 (85 records):
    discount30 = cost 30% on 0~29성, destroy_down = destroy x0.7 on 15~21성, restore20 = trace
    restore meso x0.8; one_plus_one = 10성 이하 성공 시 +2, guarantee = 5/10/15성 100%
    (10_조사/20260926_강화이벤트_조사.md)."""
    return EVENTS[event] if isinstance(event, str) else set(event)


# MVP discount on 1~17성 attempts (namu MVP 2026-09-10): 브론즈 none, 다이아 · 레드 · 블랙 10%
MVP = {"없음": 0.0, "브론즈": 0.0, "실버": 0.03, "골드": 0.05, "다이아": 0.10, "레드": 0.10, "블랙": 0.10}

# [spare equips needed, meso in 억] for restoring the trace at a given star
RESTORE = {
    130: {15: (1, 1.19), 16: (1, 2.87), 17: (1, 4.85), 18: (1, 11.03), 19: (2, 18.27)},
    135: {15: (1, 1.33), 16: (1, 3.21), 17: (1, 5.42), 18: (1, 12.31), 19: (2, 20.43)},
    140: {15: (1, 1.48), 16: (1, 3.58), 17: (1, 6.05), 18: (1, 13.74), 19: (2, 22.79),
          20: (2, 40.15), 21: (3, 50.45), 22: (4, 82.9)},
    145: {15: (1, 1.65), 16: (1, 3.98), 17: (1, 6.71), 18: (1, 15.28), 19: (2, 25.4),
          20: (2, 44.5), 21: (3, 56.05), 22: (4, 92.25)},
    150: {15: (1, 1.83), 16: (1, 4.41), 17: (1, 7.45), 18: (1, 16.89), 19: (2, 28.03),
          20: (2, 49.44), 21: (3, 62.24), 22: (4, 101.79)},
    160: {15: (1, 2.22), 16: (1, 5.35), 17: (1, 9.03), 18: (1, 20.5), 19: (2, 34.02),
          20: (2, 59.93), 21: (3, 75.31), 22: (4, 123.74)},
    200: {15: (1, 4.33), 16: (1, 10.44), 17: (1, 17.64), 18: (1, 40.05), 19: (2, 66.44),
          20: (2, 117.06), 21: (3, 147.09), 22: (4, 241.68)},
    250: {15: (1, 8.46), 16: (1, 20.39), 17: (1, 34.46), 18: (1, 78.21), 19: (2, 129.77),
          20: (2, 228.63), 21: (3, 287.28), 22: (4, 472.04)},
}


def max_star(level: int) -> int:
    # 공식 가이드 412 (2026-09-27 확인, 10_조사/20260927_총조사/data/kb/starforce_cost.yaml): 95~107 = 8, 108~117 = 10
    if level < 95:
        return 5
    if level <= 107:
        return 8
    if level <= 117:
        return 10
    if level <= 127:
        return 15
    if level <= 137:
        return 20
    return 30


def _round100(x: float) -> int:
    """Round half up to 100 meso. Python's round() goes to even on exact .5, which made 15 of the
    level 100~300 x 0~29 cells 100 meso low (e.g. 150제 2성 282,200 instead of 282,300; kb 2026-09-27)."""
    return int(math.floor(x / 100 + 0.5)) * 100


def base_cost(level: int, star: int) -> int:
    if star <= 9:
        return _round100(1000 + level ** 3 * (star + 1) / 36)
    b = level ** 3 * (star + 1) ** 2.7 / DIVISOR.get(star, 200)
    return 1000 + _round100(b)


@dataclass
class Setup:
    level: int
    start: int
    target: int
    event: str = "없음"
    mvp: str = "없음"
    pc_room: bool = False
    safeguard: set = field(default_factory=set)   # subset of SAFEGUARD_STARS
    restore: set = field(default_factory=set)     # stars where the trace is restored instead of 12성
    spare_cost: float = 0.0                       # meso per spare equip


def tables(s: Setup):
    """Per-star probability rows, attempt cost, destroy target star and destroy cost."""
    ev = event_flags(s.event)
    prob = PROB.copy()
    if "destroy_down" in ev:
        d = prob[:22, 2].copy()
        prob[:22, 2] = d * 0.7
        prob[:22, 1] += d * 0.3
    if "guarantee" in ev:
        prob[[5, 10, 15]] = [1, 0, 0]
    user_disc = MVP[s.mvp] + (0.05 if s.pc_room else 0)
    cost = np.zeros(30)
    for st in range(30):
        base = base_cost(s.level, st)
        c = base * (1 - user_disc) if st <= 16 else base
        if "discount30" in ev:
            c *= 0.7
        c = round(c)
        if st in s.safeguard and st in SAFEGUARD_STARS and prob[st, 0] < 1:
            prob[st, 1] += prob[st, 2]
            prob[st, 2] = 0
            c += base * 2
        cost[st] = c
    dest_star = np.full(30, DESTROY_RESET_STAR)
    dest_cost = np.full(30, s.spare_cost, dtype=float)
    res = RESTORE.get(s.level, {})
    for st in range(30):
        key = st if st <= 22 else (22 if 22 in s.restore else None)
        if key in s.restore and key in res:
            n, eok = res[key]
            meso = eok * 1e8 * (0.8 if "restore20" in ev else 1)
            dest_star[st] = key
            dest_cost[st] = n * s.spare_cost + meso
    return prob, cost, dest_star, dest_cost


def expected(s: Setup) -> dict:
    """Exact expectation by solving the linear system over stars start..target-1.
    E[i] = c_i + p E[next] + m E[i] + d (D_i + E[dest_i]), E[target+] = 0."""
    prob, cost, dest_star, dest_cost = tables(s)
    step = 2 if "one_plus_one" in event_flags(s.event) else 1
    lo = min(s.start, DESTROY_RESET_STAR)
    n = s.target - lo
    A = np.eye(n)
    bc, bd = np.zeros(n), np.zeros(n)
    for i in range(n):
        st = lo + i
        p, m, d = prob[st]
        A[i, i] -= m
        nxt = st + (step if (step == 2 and st <= 10) else 1)
        if nxt < s.target:
            A[i, nxt - lo] -= p
        if d > 0:
            A[i, dest_star[st] - lo] -= d
        bc[i] = cost[st] + d * dest_cost[st]
        bd[i] = d
    ec, ed = np.linalg.solve(A, bc), np.linalg.solve(A, bd)
    i0 = s.start - lo
    return {"cost": float(ec[i0]), "destroys": float(ed[i0])}


def simulate(s: Setup, n: int = 20000, seed: int = 0, max_steps: int = 2_000_000) -> dict:
    prob, cost, dest_star, dest_cost = tables(s)
    step2 = "one_plus_one" in event_flags(s.event)
    rng = np.random.default_rng(seed)
    star = np.full(n, s.start)
    spent = np.zeros(n)
    destroys = np.zeros(n, dtype=int)
    active = np.arange(n)
    for _ in range(max_steps):
        if active.size == 0:
            break
        st = star[active]
        spent[active] += cost[st]
        r = rng.random(active.size)
        p, d = prob[st, 0], prob[st, 2]
        succ = r < p
        dest = r >= 1 - d
        inc = np.where(step2 & (st <= 10), 2, 1)
        star[active[succ]] += inc[succ]
        da = active[dest]
        spent[da] += dest_cost[star[da]]
        destroys[da] += 1
        star[da] = dest_star[star[da]]
        active = active[star[active] < s.target]
    assert active.size == 0, "simulation did not finish"
    q = lambda a, x: float(np.quantile(a, x))
    return {"cost_mean": float(spent.mean()), "destroys_mean": float(destroys.mean()),
            "cost_q": {k: q(spent, k) for k in (0.1, 0.5, 0.9, 0.99)},
            "no_destroy_prob": float((destroys == 0).mean()), "costs": spent, "destroys": destroys}


def selftest() -> None:
    assert base_cost(200, 17) == 1000 + round(200 ** 3 * 18 ** 2.7 / 150 / 100) * 100
    assert base_cost(150, 2) == 282_300, base_cost(150, 2)  # half-up rounding
    assert [max_star(x) for x in (94, 95, 107, 108, 117, 118, 128, 138, 200)] == [5, 8, 8, 10, 10, 15, 20, 30, 30]
    cases = [Setup(200, 12, 17), Setup(200, 15, 22), Setup(250, 17, 22, event="샤이닝 스타포스"),
             Setup(160, 0, 18, mvp="골드", pc_room=True, safeguard={15, 16, 17}),
             Setup(200, 17, 22, restore={17, 18, 19, 20, 21}, spare_cost=5e8)]
    for c in cases:
        e = expected(c)
        m = simulate(c, n=40000, seed=1)
        rel = abs(m["cost_mean"] - e["cost"]) / e["cost"]
        print(f"{c.level}제 {c.start}->{c.target} {c.event}: 기대 {e['cost']/1e8:,.2f}억 "
              f"(시뮬 {m['cost_mean']/1e8:,.2f}억, 차 {rel:.1%}) 파괴 {e['destroys']:.3f} "
              f"(시뮬 {m['destroys_mean']:.3f}) 중앙값 {m['cost_q'][0.5]/1e8:,.2f}억")
        assert rel < 0.05, "exact and simulation disagree"


if __name__ == "__main__":
    selftest()
