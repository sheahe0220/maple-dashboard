"""MVP (메이플 VIP) window: rolling payment total, what is left to each grade, and how long each grade lasts.

Why: 2026-09-30 user: "MVP 창을 따로 만들어 봐. 블랙 · 레드까지 등급별로 얼마 남았는지, 올라가면 몇 주 유지되는지".
No API serves payments, so the user types payments (date, 넥슨캐시 amount, memo) and they are saved to
data/mvp_log.yaml (git-synced between the owner's PCs). Rules (grades, period, week start, benefits) come from
ref/mvp_20260930.yaml (official sources, 10_조사/20260930_MVP/MVP규칙.md); the fallbacks below are only used when that
file is missing.

Model: the MVP total at week W = sum of payments in the `period_weeks` weeks ending with W (the current week included).
Without new payments, old weeks fall out one per week, so a grade lasts while that rolling sum stays >= its threshold.

Self-test:
    <story>\\.venv\\Scripts\\python.exe -X utf8 <story>\\mvp.py
"""
from datetime import date, datetime, timedelta
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent
LOG = ROOT / "data" / "mvp_log.yaml"
RULES = ROOT / "ref" / "mvp_20260930.yaml"
FALLBACK = {"grades": [{"name": "브론즈", "threshold": 150_000}, {"name": "실버", "threshold": 300_000},
                       {"name": "골드", "threshold": 600_000}, {"name": "다이아", "threshold": 900_000},
                       {"name": "레드", "threshold": 1_500_000}, {"name": "블랙", "threshold": 2_500_000}],
            "period_weeks": 13, "week_start_weekday": 3}  # Thursday [추정 until ref/mvp_20260930.yaml exists]


def rules() -> dict:
    r = yaml.safe_load(RULES.read_text(encoding="utf-8")) if RULES.exists() else {}
    out = dict(FALLBACK)
    for k in ("grades", "period_weeks", "benefits", "sources", "counting", "carryover", "retention_rule",
              "recalc_rule", "week_start", "changes"):
        if r and r.get(k) is not None:
            out[k] = r[k]
    days = {"월요일": 0, "화요일": 1, "수요일": 2, "목요일": 3, "금요일": 4, "토요일": 5, "일요일": 6}
    ws = (r or {}).get("week_start") or {}
    if isinstance(ws, dict) and ws.get("weekday") in days:
        out["week_start_weekday"] = days[ws["weekday"]]
    out["carry_max"] = int(((r or {}).get("carryover") or {}).get("max") or 10_000_000)
    out["from_file"] = bool(r)
    return out


def load_log() -> list[dict]:
    rows = yaml.safe_load(LOG.read_text(encoding="utf-8")) if LOG.exists() else []
    return [r for r in (rows or []) if r.get("date") and r.get("amount")]


def save_log(rows: list[dict]) -> None:
    clean = [{"date": str(r["date"])[:10], "amount": int(r["amount"]), "memo": str(r.get("memo") or "")}
             for r in rows if r.get("date") and r.get("amount")]
    clean.sort(key=lambda r: r["date"])
    LOG.parent.mkdir(exist_ok=True)
    LOG.write_text(yaml.safe_dump(clean, allow_unicode=True, sort_keys=False), encoding="utf-8")


def week_of(d: date, start_weekday: int) -> date:
    return d - timedelta(days=(d.weekday() - start_weekday) % 7)


def _d(x) -> date:
    return x if isinstance(x, date) and not isinstance(x, datetime) else date.fromisoformat(str(x)[:10])


def weekly(rows: list[dict], start_weekday: int) -> dict:
    out: dict[date, int] = {}
    for r in rows:
        w = week_of(_d(r["date"]), start_weekday)
        out[w] = out.get(w, 0) + int(r["amount"])
    return out


def total_at(wk: dict, week: date, period: int) -> int:
    return sum(v for w, v in wk.items() if week - timedelta(weeks=period - 1) <= w <= week)


def grade_of(total: float, grades: list[dict]) -> str | None:
    best = None
    for g in sorted(grades, key=lambda g: g["threshold"]):
        if total >= g["threshold"]:
            best = g["name"]
    return best


def status(rows: list[dict], today: date, r: dict | None = None, carry: int = 0) -> dict:
    """Current total / grade, per-grade remaining, and per-grade last week it holds without new payments.
    carry = 블랙 이월 금액 (user-typed): it only props up 블랙 here, because whether it also keeps lower grades is
    [판정보류] in the official text (ref/mvp_20260930.yaml carryover.unclear)."""
    r = r or rules()
    sw, period, grades = r["week_start_weekday"], int(r["period_weeks"]), r["grades"]
    wk = weekly(rows, sw)
    this_week = week_of(today, sw)
    total = total_at(wk, this_week, period)
    future = [(this_week + timedelta(weeks=i), total_at(wk, this_week + timedelta(weeks=i), period))
              for i in range(period + 1)]
    per = []
    top = max(grades, key=lambda g: g["threshold"])["name"]
    for g in sorted(grades, key=lambda g: g["threshold"]):
        th = g["threshold"]
        extra = carry if g["name"] == top else 0
        hold = [w for w, t in future if t + extra >= th]
        # consecutive weeks from now that stay at or above the threshold
        last = None
        for w, t in future:
            if t + extra >= th:
                last = w
            else:
                break
        per.append({"grade": g["name"], "threshold": th, "left": max(0, th - total - extra),
                    "reached": total + extra >= th, "uses_carry": bool(extra),
                    "holds_until_week": last, "weeks_kept": 0 if last is None else (last - this_week).days // 7 + 1,
                    "any_future": bool(hold)})
    # when each past payment stops counting
    expiry = [{"date": _d(x["date"]), "amount": int(x["amount"]), "memo": x.get("memo", ""),
               "counts_until_week": week_of(_d(x["date"]), sw) + timedelta(weeks=period - 1)} for x in rows]
    return {"this_week": this_week, "total": total, "grade": grade_of(total, grades), "per_grade": per,
            "future": future, "expiry": expiry, "period": period, "week_start_weekday": sw}


GAME = ROOT / "data" / "mvp_game.yaml"


def load_game() -> dict:
    """Values copied from the in-game MVP window (2026-09-30 user screenshot: 이번 주 등급 · 블랙 등급까지 ·
    다음 주 예상 등급 · 유지까지). The API has no MVP endpoint (01_API_전수 / api_spec: 0 hits)."""
    g = yaml.safe_load(GAME.read_text(encoding="utf-8")) if GAME.exists() else None
    return g or {}


def save_game(g: dict) -> None:
    GAME.parent.mkdir(exist_ok=True)
    GAME.write_text(yaml.safe_dump(g, allow_unicode=True, sort_keys=False), encoding="utf-8")


def from_game(g: dict, r: dict | None = None) -> dict | None:
    """13-week total from the window's '블랙 등급까지 N' (total = 블랙 기준 - N) and what is left to each grade.
    Black members see no '블랙까지', so their total is given as at least the black threshold."""
    if not g or not g.get("grade"):
        return None
    r = r or rules()
    grades = sorted(r["grades"], key=lambda x: x["threshold"])
    black = grades[-1]["threshold"]
    total = black if g["grade"] == grades[-1]["name"] else black - int(g.get("to_black") or 0)
    per = [{"grade": x["name"], "threshold": x["threshold"], "left": max(0, x["threshold"] - total),
            "reached": total >= x["threshold"]} for x in grades]
    return {"total": total, "grade": g["grade"], "per_grade": per, "next_grade": g.get("next_grade"),
            "keep_left": int(g.get("keep_left") or 0), "date": g.get("date")}


def hold_plan(g: dict, r: dict | None = None, target: str | None = None) -> list[dict] | None:
    """From the in-game '주차별 예상' table (N주 뒤: 현재 등급 유지까지 K 캐시), how much to spend THIS week to keep
    `target` (default the top grade) through each future week, and how long it lasts if only the gap is spent now.

    2026-09-30 user: "블랙까지 296,614 인데 블랙을 가면 다음 주에 얼마나 유지되는지". Logic (no payment log needed):
      T0 = 13-week total now = 블랙 기준 - '블랙까지'.  T_k = total left k weeks later without new spending.
      The window's keep_k for the CURRENT grade (threshold th_c): keep_k > 0 -> T_k = th_c - keep_k (exact);
      keep_k = 0 -> only th_c <= T_k <= T_(k-1) is known.
      Spending S this week adds S to T_0 .. T_12 (a week's spending counts 13 weeks), so keeping `target` (threshold
      th_t) through week k needs S >= th_t - min(T_0..T_k) = th_t - T_k (T never rises without spending).
    Rows: week k, predicted grade (as typed), T_k range, spend-now range, exact flag."""
    base = from_game(g, r)
    weeks = (g or {}).get("weeks") or []
    if not base or not weeks:
        return None
    r = r or rules()
    grades = sorted(r["grades"], key=lambda x: x["threshold"])
    th = {x["name"]: x["threshold"] for x in grades}
    th_c = th.get(base["grade"])
    th_t = th[target or grades[-1]["name"]]
    t0 = base["total"]
    lo_prev, hi_prev = t0, t0
    rows = [{"week": 0, "grade": base["grade"], "t_lo": t0, "t_hi": t0, "exact": True,
             "spend_lo": max(0, th_t - t0), "spend_hi": max(0, th_t - t0)}]
    for w in sorted(weeks, key=lambda x: int(x["k"])):
        keep = int(w.get("keep") or 0)
        if keep > 0:
            lo = hi = th_c - keep
        else:
            lo, hi = min(th_c, hi_prev), hi_prev
        lo, hi = min(lo, hi_prev), min(hi, hi_prev)
        rows.append({"week": int(w["k"]), "grade": w.get("grade") or "", "t_lo": lo, "t_hi": hi, "exact": lo == hi,
                     "spend_lo": max(0, th_t - hi), "spend_hi": max(0, th_t - lo)})
        lo_prev, hi_prev = lo, hi
    return rows


def selftest() -> None:
    r = dict(FALLBACK)
    today = date(2026, 9, 30)  # Wednesday; week (Thursday start) = 2026-09-24
    rows = [{"date": "2026-07-02", "amount": 500_000}, {"date": "2026-09-25", "amount": 1_100_000}]
    s = status(rows, today, r)
    assert s["this_week"] == date(2026, 9, 24), s["this_week"]
    assert s["total"] == 1_600_000 and s["grade"] == "레드", (s["total"], s["grade"])
    red = [p for p in s["per_grade"] if p["grade"] == "레드"][0]
    black = [p for p in s["per_grade"] if p["grade"] == "블랙"][0]
    assert black["left"] == 900_000 and not black["reached"]
    # the 2026-07-02 payment (week 07-02) counts through week 07-02 + 12 weeks = 09-24; from 10-01 the total is 1.1M
    assert red["weeks_kept"] == 1 and red["holds_until_week"] == date(2026, 9, 24), red
    dia = [p for p in s["per_grade"] if p["grade"] == "다이아"][0]
    assert dia["holds_until_week"] == date(2026, 12, 17), dia   # 09-25 payment counts 13 weeks: 09-24 .. 12-17
    print(f"total {s['total']:,} {s['grade']}, 레드 {red['weeks_kept']}주, 다이아 until {dia['holds_until_week']}")
    fg = from_game({"grade": "레드", "to_black": 296_614, "next_grade": "레드", "keep_left": 0}, r)
    assert fg["total"] == 2_203_386 and [p["left"] for p in fg["per_grade"]][-1] == 296_614, fg
    print(f"game window: total {fg['total']:,}, 블랙까지 {fg['per_grade'][-1]['left']:,}")
    print("rules from file:", rules()["from_file"])
    print("selftest ok")


if __name__ == "__main__":
    selftest()
