"""Per-character stat efficiency: how much each stat raises boss damage, and its worth in 보공 %.

Why: 2026-09-27 user asked for 효율 계산 per character on the coming 직업 정보 tab. Model (10_조사/20260927_총조사/
08_환산_전투력.md, the multiplicative form maplescouter uses, matched to 6 decimals there):
    damage ∝ (4 x 주스탯 + 부스탯) x 공마 x (1 + 데미지% + 보공%) x (1.35 + 크뎀%) x (1 + 최종뎀) x (1 - 방어율 x (1 - 방무))
Marginal gains (relative, per unit) at the character's current stats:
    보공 · 데미지 +1%p   1 / (100 + 데미지 + 보공)
    크뎀 +1%p            1 / (135 + 크뎀)
    최종뎀 +1% (곱)       1%
    방무 +1% (곱: 남은 방어의 1% 무시)  0.01 x D x (1 - I) / (1 - D x (1 - I)),  D = 3.0 or 3.8
    공마 +1 (최종 수치)    1 / 공마
    주스탯 +1 (최종 수치)  4 / (4 x 주스탯 + 부스탯)
selftest reproduces maplescouter's own efficiency ratios from the inputs in its response (A_verify_scouter_out.txt).
Limits: API final_stat includes the buffs active when the game saved it, so values differ from a no-buff stat window;
공마 · 주스탯 here are final values (after %), unlike maplescouter's base "공마 1". Special jobs (제논 3 stats,
데몬어벤져 HP) need their own main-stat rule [판정보류].

Self-test:
    <story>\\.venv\\Scripts\\python.exe -X utf8 <story>\\efficiency.py
"""
import json

BOSS_DEF = {"300%": 3.0, "380%": 3.8}
# main / sub stat per class. Filled from ref/jobs when available; this fallback covers the owner's classes.
FALLBACK_STATS = {"키네시스": ("INT", "LUK"), "레테": ("STR", "DEX"), "에반": ("INT", "LUK")}


def final_stats(stat_json: dict) -> dict:
    """API character/stat JSON -> {name: float} of final_stat."""
    out = {}
    for r in stat_json.get("final_stat") or []:
        try:
            out[r["stat_name"]] = float(str(r["stat_value"]).replace(",", ""))
        except (TypeError, ValueError):
            pass
    return out


def gains(fs: dict, main: str, sub: str, magic: bool) -> dict:
    """Relative damage gain (fraction) per unit of each stat at these final stats."""
    m, s = fs.get(main, 0.0), fs.get(sub, 0.0)
    atk = fs.get("마력" if magic else "공격력", 0.0)
    dmg_boss = fs.get("데미지", 0.0) + fs.get("보스 몬스터 데미지", 0.0)
    cd = fs.get("크리티컬 데미지", 0.0)
    ied = fs.get("방어율 무시", 0.0) / 100
    out = {"보공 1%": 1 / (100 + dmg_boss), "크뎀 1%": 1 / (135 + cd), "최종뎀 1%": 0.01}
    for label, d in BOSS_DEF.items():
        rem = d * (1 - ied)
        out[f"방무 1% ({label})"] = 0.01 * rem / (1 - rem) if rem < 1 else float("nan")
    out[f"{'마력' if magic else '공격력'} 1"] = 1 / atk if atk else float("nan")
    out[f"{main} 1"] = 4 / (4 * m + s) if m else float("nan")
    out[f"{sub} 1"] = 1 / (4 * m + s) if m else float("nan")
    return out


def table(fs: dict, main: str, sub: str, magic: bool) -> list[dict]:
    """Rows: stat, 딜 증가(%), 보공 % 환산, 딜 1% 에 필요한 양."""
    g = gains(fs, main, sub, magic)
    base = g["보공 1%"]
    rows = []
    for k, v in g.items():
        rows.append({"항목": k, "딜 증가(%)": v * 100, "보공 % 환산": v / base if base else float("nan"),
                     "딜 1% 에 필요": 0.01 / v if v else float("nan")})
    return rows


def selftest() -> None:
    # maplescouter response for the main character (A_verify_scouter_out.txt): 100+atk% 287.23, base atk 4,729.5,
    # 100+dmg+boss 970.65, crit term 314.50, IED 97.519 %, and its efficiencies dmgeff1 0.00103024,
    # cridmgeff1 0.00317965, igreff1 (300) 0.000804183, atkeff1 0.00021144
    dmg_boss, crit, ied = 870.65, 179.50, 0.97519
    fs = {"데미지": 0.0, "보스 몬스터 데미지": dmg_boss, "크리티컬 데미지": crit, "방어율 무시": ied * 100,
          "INT": 10000.0, "LUK": 1000.0, "마력": 4729.5}
    g = gains(fs, "INT", "LUK", True)
    site = {"보공 1%": 0.00103024, "크뎀 1%": 0.00317965, "방무 1% (300%)": 0.000804183, "마력 1": 0.00021144}
    for k, v in site.items():
        rel = abs(g[k] - v) / v
        print(f"  {k}: model {g[k]:.8f} / site {v:.8f} (차 {rel:.3%})")
        assert rel < 0.002, (k, g[k], v)
    # real record: the latest stat snapshot of the config's main character (name read from config, not written here)
    import db
    import yaml
    from pathlib import Path
    main = (yaml.safe_load((Path(__file__).parent / "config.yaml").read_text(encoding="utf-8")) or {}).get("main_character")
    con = db.connect()
    row = con.execute("SELECT s.date, s.json, c.class FROM snapshot s JOIN characters c USING (ocid) WHERE c.name=? AND "
                      "s.endpoint='stat' AND s.json NOT LIKE '%_error%' AND s.json LIKE '%final_stat%' "
                      "ORDER BY s.date DESC LIMIT 1", (main,)).fetchone() if main else None
    con.close()
    if not row:
        print("main character stat snapshot not found; model check above passed")
        print("selftest ok")
        return
    fs = final_stats(json.loads(row[1]))
    m, sub = FALLBACK_STATS.get(row[2], ("INT", "LUK"))
    assert fs.get(m), fs
    print(f"본캐 {row[0]} (보공 {fs['보스 몬스터 데미지']:.0f}%, 크뎀 {fs['크리티컬 데미지']:.0f}%, 방무 {fs['방어율 무시']:.2f}%)")
    for r in table(fs, m, sub, m == "INT"):
        print(f"  {r['항목']:<14} 딜 +{r['딜 증가(%)']:.4f}%  = 보공 {r['보공 % 환산']:.3f}%  (딜 1% 에 {r['딜 1% 에 필요']:,.2f})")
    print("selftest ok")


if __name__ == "__main__":
    selftest()
