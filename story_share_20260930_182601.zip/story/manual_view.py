"""사용설명서 tab: renders manual/manual.yaml (one guide per feature, numbered steps with annotated screenshots).

Why: 2026-09-27 user asked for a visual, step-by-step manual for every feature, each separate ("이거 먼저 하고
그다음 이쪽"), with pictures and example values. The images and texts are produced by manual/make_images.py
from the live dashboard; this module only draws them with native Streamlit elements (light and dark mode).
"""
from pathlib import Path

import streamlit as st
import yaml

ROOT = Path(__file__).resolve().parent / "manual"
YAML = ROOT / "manual.yaml"


def load() -> list[dict]:
    if not YAML.exists():
        return []
    data = yaml.safe_load(YAML.read_text(encoding="utf-8")) or {}
    feats = data.get("features") if isinstance(data, dict) else data
    return feats or []


def _icon(name: str | None) -> str:
    from streamlit.material_icon_names import ALL_MATERIAL_ICONS
    return f":material/{name}:" if name and name in ALL_MATERIAL_ICONS else ":material/help:"


def render(feats: list[dict]) -> None:
    if not feats:
        st.info("사용설명서를 만드는 중입니다. 잠시 뒤 새로고침해 주세요.", icon=":material/hourglass_top:")
        return
    st.caption(f"기능 {len(feats)}개 · 기능마다 따로 봅니다. 번호 순서대로 따라 하면 됩니다.")
    pick = st.pills("기능", [f["id"] for f in feats], default=feats[0]["id"], key="manual_pick",
                    format_func=lambda i: next((f["title"] for f in feats if f["id"] == i), str(i))) or feats[0]["id"]
    f = next(x for x in feats if x["id"] == pick)
    with st.container(border=True):
        st.markdown(f"### {_icon(f.get('icon'))} {f.get('title', '')}")
        if f.get("where"):
            st.markdown(f":gray-badge[위치] {f['where']}")
        if f.get("summary"):
            st.markdown(f.get("summary"))
        if f.get("when"):
            st.caption(f"언제 쓰나: {f['when']}")
    for s in f.get("steps") or []:
        with st.container(border=True):
            st.markdown(f"#### :orange-badge[{s.get('n', '')}] {s.get('title', '')}")
            img = s.get("image")
            if img and (ROOT / img).exists():
                st.image(str(ROOT / img), width="content")  # native size: no blurry upscaling (UI 점검)
            if s.get("text"):
                st.markdown(s["text"])
            if s.get("example"):
                st.caption(f"예시 값: {s['example']}")
    if f.get("result"):
        st.success(f["result"], icon=":material/check_circle:")
    tips, cautions = f.get("tips") or [], f.get("caution") or []
    if tips or cautions:
        a, b = st.columns(2)
        if tips:
            a.markdown("**팁**  \n" + "  \n".join(f"- {t}" for t in tips))
        if cautions:
            b.markdown("**주의**  \n" + "  \n".join(f"- {t}" for t in cautions))
