"""SQLite storage. Raw JSON is kept so the dashboard can derive new views later
without refetching (the API quota is the scarce resource, not disk)."""
import json
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent / "data" / "maple.db"
KST = timezone(timedelta(hours=9))

SCHEMA = """
CREATE TABLE IF NOT EXISTS characters (
    ocid TEXT PRIMARY KEY, name TEXT, world TEXT, class TEXT, level INTEGER, updated_at TEXT);
CREATE TABLE IF NOT EXISTS snapshot (
    ocid TEXT, date TEXT, endpoint TEXT, json TEXT, fetched_at TEXT,
    PRIMARY KEY (ocid, date, endpoint));
CREATE TABLE IF NOT EXISTS history (
    kind TEXT, id TEXT, date_create TEXT, character_name TEXT, json TEXT,
    PRIMARY KEY (kind, id));
CREATE TABLE IF NOT EXISTS history_done (kind TEXT, date TEXT, n INTEGER, PRIMARY KEY (kind, date));
CREATE TABLE IF NOT EXISTS call_log (date TEXT PRIMARY KEY, n INTEGER);
"""


def now_kst() -> datetime:
    return datetime.now(KST)


def connect(path: Path = DB_PATH) -> sqlite3.Connection:
    path.parent.mkdir(exist_ok=True)
    con = sqlite3.connect(path)
    con.executescript(SCHEMA)
    return con


def calls_today(con) -> int:
    row = con.execute("SELECT n FROM call_log WHERE date=?", (now_kst().strftime("%Y-%m-%d"),)).fetchone()
    return row[0] if row else 0


def add_call(con) -> None:
    con.execute("INSERT INTO call_log VALUES (?,1) ON CONFLICT(date) DO UPDATE SET n=n+1",
                (now_kst().strftime("%Y-%m-%d"),))
    con.commit()


def upsert_character(con, c: dict) -> None:
    con.execute("INSERT OR REPLACE INTO characters VALUES (?,?,?,?,?,?)",
                (c["ocid"], c["character_name"], c["world_name"], c["character_class"],
                 int(c["character_level"]), now_kst().isoformat(timespec="seconds")))


def has_snapshot(con, ocid, date, endpoint) -> bool:
    return con.execute("SELECT 1 FROM snapshot WHERE ocid=? AND date=? AND endpoint=?",
                       (ocid, date, endpoint)).fetchone() is not None


def put_snapshot(con, ocid, date, endpoint, data: dict) -> None:
    con.execute("INSERT OR REPLACE INTO snapshot VALUES (?,?,?,?,?)",
                (ocid, date, endpoint, json.dumps(data, ensure_ascii=False),
                 now_kst().isoformat(timespec="seconds")))
    con.commit()


def history_done(con, kind, date) -> bool:
    return con.execute("SELECT 1 FROM history_done WHERE kind=? AND date=?", (kind, date)).fetchone() is not None


def put_history(con, kind, date, rows: list[dict], done: bool = True) -> None:
    """done=False stores the rows without marking the day finished (today is still growing)."""
    con.executemany("INSERT OR IGNORE INTO history VALUES (?,?,?,?,?)",
                    [(kind, r["id"], r.get("date_create"), r.get("character_name"),
                      json.dumps(r, ensure_ascii=False)) for r in rows])
    if done:
        con.execute("INSERT OR REPLACE INTO history_done VALUES (?,?,?)", (kind, date, len(rows)))
    con.commit()
