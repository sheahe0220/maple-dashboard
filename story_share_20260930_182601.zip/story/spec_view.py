"""Spec screen sections beyond equipment: stats, hexa / V matrix, symbols, ability, hyper stat, union,
link skills, set effects (2026-09-27 user: "스펙 수단이 유니온도 있고 헥사강화도 있고 어빌도 있고 하이퍼도 있고 ...
그런 것까지 다 넣어 달라, 아이콘 쓸 수 있는 건 다 쓰고, 가독성 좋게").

Data: live snapshots (collector spec_endpoints, refreshed by the 지금 갱신 button). Every render function takes the
parsed JSON of one endpoint and draws with native Streamlit elements, so light and dark mode follow the theme.
"""
import json
import math
import re
from pathlib import Path

import pandas as pd
import streamlit as st

import db

GRADE_COLOR = {"레전드리": "green", "유니크": "orange", "에픽": "violet", "레어": "blue"}
KEY_STATS = [("전투력", "swords"), ("최종 데미지", "bolt"), ("보스 몬스터 데미지", "skull"), ("방어율 무시", "shield"),
             ("데미지", "whatshot"), ("크리티컬 데미지", "target"), ("재사용 대기시간 감소 (%)", "timer"),
             ("버프 지속시간", "hourglass_top"), ("아케인포스", "auto_awesome"), ("어센틱포스", "diamond")]


def load(name: str) -> dict:
    """Latest snapshot per endpoint for one character."""
    con = db.connect()
    rows = con.execute("SELECT s.endpoint, s.date, s.json FROM snapshot s JOIN characters c USING (ocid) "
                       "WHERE c.name=? ORDER BY s.date", (name,)).fetchall()
    con.close()
    out = {}
    for ep, d, js in rows:
        data = json.loads(js)
        if "_error" not in data:
            out[ep] = data
            out[f"_{ep}_date"] = d
    return out


def _stat(stat: dict, name: str) -> str | None:
    for s in (stat or {}).get("final_stat") or []:
        if s.get("stat_name") == name:
            return s.get("stat_value")
    return None


def _num(v) -> float | None:
    try:
        return float(str(v).replace(",", ""))
    except (TypeError, ValueError):
        return None


def eok_man(n: float) -> str:
    """388,831,903 -> '3억 8,883만' (UI 점검: 큰 수를 원 단위로 쓰지 않기)."""
    n = int(round(n))
    eok, man = divmod(n, 100_000_000)
    man //= 10_000
    return (f"{eok:,}억 " if eok else "") + (f"{man:,}만" if man or not eok else "")


def _pretty(v) -> str:
    """API stat text -> readable: numbers get separators, big ones 억 · 만, text stays."""
    n = _num(v)
    if n is None:
        return str(v)
    if abs(n) >= 100_000_000:
        return eok_man(n)
    return f"{n:,.0f}" if float(n).is_integer() else f"{n:,.2f}"


def stats_section(stat: dict, main: str, row_factory):
    """Key stats as cards, the full list in an expander."""
    row = row_factory()
    for name, icon in [(f"{main}", "person"), ("마력" if main == "INT" else "공격력", "flare")] + KEY_STATS:
        v = _stat(stat, name)
        if v is None:
            continue
        n = _num(v)
        pct = "%" if any(k in name for k in ("데미지", "무시", "감소 (%)", "지속시간")) else ""
        text = eok_man(n) if name == "전투력" and n else (f"{n:,.0f}" if n is not None and not pct else f"{v}{pct}")
        row.metric(name, text, icon=f":material/{icon}:",
                   help="이 스탯을 저장한 시점의 값(장비 프리셋 · 버프에 따라 달라짐)" if name == "전투력" else None)
    with st.expander("전체 스탯", icon=":material/list:"):
        df = pd.DataFrame(stat.get("final_stat") or [])
        if len(df):
            df["stat_value"] = df["stat_value"].map(_pretty)
            st.dataframe(df.rename(columns={"stat_name": "스탯", "stat_value": "값"}), hide_index=True, width="stretch",
                         height=min(600, 40 + 35 * len(df)))


HEXA_COST = Path(__file__).resolve().parent / "ref" / "hexa_core_cost_20260927.csv"
SYMBOLS = Path(__file__).resolve().parent / "ref" / "symbols_20260927.csv"
SYMBOL_DAILY = Path(__file__).resolve().parent / "ref" / "symbol_daily_20260927.csv"


def _hexa_kind(api_type: str, name: str, skill_order: int) -> str:
    """API hexa_core_type has only 4 values; skill cores are origin / ascent / 3rd by their order in the list
    [추정: API lists them in that order], common cores split by name (솔 야누스 · 솔 헤카테 vs 직업군)."""
    if api_type == "스킬 코어":
        return ["스킬 코어(오리진)", "스킬 코어(어센트)", "스킬 코어(3rd)"][min(skill_order, 2)]
    if api_type == "공용 코어":
        return "공용 코어(솔 야누스 · 솔 헤카테)" if ("야누스" in name or "헤카테" in name) else "공용 코어(직업군 공용)"
    return api_type


def hexa_section(hexa: dict, hexa_stat: dict, skill6: dict, vmatrix: dict, skill5: dict,
                 fragment_meso: float = 0.0, row_factory=None):
    icons6 = {s["skill_name"]: s.get("skill_icon") for s in (skill6 or {}).get("character_skill") or []}
    icons5 = {s["skill_name"]: s.get("skill_icon") for s in (skill5 or {}).get("character_skill") or []}
    cores = (hexa or {}).get("character_hexa_core_equipment") or []
    cost = pd.read_csv(HEXA_COST, encoding="utf-8-sig") if HEXA_COST.exists() else pd.DataFrame()
    st.markdown("**헥사 코어**")
    if not cores:
        st.caption("헥사 코어 정보가 없습니다.")
    rows, skill_i = [], 0
    for c in cores:
        linked = [x.get("hexa_skill_id") for x in c.get("linked_skill") or []]
        icon = next((icons6.get(l) for l in linked if icons6.get(l)), None)
        if not icon:  # mastery cores are named differently from their VI skills
            icon = next((u for n, u in icons6.items() if c["hexa_core_name"] in n), None)
        lv = int(c.get("hexa_core_level") or 0)
        kind = _hexa_kind(c.get("hexa_core_type"), c["hexa_core_name"], skill_i)
        skill_i += c.get("hexa_core_type") == "스킬 코어"
        left = cost[(cost["core_type"] == kind) & (cost["from_level"] >= lv)] if len(cost) else cost
        rows.append({"그림": icon, "코어": c["hexa_core_name"], "종류": kind, "레벨": lv,
                     "30까지 솔 에르다": int(left["sol_erda"].sum()) if len(left) else None,
                     "30까지 조각": int(left["fragments"].sum()) if len(left) else None})
    if rows:
        df = pd.DataFrame(rows)
        if row_factory and df["30까지 조각"].notna().any():
            frag, erda = int(df["30까지 조각"].sum()), int(df["30까지 솔 에르다"].sum())
            r = row_factory()
            r.metric("풀강까지 조각", f"{frag:,}개", icon=":material/token:",
                     help="모든 코어를 30레벨로 올릴 때 남은 솔 에르다 조각 (나무위키 · 해외 위키 180칸 일치)")
            r.metric("풀강까지 솔 에르다", f"{erda:,}개", icon=":material/auto_awesome:",
                     help="기운 1,000 = 솔 에르다 1개")
            r.metric("조각 메소 가치", f"{frag * fragment_meso / 1e8:,.0f}억" if fragment_meso else "시세 미입력",
                     icon=":material/savings:", help="메소 가치 탭 세부 설정의 '솔 에르다 조각 시세' 기준")
        st.dataframe(df, hide_index=True, width="stretch", row_height=38, height="content",
                     column_config={"그림": st.column_config.ImageColumn(" ", width="small"),
                                    "레벨": st.column_config.ProgressColumn(min_value=0, max_value=30, format="%d / 30"),
                                    "30까지 조각": st.column_config.NumberColumn(format="%,d"),
                                    "30까지 솔 에르다": st.column_config.NumberColumn(format="%,d")})
        st.caption("스킬 코어의 오리진 · 어센트 · 3rd 구분은 목록 순서로 정합니다 [추정]. 비용표: ref/hexa_core_cost_20260927.csv")
    stat_cores = (hexa_stat or {}).get("character_hexa_stat_core") or []
    for k in ("character_hexa_stat_core_2", "character_hexa_stat_core_3"):
        stat_cores += (hexa_stat or {}).get(k) or []
    if stat_cores:
        st.markdown("**헥사 스탯**")
        st.dataframe(pd.DataFrame([{"메인": f"{s['main_stat_name']} Lv.{s['main_stat_level']}",
                                    "서브 1": f"{s['sub_stat_name_1']} Lv.{s['sub_stat_level_1']}",
                                    "서브 2": f"{s['sub_stat_name_2']} Lv.{s['sub_stat_level_2']}",
                                    "등급": s.get("stat_grade")} for s in stat_cores]), hide_index=True, width="stretch")
    vcores = (vmatrix or {}).get("character_v_core_equipment") or []
    if vcores:
        st.markdown("**V 매트릭스**")
        import icons_extra
        job = (skill5 or {}).get("character_class", "")
        vic = lambda n: (icons5.get(n) or icons_extra.extra_icon("skill_v", f"{job}_{n.replace(':', '_')}")
                         or icons5.get(n.removesuffix(" 강화")))
        st.dataframe(pd.DataFrame([{"그림": vic(v["v_core_name"]), "코어": v["v_core_name"],
                                    "종류": v.get("v_core_type"), "레벨": int(v.get("v_core_level") or 0)}
                                   for v in vcores if v.get("v_core_name")]),
                     hide_index=True, width="stretch", row_height=36, height=min(520, 40 + 37 * len(vcores)),
                     column_config={"그림": st.column_config.ImageColumn(" ", width="small"),
                                    "레벨": st.column_config.ProgressColumn(min_value=0, max_value=30, format="%d")})


def symbol_section(sym: dict, row_factory):
    symbols = (sym or {}).get("symbol") or []
    if not symbols:
        st.caption("심볼 정보가 없습니다.")
        return
    arc = [s for s in symbols if "아케인" in s["symbol_name"]]
    aut = [s for s in symbols if "어센틱" in s["symbol_name"] or "그랜드" in s["symbol_name"]]
    row = row_factory()
    row.metric("아케인 심볼 합계", f"{sum(int(s['symbol_force']) for s in arc):,}", icon=":material/auto_awesome:",
               help="스탯창의 아케인포스에는 심볼 외 다른 효과도 더해집니다")
    row.metric("어센틱 심볼 합계", f"{sum(int(s['symbol_force']) for s in aut):,}", icon=":material/diamond:")
    tab = pd.read_csv(SYMBOLS, encoding="utf-8-sig") if SYMBOLS.exists() else pd.DataFrame()
    daily = pd.read_csv(SYMBOL_DAILY, encoding="utf-8-sig") if SYMBOL_DAILY.exists() else pd.DataFrame()
    rows = []
    for s in symbols:
        region = s["symbol_name"].split(" : ")[-1]
        lv, top = int(s["symbol_level"]), (20 if "아케인" in s["symbol_name"] else 11)
        t = tab[(tab["region"] == region) & (tab["level"] >= lv) & (tab["level"] < top)] if len(tab) else tab
        need = float(t["growth_needed"].sum()) - float(s.get("symbol_growth_count") or 0) if len(t) else None
        meso = float(t["meso_cost"].sum()) if len(t) else None
        d = daily[daily["region"] == region] if len(daily) else daily
        per_day = (float(d["weekly_total"].iloc[0]) / 7 if len(d) and pd.notna(d["weekly_total"].iloc[0]) else None)
        rows.append({"그림": s["symbol_icon"], "심볼": region, "종류": "아케인" if s in arc else "어센틱", "레벨": lv,
                     "포스": int(s["symbol_force"]),
                     # at max level the API still sends a placeholder requirement (411 / 1309) with growth 0
                     "성장": (100.0 if lv >= top else s["symbol_growth_count"] / s["symbol_require_growth_count"] * 100
                              if s.get("symbol_require_growth_count") else 100.0),
                     "만렙까지 성장치": None if lv >= top else need,
                     "만렙까지 메소 (억)": None if lv >= top or meso is None else meso / 1e8,
                     "예상 일수": None if lv >= top or not per_day or need is None else math.ceil(max(0, need) / per_day)})
    df = pd.DataFrame(rows)
    df["_done"] = df["레벨"] >= df["종류"].map({"아케인": 20, "어센틱": 11})
    df = df.sort_values(["_done", "만렙까지 성장치"], ascending=[True, False], na_position="last")
    df["상태"] = df["_done"].map({True: "만렙", False: "성장 중"})
    left = df[~df["_done"]]
    df = df.drop(columns="_done")
    if len(left):
        row2 = row_factory()
        row2.metric("만렙 남은 심볼", f"{len(left)}개", icon=":material/flag:")
        row2.metric("만렙까지 메소", f"{left['만렙까지 메소 (억)'].sum():,.1f} 억", icon=":material/savings:",
                    help="아케인 메소는 2026-09-17 30% 인하 뒤 공식 표가 없어 [추정] (인하 전 x 0.7)")
        worst = left["예상 일수"].max() if left["예상 일수"].notna().any() else None
        slow = left.sort_values("예상 일수", ascending=False).iloc[0]["심볼"] if worst is not None else "-"
        row2.metric("가장 늦는 심볼", slow, icon=":material/schedule:",
                    delta=("성장치 다 모음 · 메소만 필요" if worst == 0 else f"약 {int(worst)}일") if worst is not None else None,
                    delta_color="off",
                    help="일퀘 + 주간 컨텐츠 수급(주당 합계 ÷ 7) 기준, 이벤트 추가 지급 제외. 성장치를 이미 다 모았으면 "
                         "메소만 내고 바로 올릴 수 있습니다")
    st.dataframe(df, hide_index=True, width="stretch", row_height=38,
                 column_config={"그림": st.column_config.ImageColumn(" ", width="small"),
                                "레벨": st.column_config.NumberColumn(format="Lv.%d"),
                                "성장": st.column_config.ProgressColumn("다음 레벨까지", min_value=0, max_value=100,
                                                                      format="%.0f%%"),
                                "만렙까지 성장치": st.column_config.NumberColumn(format="%,d"),
                                "만렙까지 메소 (억)": st.column_config.NumberColumn(format="%,.1f"),
                                "예상 일수": st.column_config.NumberColumn(format="%d일", help="0일 = 성장치는 다 모았고 메소만 있으면 됨")})


def ability_hyper_section(ability: dict, hyper: dict):
    a, h = st.columns(2, gap="large")
    with a:
        st.markdown("**어빌리티**")
        if ability:
            cur = ability.get("preset_no") or 1
            ptabs = st.tabs([f"프리셋 {p}" + (" (사용 중)" if p == cur else "") for p in (1, 2, 3)])
            for p, t in zip((1, 2, 3), ptabs):
                with t:
                    info = (ability.get(f"ability_preset_{p}") or {}).get("ability_info") or []
                    for line in info:
                        g = line.get("ability_grade") or ""
                        st.markdown(f":{GRADE_COLOR.get(g, 'gray')}-badge[{g}] {line.get('ability_value')}")
            st.caption(f"남은 명성치 {ability.get('remain_fame', 0):,}")
    with h:
        st.markdown("**하이퍼 스탯**")
        if hyper:
            cur = int(hyper.get("use_preset_no") or 1)
            hp = st.segmented_control("프리셋", [1, 2, 3], default=cur, key="hyper_preset",
                                      format_func=lambda p: f"{p}" + (" (사용 중)" if p == cur else "")) or cur
            rows = [{"스탯": x["stat_type"], "레벨": int(x.get("stat_level") or 0), "효과": x.get("stat_increase") or ""}
                    for x in hyper.get(f"hyper_stat_preset_{hp}") or [] if int(x.get("stat_level") or 0) > 0]
            st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch",
                         column_config={"레벨": st.column_config.ProgressColumn(min_value=0, max_value=15, format="%d")})
            st.caption(f"남은 포인트 {hyper.get(f'hyper_stat_preset_{hp}_remain_point', 0)}")


def union_section(union: dict, raider: dict, artifact: dict, champion: dict, char_img: dict, row_factory):
    if not union:
        st.caption("유니온 정보가 없습니다.")
        return
    row = row_factory()
    row.metric("유니온 레벨", f"{union.get('union_level', 0):,}", icon=":material/groups:")
    row.metric("유니온 등급", str(union.get("union_grade", "-")), icon=":material/military_tech:")
    import icons_extra
    gpic = icons_extra.extra_icon("union_grade", str(union.get("union_grade", "")))
    row.metric("아티팩트 레벨", f"{union.get('union_artifact_level', 0)}", icon=":material/token:")
    a, b = st.columns(2, gap="large")
    with a:
        st.markdown("**공격대 효과**")
        raw = [str(e).replace("ALLSTAT", "올스탯") for e in (raider or {}).get("union_raider_stat") or []]
        # the same line repeats once per raider (e.g. "INT 100 증가" x5): merge and show the count and the sum
        cnt: dict[str, int] = {}
        for e in raw:
            cnt[e] = cnt.get(e, 0) + 1

        def merged(e: str, n: int) -> str:
            m = re.search(r"(\d+(?:\.\d+)?)", e)
            if n == 1 or not m:
                return e
            total = float(m.group(1)) * n
            return f"{e}  x{n}  (합 {total:,.0f}{'%' if '%' in e else ''})"
        eff = [merged(e, n) for e, n in sorted(cnt.items(), key=lambda kv: -kv[1])]
        st.dataframe(pd.DataFrame({"효과": eff}), hide_index=True, width="stretch", height=min(420, 40 + 35 * len(eff)))
        # union_occupied_stat is always [] since patch 806 (2026-06-18); the placed stats are union_state_stat
        state = (raider or {}).get("union_state_stat") or []
        if state:
            st.markdown(f"**유니온 스탯** (포인트 {(raider or {}).get('union_max_point', '-')})")
            st.dataframe(pd.DataFrame({"효과": state}), hide_index=True, width="stretch",
                         height=min(320, 40 + 35 * len(state)))
    with b:
        if gpic:
            st.image(gpic, width=64, caption=str(union.get("union_grade", "")))
        st.markdown("**아티팩트**")
        eff = (artifact or {}).get("union_artifact_effect") or []
        st.dataframe(pd.DataFrame([{"효과": e["name"], "레벨": e["level"]} for e in eff]), hide_index=True,
                     width="stretch", height="content", column_config={"레벨": st.column_config.ProgressColumn(
                         min_value=0, max_value=10, format="%d / 10")})
    champs = (champion or {}).get("union_champion") or []
    if champs:
        st.markdown("**유니온 챔피언**")
        st.dataframe(pd.DataFrame([{"그림": char_img.get(c["champion_name"]), "캐릭터": c["champion_name"],
                                    "직업": c.get("champion_class"), "등급": c.get("champion_grade"),
                                    "휘장": len(c.get("champion_badge_info") or [])} for c in champs]),
                     hide_index=True, width="stretch", row_height=44,
                     column_config={"그림": st.column_config.ImageColumn(" ", width="small")})


def link_set_section(link: dict, sets: dict):
    a, b = st.columns(2, gap="large")
    with a:
        st.markdown("**링크 스킬**")
        links = (link or {}).get("character_link_skill") or []
        own = (link or {}).get("character_owned_link_skill")
        rows = [{"그림": x.get("skill_icon"), "스킬": x["skill_name"], "레벨": x.get("skill_level"),
                 "효과": (x.get("skill_effect") or "").replace("\n", " ")} for x in links + ([own] if own else [])]
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch", row_height=38,
                     height=min(560, 40 + 39 * len(rows)),
                     column_config={"그림": st.column_config.ImageColumn(" ", width="small"),
                                    "효과": st.column_config.TextColumn(width="large")})
    with b:
        st.markdown("**세트 효과**")
        for s in (sets or {}).get("set_effect") or []:
            active = [x["set_option"] for x in s.get("set_effect_info") or []]
            with st.expander(f"{s['set_name']} · {s['total_set_count']}세트", icon=":material/layers:"):
                for i in s.get("set_effect_info") or []:
                    st.caption(f"{i['set_count']}세트: {re.sub(r'  +', ' ', i['set_option'])}")
                if not active:
                    st.caption("적용 중인 효과 없음")
