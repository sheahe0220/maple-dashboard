"""스펙업 기록: equipment changes found by comparing daily item-equipment snapshots.

Why: 2026-09-27 user: "안대 맞춘 거 알지? 기존에 블빈마였는데, 이런 것처럼 얼마에 샀고 얼마만큼
스펙업했고 ...". There is no auction-house API (prices are typed in by the user, saved in data/spec_log.yaml), but
the snapshots show what changed and when. Changes found in several presets are merged into one entry.

Self-test:
    <설치 폴더>\\.venv\\Scripts\\python.exe -X utf8 <설치 폴더>\\spec_log.py
"""
import json
from pathlib import Path

import yaml

import db
import equip

PRICES = Path(__file__).resolve().parent / "data" / "spec_log.yaml"


def _state(it: dict, main: str) -> dict:
    pot = [it.get(f"potential_option_{i}") for i in (1, 2, 3)]
    add = [it.get(f"additional_potential_option_{i}") for i in (1, 2, 3)]
    f = equip.frame([it], main).iloc[0]
    return {"name": it.get("item_name"), "icon": it.get("item_icon"), "star": int(it.get("starforce") or 0),
            "pot_grade": it.get("potential_option_grade"), "add_grade": it.get("additional_potential_option_grade"),
            "pot": [x for x in pot if x], "add": [x for x in add if x], "scroll": int(it.get("scroll_upgrade") or 0),
            "main_pct": float(f["main_pct"]), "atk_pct": float(f["atk_pct"])}


def _kind(a: dict, b: dict) -> list[str]:
    if a["name"] != b["name"]:
        return ["교체"]
    out = []
    if a["star"] != b["star"]:
        out.append(f"스타포스 {a['star']}→{b['star']}")
    if a["pot"] != b["pot"] or a["pot_grade"] != b["pot_grade"]:
        out.append("윗잠 " + (f"{a['pot_grade']}→{b['pot_grade']}" if a["pot_grade"] != b["pot_grade"] else "재설정"))
    if a["add"] != b["add"] or a["add_grade"] != b["add_grade"]:
        out.append("에디 " + (f"{a['add_grade']}→{b['add_grade']}" if a["add_grade"] != b["add_grade"] else "재설정"))
    if a["scroll"] != b["scroll"]:
        out.append(f"주문서 {a['scroll']}→{b['scroll']}")
    return out


def changes(name: str, main: str) -> list[dict]:
    """Newest first. One entry per (date, slot, before, after) across presets."""
    con = db.connect()
    rows = con.execute("SELECT s.date, s.json FROM snapshot s JOIN characters c USING (ocid) "
                       "WHERE c.name=? AND s.endpoint='item-equipment' ORDER BY s.date", (name,)).fetchall()
    con.close()
    prev, prev_date, found = None, None, {}
    for d, js in rows:
        data = json.loads(js)
        if "_error" in data:
            continue
        cur = {}
        for p in (1, 2, 3):
            for it in data.get(f"item_equipment_preset_{p}") or []:
                cur[(p, it["item_equipment_slot"])] = _state(it, main)
        if prev is not None:
            for key in set(cur) & set(prev):
                a, b = prev[key], cur[key]
                kinds = _kind(a, b)
                if not kinds:
                    continue
                sig = (d, key[1], a["name"], json.dumps(a["add"] + a["pot"]), b["name"], json.dumps(b["add"] + b["pot"]))
                e = found.setdefault(sig, {"date": d, "since": prev_date, "slot": key[1], "presets": [], "before": a,
                                           "after": b, "kinds": kinds})
                e["presets"].append(key[0])
        prev, prev_date = cur, d
    out = sorted(found.values(), key=lambda e: (e["date"], e["slot"]), reverse=True)
    for e in out:
        e["d_main"] = e["after"]["main_pct"] - e["before"]["main_pct"]
        e["d_atk"] = e["after"]["atk_pct"] - e["before"]["atk_pct"]
        e["key"] = f"{name}|{e['date']}|{e['slot']}|{e['after']['name']}"
    return out


def load_prices() -> dict:
    return (yaml.safe_load(PRICES.read_text(encoding="utf-8")) or {}) if PRICES.exists() else {}


def save_prices(prices: dict) -> None:
    PRICES.parent.mkdir(exist_ok=True)
    PRICES.write_text(yaml.safe_dump(prices, allow_unicode=True, sort_keys=True), encoding="utf-8")


def selftest() -> None:
    a = {"name": "블랙빈 마크", "star": 20, "pot_grade": "레전드리", "add_grade": "에픽", "pot": ["INT +12%"],
         "add": ["INT +4%"], "scroll": 5}
    assert _kind(a, dict(a, name="마력이 깃든 안대")) == ["교체"]
    assert _kind(a, dict(a, star=22, add_grade="레전드리", add=["INT +6%"])) == ["스타포스 20→22", "에디 에픽→레전드리"]
    assert _kind(a, dict(a)) == []
    con = db.connect()
    row = con.execute("SELECT c.name FROM snapshot s JOIN characters c USING (ocid) "
                      "WHERE s.endpoint='item-equipment' GROUP BY c.name ORDER BY COUNT(*) DESC LIMIT 1").fetchone()
    con.close()
    if row:  # real data check on whichever character has the most equipment snapshots
        ch = changes(row[0], "INT")
        assert all(e["kinds"] and e["date"] > (e["since"] or "") for e in ch)
        print(f"{row[0]}: {len(ch)} changes")
    print("selftest ok")


if __name__ == "__main__":
    selftest()
