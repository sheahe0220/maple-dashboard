"""Lookup for the extra images in ref/icons_extra (job art, cubes, currency, symbols, skills, worlds ...).

Why: 2026-09-27 the image research (10_조사/20260927_그림보강/보고서.md) fetched 481 official images into
ref/icons_extra/<category>/<name>.png with _sources.csv; the app had no way to use them.
extra_icon(category, name) returns a data URL (works in st.image, st.dataframe ImageColumn and markdown <img>),
cached per process so each file is read and encoded once.

Self-test:
    <story>\\.venv\\Scripts\\python.exe -X utf8 <story>\\icons_extra.py
"""
import base64
import csv
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "ref" / "icons_extra"


@lru_cache(maxsize=1)
def index() -> dict:
    """(category, name) -> file path, from _sources.csv plus whatever files are present."""
    out = {}
    src = ROOT / "_sources.csv"
    if src.exists():
        with open(src, encoding="utf-8-sig") as f:
            for r in csv.DictReader(f):
                p = ROOT / r["file"]
                if p.exists():
                    out[(r["category"], r["name"])] = p
    for p in list(ROOT.glob("*/*.png")) + list(ROOT.glob("*/*.webp")):
        out.setdefault((p.parent.name, p.stem), p)
    return out


@lru_cache(maxsize=2048)
def extra_icon(category: str, name: str) -> str | None:
    p = index().get((category, name))
    if p is None:
        return None
    mime = "image/webp" if p.suffix == ".webp" else "image/png"
    return f"data:{mime};base64," + base64.b64encode(p.read_bytes()).decode("ascii")


def names(category: str) -> list[str]:
    return sorted(n for c, n in index() if c == category)


def first_icon(categories: tuple, name: str) -> str | None:
    """The first category that has this name (e.g. item names found in 'item' or 'cube')."""
    for c in categories:
        u = extra_icon(c, name)
        if u:
            return u
    return None


def selftest() -> None:
    idx = index()
    cats = sorted({c for c, _ in idx})
    print(f"images {len(idx)}, categories {len(cats)}: {', '.join(cats)}")
    assert len(idx) >= 400, len(idx)
    for c, n in [("job_art_s", "키네시스"), ("job_thumb_s", "키네시스"), ("currency", "강렬한 힘의 결정"),
                 ("item", "슈피겔만의 평범한 목걸이")]:
        u = extra_icon(c, n)
        assert u and u.startswith("data:image/"), (c, n)
        print(f"  {c}/{n}: {len(u) // 1024} KB")
    assert extra_icon("job_art", "없는직업") is None
    print("selftest ok")


if __name__ == "__main__":
    selftest()
