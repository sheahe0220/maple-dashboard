"""Custom UI pieces Streamlit doesn't have natively (CCv2 inline components).

Why: 2026-09-27 user asked for an in-game style equipment window: small icon tiles laid out like the
MapleStory equip window, click a tile to see the item. Native widgets can't show clickable images, so this
is a Custom Components v2 inline component (no v1 APIs). Registered once at import; app.py does not reload
this module.

Colors use Streamlit's --st-* theme variables so light and dark mode both work; only the potential-grade
border colors are fixed (same meaning in both modes).
"""
from collections.abc import Callable

import streamlit as st

# in-game equip window, 6 rows x 5 columns (None = empty cell)
EQUIP_LAYOUT = [
    ["반지1", "얼굴장식", None, "모자", "망토"],
    ["반지2", "눈장식", "무기", "상의", "장갑"],
    ["반지3", "귀고리", "보조무기", "하의", "신발"],
    ["반지4", "펜던트", "엠블렘", "어깨장식", "훈장"],
    ["벨트", "펜던트2", None, None, "기계 심장"],
    ["포켓 아이템", None, None, "뱃지", None],
]
GRADE_BORDER = {"레전드리": "#3fb950", "유니크": "#d4a72c", "에픽": "#a371f7", "레어": "#4c9aff"}

_CSS = """
.eqwin { display: grid; grid-template-columns: repeat(5, 58px); gap: 6px; padding: 10px;
         background: var(--st-secondary-background-color); border: 1px solid var(--st-border-color);
         border-radius: var(--st-base-radius); width: max-content; }
.cell { position: relative; width: 58px; height: 58px; box-sizing: border-box; border-radius: 8px;
        border: 2px solid var(--st-border-color); background: var(--st-background-color);
        display: flex; align-items: center; justify-content: center; cursor: pointer; }
.cell img { max-width: 40px; max-height: 40px; image-rendering: pixelated; }
.cell.empty { cursor: default; border-style: dashed; opacity: .45; }
.cell.empty span { font-size: 9px; color: var(--st-text-color); text-align: center; line-height: 1.1; }
.cell.sel { outline: 3px solid var(--st-primary-color); outline-offset: 1px; }
.cell:not(.empty):hover { transform: translateY(-1px); }
.star { position: absolute; top: -6px; left: -4px; font-size: 10px; font-weight: 700; padding: 0 4px;
        border-radius: 6px; background: #c98500; color: #fff; line-height: 15px; }
"""

_JS = """
export default function (component) {
  const { data, parentElement, setStateValue } = component
  const root = parentElement.querySelector(".eqwin")
  if (!root || !data) return
  root.replaceChildren()
  for (const c of data.cells) {
    const d = document.createElement("div")
    if (!c.name) {
      d.className = "cell empty"
      const s = document.createElement("span")
      s.textContent = c.slot || ""
      d.appendChild(s)
    } else {
      d.className = "cell" + (c.slot === data.selected ? " sel" : "")
      d.title = c.name
      if (c.border) d.style.borderColor = c.border
      if (c.icon) {
        const img = document.createElement("img")
        img.src = c.icon
        img.alt = c.name
        d.appendChild(img)
      }
      if (c.star) {
        const b = document.createElement("div")
        b.className = "star"
        b.textContent = "★" + c.star
        d.appendChild(b)
      }
      d.onclick = () => setStateValue("selected", c.slot)
    }
    root.appendChild(d)
  }
}
"""

_EQUIP_WINDOW = st.components.v2.component("equip_window", html="<div class='eqwin'></div>", css=_CSS, js=_JS)


def equip_window(items: list[dict], *, key: str, on_change: Callable[[], None] | None = None) -> str | None:
    """items: dicts with slot, name, icon, star, pot_grade. Returns the selected slot (default: first item)."""
    by_slot = {it["slot"]: it for it in items}
    state = st.session_state.get(key) or {}
    selected = state.get("selected") if isinstance(state, dict) else None
    if selected not in by_slot:
        selected = next(iter(by_slot), None)
    cells = []
    for row in EQUIP_LAYOUT:
        for slot in row:
            it = by_slot.get(slot) if slot else None
            if it:
                cells.append({"slot": slot, "name": it["name"], "icon": it.get("icon"), "star": it.get("star") or 0,
                              "border": GRADE_BORDER.get(it.get("pot_grade") or "")})
            else:
                cells.append({"slot": slot or "", "name": None})
    res = _EQUIP_WINDOW(data={"cells": cells, "selected": selected}, key=key,
                        on_selected_change=on_change or (lambda: None))
    return res.selected if getattr(res, "selected", None) in by_slot else selected
