"""Link-only access for the shared dashboard (no password to type).

Why: 2026-09-27 user: "폴더를 주거나 링크를 준 사람만 쓰게, 비번은 귀찮고". Opening on this PC (localhost) is always
allowed. From outside (the Cloudflare tunnel) the page opens only when the address carries ?t=<SHARE_TOKEN>, so a
friend just clicks the link. SHARE_TOKEN lives in .env (created on first run). share_link.bat writes the tunnel
log to data/tunnel.log, and the sidebar on this PC shows the full link to copy.
"""
import re
import secrets
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parent
ENV = ROOT / ".env"
TUNNEL_LOG = ROOT / "data" / "tunnel.log"


def share_token() -> str:
    """SHARE_TOKEN from .env; appended once if missing (the API key line is left untouched)."""
    text = ENV.read_text(encoding="utf-8") if ENV.exists() else ""
    for line in text.splitlines():
        if line.startswith("SHARE_TOKEN=") and line.split("=", 1)[1].strip():
            return line.split("=", 1)[1].strip()
    tok = secrets.token_urlsafe(16)
    with ENV.open("a", encoding="utf-8") as f:
        f.write(("" if text.endswith("\n") or not text else "\n") + f"SHARE_TOKEN={tok}\n")
    return tok


def is_local() -> bool:
    host = (st.context.headers.get("host") or "").lower()
    # no Host header = not a browser request (headless AppTest); tunnel visitors always send one
    return not host or host.startswith(("localhost", "127.0.0.1", "[::1]"))


def tunnel_url() -> str | None:
    """Latest https://....trycloudflare.com address printed by cloudflared into data/tunnel.log."""
    if not TUNNEL_LOG.exists():
        return None
    found = re.findall(r"https://[a-z0-9-]+\.trycloudflare\.com", TUNNEL_LOG.read_text(encoding="utf-8", errors="ignore"))
    return found[-1] if found else None


def gate() -> None:
    """Stop the script for outside visitors without the right ?t= value."""
    if is_local():
        return
    tok = share_token()
    given = st.query_params.get("t", "")
    if given and secrets.compare_digest(given, tok):
        st.session_state["share_ok"] = True
    if not st.session_state.get("share_ok"):
        st.title("메이플 대시보드")
        st.warning("허가된 링크가 아닙니다. 링크를 보내 준 사람에게 전체 주소를 다시 받아 주세요.", icon=":material/lock:")
        st.stop()


def sidebar_link() -> None:
    """On this PC only: the link to send (tunnel address + token)."""
    if not is_local():
        return
    url = tunnel_url()
    with st.expander("친구에게 보낼 링크", icon=":material/share:"):
        if url:
            st.code(f"{url}/?t={share_token()}", language=None)
            st.caption("share_link.bat 을 켤 때마다 주소가 바뀝니다. 이 주소를 아는 사람만 들어올 수 있습니다.")
        else:
            st.caption("share_link.bat 을 실행하면 여기에 보낼 주소가 나옵니다.")
