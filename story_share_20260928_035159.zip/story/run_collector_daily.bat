@echo off
rem Daily unattended collection for Windows Task Scheduler (2026-09-27).
rem --history-only: normal daily steps, then the rest of the day's budget goes to past enhancement history
rem (back to config history_start = 2024-12-19, 리부트 -> 에오스). Once that is complete it is a plain daily run.
rem Output is appended to data\collector_daily.log (no pause, nobody is watching the window).
chcp 65001 > nul
cd /d "%~dp0"
echo ===== %date% %time% >> data\collector_daily.log
.venv\Scripts\python.exe -X utf8 collector.py --history-only >> data\collector_daily.log 2>&1
rem 2026-09-28: send a copy of maple.db to the private GitHub release so the home laptop gets it
.venv\Scripts\python.exe -X utf8 _sync\git_sync.py db-upload >> data\collector_daily.log 2>&1
