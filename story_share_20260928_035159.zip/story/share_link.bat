@echo off
chcp 65001 >nul
rem Opens the dashboard and a public https link (Cloudflare quick tunnel).
rem The link changes every time this is started. Close this window to stop sharing.
cd /d "%~dp0"
start "dashboard" /min .venv\Scripts\python.exe -m streamlit run app.py --server.headless true --server.port 8501
echo.
echo 링크를 만드는 중입니다. 잠시 뒤 대시보드 왼쪽 "친구에게 보낼 링크" 에 주소가 뜹니다.
echo (그 주소에만 들어올 수 있는 값이 붙어 있습니다. 이 창을 닫으면 공유가 끝납니다.)
echo.
if not exist data mkdir data
"C:\Program Files (x86)\cloudflared\cloudflared.exe" tunnel --no-autoupdate --url http://localhost:8501 > data\tunnel.log 2>&1
